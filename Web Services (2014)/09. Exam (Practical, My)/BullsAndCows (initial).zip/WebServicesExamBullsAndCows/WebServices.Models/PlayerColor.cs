﻿namespace WebServices.Models
{
    using System;
    using System.Linq;

    public enum PlayerColor
    {
        Red = 0,
        Blue = 1
    }
}

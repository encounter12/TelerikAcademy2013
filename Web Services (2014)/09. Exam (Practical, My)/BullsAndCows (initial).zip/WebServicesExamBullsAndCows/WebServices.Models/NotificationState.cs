﻿namespace WebServices.Models
{
    using System;
    using System.Linq;

    public enum NotificationState
    {
        Read = 0,
        Unread = 1
    }
}
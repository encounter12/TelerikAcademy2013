namespace Exam.Data.Migrations
{
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(ApplicationDbContext context)
        {
            //this.SeedUser(context);
        }

        //private void SeedGame(ApplicationDbContext context)
        //{
        //    if (context.Games.Any())
        //    {
        //        return;
        //    }

        //    context.Games.Add(new Game
        //    {
        //        FirstPlayerId = "Sample"
        //    });
        //}

        //private void SeedUser(ApplicationDbContext context)
        //{
        //    if (context.ApplicationUsers.Any())
        //    {
        //        return;
        //    }

        //    context.ApplicationUsers.Add(new ApplicationUser
        //    {
        //        UserName = "testUser"
        //    });
        //}
    }
}

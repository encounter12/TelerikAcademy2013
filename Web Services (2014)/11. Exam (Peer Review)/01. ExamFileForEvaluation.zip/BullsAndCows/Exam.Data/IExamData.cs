﻿namespace Exam.Data
{
    using Exam.Data.Repositories;
    using Exam.Models;

    public interface IExamData
    {
        IRepository<ApplicationUser> ApplicationUsers { get; }

        IRepository<Game> Games { get; }

        IRepository<Guess> Guess { get; }

        int SaveChanges();
    }
}
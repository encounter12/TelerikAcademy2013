﻿namespace Exam.Services.Controllers
{
    using System.Linq;
    using System.Web.Http;
    using System.Web.Http.Description;
    using Exam.Data;
    using Exam.Models;

    [Authorize]
    public class GuessesController : BaseApiController
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public GuessesController(IExamData data)
            : base(data)
        {
        }

        // POST: api/Guesses
        [Authorize]
        [HttpPost]
        [ResponseType(typeof(Guess))]
        public IHttpActionResult PostGuess(int id, string number)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

           // db.Guesses.Add(guess);
           // db.SaveChanges();
           // 
           return Ok();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool GuessExists(int id)
        {
            return db.Guesses.Count(e => e.Id == id) > 0;
        }
    }
}
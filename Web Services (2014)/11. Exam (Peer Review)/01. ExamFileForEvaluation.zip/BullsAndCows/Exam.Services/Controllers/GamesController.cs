﻿namespace Exam.Services.Controllers
{
    using System;
    using System.Linq;
    using System.Web.Http;
    using System.Web.Http.Description;
    using Exam.Data;
    using Exam.Models;
    using Exam.Services.Models;
    using System.Threading;
    using Microsoft.AspNet.Identity;

    [Authorize]
    public class GamesController : BaseApiController
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public GamesController(IExamData data)
            : base(data)
        {
        }

        // GET: api/Games
        [HttpGet]
        [AllowAnonymous]
        public IHttpActionResult GetGames()
        {
            var games = db.Games
                    .Where(g => g.Status == GameStatus.WaitingForOpponent)
                    .OrderBy(g => g.Name)
                    .ThenBy(g => g.CreatedOn)
                    .ThenBy(g => g.FirstPlayer.UserName)
                    .Take(10)
                    .Select(GamesDataModel.FromGame).ToList();

            return Ok(games);
        }

        // GET: api/Games?page=P
        [HttpGet]
        [AllowAnonymous]
        public IHttpActionResult GetGames(int page)
        {
            var games = db.Games
                    .Where(g => g.Status == GameStatus.WaitingForOpponent)
                    .OrderBy(g => g.Name)
                    .ThenBy(g => g.CreatedOn)
                    .ThenBy(g => g.FirstPlayer.UserName)
                    .Skip(10 * (page - 1))
                    .Take(10)
                    .Select(GamesDataModel.FromGame).ToList();

            return Ok(games);
        }

        //[HttpGet]
        //[Authorize]
        //public IHttpActionResult GetGames()
        //{
        //    var games = db.Games
        //            .Where(g => (g.FirstPlayerId == Thread.CurrentPrincipal.Identity.GetUserId() || g.SecondPlayerId == Thread.CurrentPrincipal.Identity.GetUserId()) && (g.Status != GameStatus.WonByBlue || g.Status != GameStatus.WonByRed))
        //            .OrderBy(g => g.Status)
        //            .ThenBy(g => g.Name)
        //            .ThenBy(g => g.CreatedOn)
        //            .ThenBy(g => g.FirstPlayer.UserName)
        //            .Take(10)
        //            .Select(GamesDataModel.FromGame).ToList();

        //    return Ok(games);
        //}

        // GET: api/Games/ID
        [Authorize]
        [ResponseType(typeof(Game))]
        public IHttpActionResult GetGame(int id)
        {
            Game game = db.Games.Find(id);

            if (game == null || (game.FirstPlayerId != Thread.CurrentPrincipal.Identity.GetUserId() && game.SecondPlayerId != Thread.CurrentPrincipal.Identity.GetUserId()))
            {
                return NotFound();
            }

            var details = new DetailsGameModel
            {
                Id = game.Id,
                Name = game.Name,
                DateCreated = game.CreatedOn,
                Red = game.FirstPlayerColor == PlayerColor.Red ? game.FirstPlayer.UserName : game.SecondPlayer.UserName,
                Blue = game.FirstPlayerColor == PlayerColor.Blue ? game.FirstPlayer.UserName : game.SecondPlayerId != null ? game.SecondPlayer.UserName : null,
                YourNumber = game.FirstPlayerId == Thread.CurrentPrincipal.Identity.GetUserId() ? game.FirstPlayerUserNumber : game.SecondPlayerUserNumber,
               // YourGuesses = game.Guesses.Where(g => g.UserId == Thread.CurrentPrincipal.Identity.GetUserId()),
               // OpponentGuesses = game.Guesses.Where(g => g.UserId != Thread.CurrentPrincipal.Identity.GetUserId()),
                YourColor = game.FirstPlayerId == Thread.CurrentPrincipal.Identity.GetUserId() ? game.FirstPlayerColor.ToString() : game.SecondPlayerColor.ToString(),
                GameState = game.Status.ToString()
            };

            return Ok(details);
        }

        // PUT: api/Games/5
        [HttpPut]
        [Authorize]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutGame(int id, string Number)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Game game = db.Games.Find(id);
            if (game == null || game.FirstPlayerId != Thread.CurrentPrincipal.Identity.GetUserId())
            {
                return NotFound();
            }

            game.SecondPlayerId = Thread.CurrentPrincipal.Identity.GetUserId();
            game.SecondPlayerColor = PlayerColor.Blue;
            game.SecondPlayerUserNumber = Number;

            var random = new Random();
            int turn = random.Next(0, 2);
            if (turn == 0)
            {
                game.Status = GameStatus.RedTurn;
            }
            else
            {
                game.Status = GameStatus.BlueTurn;
            }
            
            db.SaveChanges();

            return Ok("{\"result\": \"You joined game \"" + game.Name + "\"\"}");
        }

        // POST: api/Games
        [Authorize]
        [HttpPost]
        [ResponseType(typeof(Game))]
        public IHttpActionResult PostGame(CreateGameModel gameModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var newGame = new Game
            {
                Name = gameModel.Name,
                FirstPlayerId = Thread.CurrentPrincipal.Identity.GetUserId(),
                FirstPlayerColor = PlayerColor.Red,
                FirstPlayerUserNumber = gameModel.Number,
                CreatedOn = DateTime.Now,
                Status = GameStatus.WaitingForOpponent
            };

            db.Games.Add(newGame);
            db.SaveChanges();

            var currentGame = db.Games
                .Where(x => x.Name == newGame.Name)
                .Select(x => new GamesDataModel
                {
                    Id = x.Id,
                    Name = x.Name,
                    Blue = x.SecondPlayer != null ? x.SecondPlayer.UserName : "No blue player yet",
                    Red = x.FirstPlayer.UserName,
                    GameState = x.Status.ToString(),
                    DateCreated = x.CreatedOn
                })
                .FirstOrDefault();

            if (currentGame == null)
            {
                return NotFound();
            }

            return Ok(currentGame);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }

            base.Dispose(disposing);
        }

        private bool GameExists(int id)
        {
            return db.Games.Count(e => e.Id == id) > 0;
        }
    }
}
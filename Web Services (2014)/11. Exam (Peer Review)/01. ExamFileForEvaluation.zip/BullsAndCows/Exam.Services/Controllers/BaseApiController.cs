﻿namespace Exam.Services.Controllers
{
    using Exam.Data;
    using System.Web.Http;

    [Authorize]
    public abstract class BaseApiController : ApiController
    {
        protected IExamData data;

        protected BaseApiController(IExamData data)
        {
            this.data = data;
        }
    }
}
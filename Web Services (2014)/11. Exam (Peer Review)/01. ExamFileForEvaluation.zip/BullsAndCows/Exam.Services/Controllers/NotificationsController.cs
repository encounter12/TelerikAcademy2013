﻿namespace Exam.Services.Controllers
{
    using System.Linq;
    using System.Web.Http;
    using System.Web.Http.Description;
    using Exam.Data;
    using System.Threading;
    using Microsoft.AspNet.Identity;

    [Authorize]
    public class NotificationsController : BaseApiController
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public NotificationsController(IExamData data)
            : base(data)
        {
        }

        // GET: api/Notifications
        [Authorize]
        [ResponseType(typeof(object))]
        public IHttpActionResult GetNotifications()
        {
            var notifications = db.Notifications
        .Where(n => n.UserId == Thread.CurrentPrincipal.Identity.GetUserId())
        .OrderByDescending(n => n.DateCreated)
        .Take(10)
        .ToList();

            return Ok(notifications);
        }

        // GET: api/Notifications?page=P
        [Authorize]
        [ResponseType(typeof(object))]
        public IHttpActionResult GetNotifications(int page)
        {
            var notifications = db.Notifications
        .Where(n => n.UserId == Thread.CurrentPrincipal.Identity.GetUserId())
        .OrderByDescending(n => n.DateCreated)
        .Skip(10 * (page - 1))
        .Take(10)
        .ToList();

            return Ok(notifications);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool NotificationExists(int id)
        {
            return db.Notifications.Count(e => e.Id == id) > 0;
        }
    }
}
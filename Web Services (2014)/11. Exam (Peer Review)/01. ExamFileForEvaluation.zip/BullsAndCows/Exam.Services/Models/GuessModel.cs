﻿namespace Exam.Services.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class GuessModel
    {
        public int Id {get;set;}

        [Required]
        public int UserId {get;set;}

        [Required]
        [MinLength(2)]
        [MaxLength(20)]
        public string Username {get;set;}

        [Required]
        public int GameId {get;set;}

        [Required]
        [StringLength(4)]
        public string Number {get;set;}

        [Required]
        public DateTime DateMade {get;set;}

        public int CowsCount {get;set;}

        public int BullsCount {get;set;}
    }
}
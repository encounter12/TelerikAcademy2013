﻿namespace Exam.Services.Models
{
    using Exam.Models;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Linq.Expressions;

    public class GamesDataModel
    {
        public static Expression<Func<Game, GamesDataModel>> FromGame
        {
            get
            {
                return g => new GamesDataModel
                {
                    Id = g.Id,
                    Name = g.Name,
                    Blue = g.SecondPlayer != null ? g.SecondPlayer.UserName : "No blue player yet",
                    Red = g.FirstPlayer.UserName,
                    GameState = g.Status.ToString(),
                    DateCreated = g.CreatedOn
                };
            }
        }

        public int Id { get; set; }

        [Required]
        [MinLength(2)]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        public string Blue { get; set; }

        [Required]
        public string Red { get; set; }

        [Required]
        public string GameState { get; set; }

        [Required]
        public DateTime DateCreated { get; set; }
    }
}
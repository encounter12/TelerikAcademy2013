﻿namespace Exam.Services.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class DetailsGameModel
    {
        public DetailsGameModel()
        {
            this.YourGuesses = new HashSet<GuessModel>();
            this.OpponentGuesses = new HashSet<GuessModel>();
        }

        public int Id { get; set; }

        [Required]
        [MinLength(2)]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        public DateTime DateCreated { get; set; }

        [Required]
        public string Red { get; set; }

        [Required]
        public string Blue { get; set; }

        [Required]
        [StringLength(4)]
        public string YourNumber { get; set; }

        public IEnumerable<GuessModel> YourGuesses { get; set; }

        public IEnumerable<GuessModel> OpponentGuesses { get; set; }

        [Required]
        public string YourColor { get; set; }

        [Required]
        public string GameState { get; set; }
    }
}
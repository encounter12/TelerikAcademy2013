﻿namespace Exam.Services.Models
{
    using System.ComponentModel.DataAnnotations;

    public class CreateGameModel
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public string Number { get; set; }
    }
}
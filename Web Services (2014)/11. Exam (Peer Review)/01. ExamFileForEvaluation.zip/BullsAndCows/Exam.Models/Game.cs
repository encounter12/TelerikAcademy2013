﻿namespace Exam.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class Game
    {
        public Game()
        {
            this.FirstPlayerUserNumber = "----";
            this.FirstPlayerUserNumber = "----";
            this.Status = GameStatus.WaitingForOpponent;
            this.FirstPlayerColor = PlayerColor.Red;
            this.SecondPlayerColor = PlayerColor.Blue;
            this.Guesses = new HashSet<Guess>();
        }

        public int Id { get; set; }

        [Required]
        [StringLength(4)]
        [Column(TypeName = "char")]
        public string FirstPlayerUserNumber { get; set; }

        [StringLength(4)]
        [Column(TypeName = "char")]
        public string SecondPlayerUserNumber { get; set; }

        public GameStatus Status { get; set; }

        [Required]
        [MinLength(2)]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required]
        public DateTime CreatedOn {get;set;}

        [Required]
        public string FirstPlayerId { get; set; }

        public virtual ApplicationUser FirstPlayer { get; set; }

        public string SecondPlayerId { get; set; }

        public virtual ApplicationUser SecondPlayer { get; set; }

        public PlayerColor FirstPlayerColor { get; set; }

        public PlayerColor SecondPlayerColor { get; set; }

        public IEnumerable<Guess> Guesses { get; set; }
    }
}

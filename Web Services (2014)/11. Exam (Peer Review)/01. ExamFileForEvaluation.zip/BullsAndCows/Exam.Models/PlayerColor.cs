﻿namespace Exam.Models
{
    public enum PlayerColor
    {
        Red = 0,
        Blue = 1
    }
}

﻿namespace Exam.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class Notification
    {
        public int Id { get; set; }

        [Required]
        public string UserId { get; set; }

        [Required]
        [MaxLength(100)]
        public string Message { get; set; }

        [Required]
        public DateTime DateCreated { get; set; }

        [Required]
        public NotificationType Type { get; set; }

        [Required]
        public NotificationState State { get; set; }

        public int GameId { get; set; }

    }
}

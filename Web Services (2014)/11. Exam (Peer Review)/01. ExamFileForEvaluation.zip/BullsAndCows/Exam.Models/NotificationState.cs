﻿namespace Exam.Models
{
    public enum NotificationState
    {
        Undera = 0,
        Read = 1
    }
}

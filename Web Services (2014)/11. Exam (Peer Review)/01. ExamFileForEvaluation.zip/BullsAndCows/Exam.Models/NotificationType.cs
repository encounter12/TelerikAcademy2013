﻿namespace Exam.Models
{
    public enum NotificationType
    {
        YourTurn = 0,
        GameWon = 1,
        GameLost = 2
    }
}

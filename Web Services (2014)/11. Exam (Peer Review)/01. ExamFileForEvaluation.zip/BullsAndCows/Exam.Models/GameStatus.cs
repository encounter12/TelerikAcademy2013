﻿namespace Exam.Models
{
    public enum GameStatus
    {
        WaitingForOpponent = 0,
        RedTurn = 1,
        BlueTurn = 2,
        WonByRed = 3,
        WonByBlue = 4
    }
}

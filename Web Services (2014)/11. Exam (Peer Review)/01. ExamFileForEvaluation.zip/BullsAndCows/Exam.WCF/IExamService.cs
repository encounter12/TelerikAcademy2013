﻿namespace Exam.WCF
{
    using System.ServiceModel;
    using System.ServiceModel.Web;

    [ServiceContract]
    public interface IExamService
    {
        [OperationContract]
        [WebGet(UriTemplate = "/users")]
        void GetInfo();
    }
}
﻿using BullsAndCows.Models;
using BullsAndCows.WCF.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace BullsAndCows.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IAlertsService" in both code and config file together.

    [ServiceContract]
    public interface IUsersService
    {
        [OperationContract]
        [WebGet(UriTemplate = "Users")]
        IEnumerable<UsersDataModel> GetUsers();

        [OperationContract]
        [WebGet(UriTemplate = "Users/{id}")]
        User GetUserDetails(string id);
    }

}

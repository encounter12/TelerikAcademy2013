﻿using BullsAndCows.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace BullsAndCows.WCF.DataModels
{
    public class UsersDataModel
    {
        public string Id { get; set; }

        public string Username { get; set; }

        public static Expression<Func<User, UsersDataModel>> FromUser
        {
            get
            {
                return a => new UsersDataModel
                {
                    Username = a.Email,
                    Id = a.Id
                };
            }
        }
    }
}
﻿using BullsAndCows.Data;
using BullsAndCows.Models;
using BullsAndCows.Web.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using Microsoft.AspNet.Identity;

namespace BullsAndCows.Web.Controllers
{
    [Authorize]
    public class GuessController : BaseApiController
    {
        public GuessController(IBullsAndCowsData data) 
            : base(data)
        {
        }

        [HttpPost]
        public IHttpActionResult Create(int id, GuessDataModel model)
        {
            var game = this.data.Games.All().FirstOrDefault(g => g.Id == id);
            if (game == null)
            {
                return NotFound();
            }

            if (game.RedId != this.User.Identity.GetUserId() && game.BlueId != this.User.Identity.GetUserId())
            {
                return BadRequest("Not your game");
            }

            model = CheckForBullsAndCows(model, game);
            if (model.BullsCount == 4)
            {
                game.State = GameState.WonByB;
                
                if (game.RedId == this.User.Identity.GetUserId())
                {
                    game.State = GameState.WonByR;
                }
            }
            else
            {
                game.State = GameState.TurnR;
                if (game.RedId == this.User.Identity.GetUserId())
                {
                    game.State = GameState.TurnB;
                }
            }

            var guess = new Guess
            {
                UserId = this.User.Identity.GetUserId(),
                Username = this.User.Identity.Name,
                Number = model.Number,
                DateMade = DateTime.Now,
                BullsCount = model.BullsCount,
                CowsCount = model.CowsCount
            };

            this.data.Guesses.Add(guess);
            this.data.SaveChanges();
            
            return Ok(guess);
        }

        private GuessDataModel CheckForBullsAndCows(GuessDataModel model, Game game)
        {
            string number = game.BlueNumber;
            if (this.User.Identity.GetUserId() == game.BlueId)
            {
                number = game.RedNumber;
            }

            string guess = model.Number;

            for (int i = 0; i < 4; i++)
            {
                if (number[i] == guess[i])
                {
                    model.BullsCount += 1;
                    continue;
                }

                for (int j = 0; j < 4; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }

                    if (guess[i] == number[j])
                    {
                        model.CowsCount += 1;
                        continue;
                    }
                }
            }

            return model;
        }
    }
}
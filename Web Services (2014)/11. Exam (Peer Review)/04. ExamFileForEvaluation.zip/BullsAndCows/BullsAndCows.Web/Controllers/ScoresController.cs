﻿using BullsAndCows.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BullsAndCows.Web.Controllers
{
    public class ScoresController : BaseApiController
    {
        public ScoresController(IBullsAndCowsData data) 
            : base(data)
        {
        }

        [HttpGet]
        public IHttpActionResult Get()
        {
            var users = this.data.Users.All()
                .OrderByDescending(u => u.GamesWon * 100 + u.GamesLost * 15)
                .Take(10)
                .Select(u => new 
                {
                    Username = u.Email,
                    Rank = u.GamesWon * 100 + u.GamesLost * 15
                });
            
            return Ok(users);
        }
    }
}

﻿using BullsAndCows.Data;
using BullsAndCows.Models;
using BullsAndCows.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using Microsoft.AspNet.Identity;
using BullsAndCows.Web.DataModels;

namespace BullsAndCows.Web.Controllers
{
    public class GamesController : BaseApiController
    {
        const int DefaultPageSize = 10;
        private static Random random = new Random();
        public GamesController(IBullsAndCowsData data) 
            : base(data)
        {
        }

        [HttpGet]
        public IHttpActionResult Get()
        {
            return this.Get(0);
        }

        [HttpGet]
        public IHttpActionResult Get(int page)
        {
            var games = this.data.Games.All()
                .Where(g => g.BlueId == null)
                .OrderBy(g => g.Name)
                .ThenBy(g => g.DateCreated)
                .ThenBy(g => g.Red.UserName)
                .Skip(page * DefaultPageSize)
                .Take(DefaultPageSize)
                .Select(GameDataModel.FromGame);
            return Ok(games);
        }

        [HttpGet]
        [Authorize]
        public IHttpActionResult GetAuthorizedGames(int page)
        {
            var games = this.data.Games.All()
                .Where(g => g.BlueId == null || g.BlueId == this.User.Identity.GetUserId())
                .OrderBy(g => g.Name)
                .ThenBy(g => g.DateCreated)
                .ThenBy(g => g.Red.UserName)
                .Skip(page * DefaultPageSize)
                .Take(DefaultPageSize)
                .Select(GameDataModel.FromGame);
            return Ok(games);
        }

        [HttpGet]
        [Authorize]
        public IHttpActionResult GetDetails(int id)
        {
            var game = this.data.Games.All().Where(g => g.Id == id).Select(GameDetailsDataModel.FromGame);
            if (game == null)
            {
                return NotFound();
            }

            return Ok(game);
        }

        [HttpPut]
        [Authorize]
        public IHttpActionResult Join(int id, CreateGameDataModel model)
        {
            var game = this.data.Games.All().FirstOrDefault(g => g.Id == id);

            if (game.State != 0 || game == null || game.RedId == this.User.Identity.GetUserId())
            {
                return BadRequest("Invalid game to join");
            }

            game.BlueId = this.User.Identity.GetUserId();
            game.BlueNumber = model.Number;
            var turn = random.Next(1, 3);
            game.State = (GameState)turn;
            
            this.data.SaveChanges();
            return Ok(new {result = @"You joined game \" + game.Name + @"\"});
        }

        [HttpPost]
        [Authorize]
        public IHttpActionResult Create(CreateGameDataModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid game model");
            }

            var currentUserId = this.User.Identity.GetUserId();
            
            var newGame = new Game
            {
                Name = model.Name,
                RedId = currentUserId,
                RedNumber = model.Number,
                State = GameState.WaitingForOpponent,
                DateCreated = DateTime.Now
            };

            this.data.Games.Add(newGame);
            this.data.SaveChanges();

            var newGameData = this.data.Games.All()
                .Where(g => g.Name == model.Name)
                .Select(GameDataModel.FromGame);
           
            return Ok(newGameData);
        }
    }
}

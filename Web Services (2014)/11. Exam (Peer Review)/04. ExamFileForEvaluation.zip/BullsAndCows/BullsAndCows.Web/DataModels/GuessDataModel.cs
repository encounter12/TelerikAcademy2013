﻿using System;
using System.ComponentModel.DataAnnotations;
namespace BullsAndCows.Web.DataModels
{
    public class GuessDataModel
    {
        public int Id { get; set; }

        public string UserId { get; set; }

        public string Username { get; set; }

        public int GameId { get; set; }

        [Required]
        public string Number { get; set; }

        public DateTime DateMade { get; set; }

        public int CowsCount { get; set; }

        public int BullsCount { get; set; }
    }
}
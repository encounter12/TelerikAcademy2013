﻿namespace BullsAndCows.Data
{
    using BullsAndCows.Models;
    using Repositories;
    public interface IBullsAndCowsData
    {
        IRepository<User> Users { get; }

        IRepository<Game> Games { get; }

        IRepository<Guess> Guesses { get; }

        int SaveChanges();

    }
}

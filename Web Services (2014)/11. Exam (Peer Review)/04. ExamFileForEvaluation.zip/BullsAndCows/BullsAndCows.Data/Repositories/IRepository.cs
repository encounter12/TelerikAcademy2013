﻿namespace BullsAndCows.Data.Repositories
{
    using System.Linq;

    public interface IRepository<T> where T : class
    {
        void Add(T entity);

        IQueryable<T> All();

        T Find(object id);

        void Update(T entity);

        T Delete(T entity);

        T Delete(object id);

        int SaveChanges();
    }
}

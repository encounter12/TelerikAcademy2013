﻿namespace BullsAndCows.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Game
    {
        public Game()
        {
            this.State = GameState.WaitingForOpponent;
            this.Guesses = new HashSet<Guess>();
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public GameState State { get; set; }

        public DateTime DateCreated { get; set; }

        [Required]
        public string RedId { get; set; }

        public virtual User Red { get; set; }

        [MinLength(4)]
        [MaxLength(4)]
        public string RedNumber { get; set; }

        public string BlueId { get; set; }

        public virtual User Blue { get; set; }

        [MinLength(4)]
        [MaxLength(4)]
        public string BlueNumber { get; set; }

        public ICollection<Guess> Guesses { get; set; }
    }
}

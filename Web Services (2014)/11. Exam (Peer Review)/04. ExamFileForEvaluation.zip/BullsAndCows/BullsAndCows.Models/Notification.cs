﻿namespace BullsAndCows.Models
{
    using System;

    public class Notification
    {
        public int Id { get; set; }

        public string Content { get; set; }

        public DateTime ExpirationDate { get; set; }
    }
}

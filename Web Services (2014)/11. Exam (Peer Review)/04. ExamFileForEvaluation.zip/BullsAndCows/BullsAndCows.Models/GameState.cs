﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BullsAndCows.Models
{
    public enum GameState
    {
        WaitingForOpponent = 0,
        TurnR = 1,
        TurnB = 2,
        WonByR = 3,
        WonByB = 4,
        Draw = 5
    }
}

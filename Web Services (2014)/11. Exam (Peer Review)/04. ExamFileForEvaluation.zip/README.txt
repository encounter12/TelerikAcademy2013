Don't forget to change '.' in Web.Config in BullsAndCows.Web project to your named instance of SQL Server

And Enable nuget packages restore
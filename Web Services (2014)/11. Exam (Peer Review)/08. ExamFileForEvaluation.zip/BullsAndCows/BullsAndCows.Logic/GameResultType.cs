﻿namespace BullsAndCows.Logic
{
    public enum GameResultType
    {
        NotFinished,
        WonByRed,
        WonByBlue
    }
}
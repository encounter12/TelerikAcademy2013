﻿namespace BullsAndCows.Models
{
    public enum MessageState
    {
        Unread = 0,
        Read = 1
    }
}
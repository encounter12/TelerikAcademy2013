﻿namespace BullsAndCows.Models
{
    public enum MessageType
    {
        GameJoined = 0,
        YourTurn = 1,
        GameLost = 2,
        GameWon = 3
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using BullsAndCows.Data;
using BullsAndCows.Models;
using BullsAndCows.WebApi.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Telerik.JustMock;

namespace BullsAndCows.Tests
{
    [TestClass]
    public class GamesControllerTests
    {
        // No time to Fix the null request object. Got to send this now.. :(

        private readonly IBaCData data;
        private readonly GamesController controller;
        private IQueryable<Game> collection;

        public GamesControllerTests()
        {
            this.Reset();

            this.data = Mock.Create<IBaCData>();
            Mock.Arrange(() => this.data.Games.All()).Returns(this.collection);

            this.controller = new GamesController(this.data);
        }

        [TestMethod]
        public void Get_WithPage_ShouldReturnOkAndNotNullContent()
        {
            HttpResponseMessage result = this.controller.Get(1);

            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
            Assert.IsNotNull(result.Content);
        }

        [TestMethod]
        public void Get_WithoutPage_ShouldReturnOkAndNotNullContent()
        {
            HttpResponseMessage result = this.controller.Get();

            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
            Assert.IsNotNull(result.Content);
        }

        [TestInitialize]
        private void Reset()
        {
            this.collection = new List<Game>()
            {
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 1,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                },
                new Game() 
                { 
                    Id = 2,
                    Name = "Test Name",
                    Red = new ApplicationUser(){UserName = "Username"},
                    GameState = GameState.WaitingForOpponent
                }
            }.AsQueryable();
        }
    }
}

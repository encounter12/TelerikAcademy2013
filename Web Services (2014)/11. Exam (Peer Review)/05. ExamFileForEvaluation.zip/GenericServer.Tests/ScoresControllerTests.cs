﻿using System;
using System.Linq;
using BullsAndCows.Data;
using BullsAndCows.Models;
using BullsAndCows.WebApi.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Telerik.JustMock;
using System.Collections.Generic;

using System.Net.Http;
using System.Web.Http;
using System.Net;

namespace BullsAndCows.Tests
{
    [TestClass]
    public class ScoresControllerTests
    {
        // No time to Fix the null request object. Got to send this now.. :(

        private IBaCData data;
        private ScoresController controller;
        private IQueryable<ApplicationUser> collection;

        public ScoresControllerTests()
        {
            Reset();

            this.data = Mock.Create<IBaCData>();
            Mock.Arrange(() => this.data.Users.All()).Returns(this.collection);

            this.controller = new ScoresController(this.data);
        }

        [TestInitialize]
        private void Reset()
        {
            this.collection = new List<ApplicationUser>() { 
                new ApplicationUser(){Id = "1", UserRank = 1},
                new ApplicationUser(){Id = "2", UserRank = 2},
                new ApplicationUser(){Id = "3", UserRank = 3},
                new ApplicationUser(){Id = "4", UserRank = 4},
                new ApplicationUser(){Id = "5", UserRank = 5}
            }.AsQueryable();
        }

        [TestMethod]
        public void Get_ShouldReturnOkAndNotNullContent()
        {
            HttpResponseMessage result = this.controller.Get();

            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
            Assert.IsNotNull(result.Content);
        }
    }
}

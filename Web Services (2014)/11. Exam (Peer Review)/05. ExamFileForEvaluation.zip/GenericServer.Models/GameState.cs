namespace BullsAndCows.Models
{
    public enum GameState 
    {
        WaitingForOpponent,
        RedInTurn,
        BlueInTurn,
        BlueWon,
        RedWon
    }
}
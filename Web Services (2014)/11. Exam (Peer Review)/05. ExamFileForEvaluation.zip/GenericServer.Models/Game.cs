﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BullsAndCows.Models
{
    public class Game
    {
        private ICollection<Guess> redGuesses;

        private ICollection<Guess> blueGuesses;

        public Game() 
        {
            this.redGuesses = new HashSet<Guess>();
            this.blueGuesses = new HashSet<Guess>();

            this.DateCreated = DateTime.Now;
        }

        public virtual int Id { get; set; }

        [Required]
        [MaxLength(250)]
        public virtual string Name { get; set; }

        [Required]
        public virtual DateTime DateCreated { get; set; }

        public virtual string RedId { get; set; }
        public virtual ApplicationUser Red { get; set; }
        public virtual string BlueId { get; set; }
        public virtual ApplicationUser Blue { get; set; }

        [Required]
        [StringLength(4)]
        public virtual string RedNumber { get; set; }

        [StringLength(4)]
        public virtual string BlueNumber { get; set; }

        public virtual ICollection<Guess> RedGuesses
        {
            get
            {
                return this.redGuesses;
            }
            set
            {
                this.redGuesses = value;
            }
        }

        public virtual ICollection<Guess> BlueGuesses
        {
            get
            {
                return this.blueGuesses;
            }
            set
            {
                this.blueGuesses = value;
            }
        }

        [Required]
        public virtual GameState GameState { get; set; }
    }
}

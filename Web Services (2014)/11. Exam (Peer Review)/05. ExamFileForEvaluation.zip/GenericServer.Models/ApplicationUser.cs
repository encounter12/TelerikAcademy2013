﻿namespace BullsAndCows.Models
{
    using System.Security.Claims;
    using System.Threading.Tasks;

    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.EntityFramework;
    using System.ComponentModel.DataAnnotations;
    
    public class ApplicationUser : IdentityUser
    {
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager, string authenticationType)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, authenticationType);
            // Add custom user claims here
            return userIdentity;
        }

        [Required]
        public virtual int WinsCount { get; set; }

        [Required]
        public virtual int LosesCount { get; set; }

        public void SetUserRank() 
        {
            this.UserRank = 100 * this.WinsCount + 15 * this.LosesCount;
        }

        public int UserRank { get; set; }
    }
}

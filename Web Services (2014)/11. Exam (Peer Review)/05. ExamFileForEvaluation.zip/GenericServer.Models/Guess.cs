using System;
using System.ComponentModel.DataAnnotations;

namespace BullsAndCows.Models
{
    public class Guess
    {
        public Guess() 
        {
            this.DateMade = DateTime.Now;
        }
        public virtual int Id { get; set; }

        [Required]
        public virtual int GameId { get; set; }

        public virtual Game Game { get; set; }

        [Required]
        public virtual string ApplicationUserId { get; set; }

        public virtual ApplicationUser ApplicationUser { get; set; }


        [Required]
        [StringLength(4)]
        public virtual string Number { get; set; }

        [Required]
        public virtual DateTime DateMade { get; set; }

        [Required]
        public virtual int CowsCount { get; set; }

        [Required]
        public virtual int BullsCount { get; set; }
    }
}
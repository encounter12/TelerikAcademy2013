namespace BullsAndCows.Models
{
    public enum NotificationType
    {
        GameJoined,
        YourTurn,
        GameWon,
        GameLost
    }
}
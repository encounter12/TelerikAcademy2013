using System;
using System.ComponentModel.DataAnnotations;

namespace BullsAndCows.Models
{
    public class Notification 
    {
        public Notification()
        {
            this.DateCreated = DateTime.Now;
            this.State = NotificationState.Unread;
        }

        public virtual int Id { get; set; }

        [Required]
        public virtual string Message { get; set; }

        [Required]
        public virtual DateTime DateCreated { get; set; }

        [Required]
        public virtual NotificationType Type { get; set; }

        [Required]
        public virtual NotificationState State { get; set; }

        [Required]
        public virtual int GameId { get; set; }

        public virtual Game Game { get; set; }

        [Required]
        public virtual string ApplicationUserId { get; set; }

        public virtual ApplicationUser ApplicationUser { get; set; }
    }
}
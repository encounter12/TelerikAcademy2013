﻿namespace BullsAndCows.WCF
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.ServiceModel;
    using System.Text;

    using BullsAndCows.Data;
    using BullsAndCows.Models;
    using System.ServiceModel.Activation;
    using System.ServiceModel.Web;
    using BullsAndCows.WCF.Models;

    [AspNetCompatibilityRequirements(RequirementsMode
    = AspNetCompatibilityRequirementsMode.Allowed)]    
    public class Users : IService
    {
        // Fixing the WCF configuration is not an easy thing to do. I'm sending this solution now. If I manage to fix it, I'll send another.

        private const int defaultPageSize = 10;
        private IWcfData data;

        public Users()
        {
            this.data = new WcfData(BaCDbContext.Create());
        }

        public IEnumerable<UserLightModel> Get()
        {
            return this.Get(0);
        }

        public IEnumerable<UserLightModel> Get(int page)
        {
            var result = this.data.Users.All().Select(UserLightModel.FromDbModel).OrderBy(u => u.Username).Skip(page * defaultPageSize).Take(defaultPageSize);
            return result;
        }
        public UserModel GetById(string id)
        {
            var result = this.data.Users.All().Select(UserModel.FromDbModel).FirstOrDefault(u => u.Id == id);

            if (result == null)
            {
                throw new ArgumentOutOfRangeException("There is no user with such Id");
            }

            return result;
        }
    }
}

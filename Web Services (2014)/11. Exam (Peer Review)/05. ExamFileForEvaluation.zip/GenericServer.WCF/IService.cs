﻿using BullsAndCows.Models;
using BullsAndCows.WCF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace BullsAndCows.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IAlertService" in both code and config file together.
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        [WebGet(UriTemplate = "services/users.svc")]
        IEnumerable<UserLightModel> Get();

        [OperationContract]
        [WebGet(UriTemplate = "services/users.svc?page={page}")]
        IEnumerable<UserLightModel> Get(int page);

        [OperationContract]
        [WebGet(UriTemplate = "services/users.svc/{id}")]
        UserModel GetById(string id);
    }
}

using System;
using System.Linq.Expressions;
using BullsAndCows.Models;
using System.ComponentModel.DataAnnotations;

namespace BullsAndCows.WCF.Models
{
    public class UserLightModel
    {
        public static Expression<Func<ApplicationUser, UserLightModel>> FromDbModel
        {
            get
            {
                return item => new UserLightModel()
                {
                    Id = item.Id,
                    Username = item.UserName
                };
            }
        }

        public string Id { get; set; }

        public string Username { get; set; }
    }
}
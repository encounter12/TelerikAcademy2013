using System;
using System.Linq.Expressions;
using BullsAndCows.Models;

namespace BullsAndCows.WCF.Models
{
    public class UserModel
    {
        public static Expression<Func<ApplicationUser, UserModel>> FromDbModel
        {
            get
            {
                return item => new UserModel()
                {
                    Id = item.Id,
                    Username = item.UserName,
                    Loses = item.LosesCount,
                    Wins = item.WinsCount,
                    Rank = item.UserRank
                };
            }
        }

        public string Id { get; set; }

        public string Username { get; set; }

        public int Loses { get; set; }

        public int Wins { get; set; }

        public int Rank { get; set; }
    }
}
using System;
using System.Linq.Expressions;
using BullsAndCows.Models;

namespace BullsAndCows.Web.Models
{
    public class GuessModel
    {
        public static Expression<Func<Guess, GuessModel>> FromDbModel
        {
            get
            {
                return item => new GuessModel()
                {
                    Id = item.Id,
                    UserId = item.ApplicationUserId,
                    Username = item.ApplicationUser.UserName,
                    GameId = item.GameId,
                    Number = item.Number,
                    DateMade = item.DateMade,
                    CowsCount = item.CowsCount,
                    BullsCount = item.BullsCount
                };
            }
        }

        public int Id { get; set; }

        public string UserId { get; set; }

        public string Username { get; set; }

        public int GameId { get; set; }

        public string Number { get; set; }

        public DateTime DateMade { get; set; }

        public int CowsCount { get; set; }

        public int BullsCount { get; set; }
    }
}
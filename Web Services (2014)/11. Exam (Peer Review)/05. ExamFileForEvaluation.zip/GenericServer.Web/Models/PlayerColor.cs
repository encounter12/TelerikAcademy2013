namespace BullsAndCows.Web.Models
{
    public enum PlayerColor
    {
        red,
        blue
    }
}
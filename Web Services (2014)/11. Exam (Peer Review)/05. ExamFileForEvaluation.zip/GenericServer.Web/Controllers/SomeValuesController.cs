﻿namespace BullsAndCows.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Http;

    using Microsoft.AspNet.Identity;

    using BullsAndCows.Data;
    using BullsAndCows.Models;
    using BullsAndCows.Web.Models;

    public class SomeValuesController : BaseApiController
    {
        private int pageSize = 10;
        public SomeValuesController(IBaCData data)
            : base(data)
        {
        }

        [HttpGet]
        public IHttpActionResult Get()
        {
            return this.Get(0);
        }

        [HttpGet]
        public IHttpActionResult Get(int page)
        {
            var results = this.OrderedGames(this.data.Games.All())
                .Select(GameLightModel.FromDbModel)
                .Skip(page * pageSize)
                .Take(pageSize);
            return Ok(results);
        }

        [HttpGet]
        [Authorize]
        public IHttpActionResult Details(int id)
        {
            var result = id;
            return Ok(result);
        }


        [HttpPost]
        [Authorize]
        public IHttpActionResult Create(GamePostModel model)
        {
            // add it
            return Ok(model);
        }

        private IQueryable<Game> OrderedGames(IQueryable<Game> games)
        {
            //•	By game state
            //•	Then by the name of the game
            //•	Then by the date of creation
            //•	Then by the name of the red player
            return games.OrderBy(g => g.GameState).ThenBy(g => g.Name).ThenBy(g => g.DateCreated).ThenBy(g => g.Red.UserName);
        }
    }
}
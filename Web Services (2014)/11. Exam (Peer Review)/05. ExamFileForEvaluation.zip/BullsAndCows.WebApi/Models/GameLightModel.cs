using System;
using System.Linq.Expressions;
using BullsAndCows.Models;
using System.ComponentModel.DataAnnotations;

namespace BullsAndCows.WebApi.Models
{
    public class GameLightModel
    {
        public static Expression<Func<Game, GameLightModel>> FromDbModel
        {
            get
            {
                return item => new GameLightModel()
                {
                    Id = item.Id,
                    Name = item.Name,
                    Red = item.Red.UserName,
                    Blue = item.Blue != null ? item.Blue.UserName : "No blue player yet",
                    GameState = item.GameState.ToString(),
                    DateCreated = item.DateCreated
                };
            }
        }

        public static GameLightModel MakeFromDbModel(Game item) 
        {
            return new GameLightModel()
            {
                Id = item.Id,
                Name = item.Name,
                Red = item.Red.UserName,
                Blue = item.Blue != null ? item.Blue.UserName : "No blue player yet",
                GameState = item.GameState.ToString(),
                DateCreated = item.DateCreated
            };
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Red { get; set; }

        public string Blue { get; set; }

        public string GameState { get; set; }

        public DateTime DateCreated { get; set; }
    }
}
namespace BullsAndCows.WebApi.Models
{
    public class GuessPostModel
    {
        public string number { get; set; }
    }
}
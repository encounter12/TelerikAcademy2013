﻿using BullsAndCows.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace BullsAndCows.WebApi.Models
{
    public class GameModel
    {
        public static GameModel MakeForCurrentPlayer(Game item, PlayerColor currentPlayerColor)
        {
            var result = new GameModel()
            {
                Id = item.Id,
                Name = item.Name,
                Red = item.Red.UserName,
                Blue = item.Blue != null ? item.Blue.UserName : "No blue player yet",
                GameState = item.GameState.ToString(),
                DateCreated = item.DateCreated,
                YourColor = currentPlayerColor.ToString()
            };

            if (result.YourColor.Equals(PlayerColor.red.ToString()))
            {
                result.YourGuesses = item.RedGuesses.Select(GuessModel.FromDbModel.Compile());
                result.OpponentGuesses = item.BlueGuesses.Select(GuessModel.FromDbModel.Compile());
                result.YourNumber = item.RedNumber;
            }
            else
            {
                result.YourGuesses = item.BlueGuesses.Select(GuessModel.FromDbModel.Compile());
                result.OpponentGuesses = item.RedGuesses.Select(GuessModel.FromDbModel.Compile());
                result.YourNumber = item.BlueNumber;
            }

            return result;
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Red { get; set; }

        public string Blue { get; set; }

        public string GameState { get; set; }

        public DateTime DateCreated { get; set; }

        public string YourNumber { get; set; }

        public IEnumerable<GuessModel> YourGuesses { get; set; }
        public IEnumerable<GuessModel> OpponentGuesses { get; set; }

        public string YourColor { get; set; }
    }
}
using System;
using System.Linq.Expressions;
using BullsAndCows.Models;

namespace BullsAndCows.WebApi.Models
{
    public class NotificationModel
    {
        public static Expression<Func<Notification, NotificationModel>> FromDbModel
        {
            get
            {
                return item => new NotificationModel()
                {
                    Id = item.Id,
                    Message = item.Message,
                    DateCreated = item.DateCreated,
                    Type = item.Type.ToString(),
                    State = item.State.ToString(),
                    GameId = item.GameId
                };
            }
        }

        public int Id { get; set; }

        public string Message { get; set; }

        public DateTime DateCreated { get; set; }

        public string Type { get; set; }

        public string State { get; set; }

        public int GameId { get; set; }
    }
}
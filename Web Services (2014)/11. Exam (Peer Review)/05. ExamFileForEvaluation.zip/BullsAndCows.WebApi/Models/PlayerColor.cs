namespace BullsAndCows.WebApi.Models
{
    public enum PlayerColor
    {
        red,
        blue
    }
}
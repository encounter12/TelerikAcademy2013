using System;
using System.Linq.Expressions;
using BullsAndCows.Models;

namespace BullsAndCows.WebApi.Models
{
    class UserRankingModel
    {
        public static Expression<Func<ApplicationUser, UserRankingModel>> FromDbModel
        {
            get
            {
                return item => new UserRankingModel()
                {
                    Username = item.UserName,
                    Rank = item.UserRank
                };
            }
        }

        public string Username { get; set; }

        public int Rank { get; set; }
    }
}
using System.ComponentModel.DataAnnotations;
using BullsAndCows.Models;

namespace BullsAndCows.WebApi.Models
{
    public class GamePostModel 
    {
        public Game ToDbModel(ApplicationUser creator)
        {
            return new Game()
            {
                Name = this.name,
                Red = creator,
                RedId = creator.Id,
                RedNumber = this.number,
                GameState = GameState.WaitingForOpponent
            };
        }

        [Required]
        [MaxLength(250)]
        public string number { get; set; }

        [Required]
        [StringLength(4)]
        public string name { get; set; }
    }
}
﻿using BullsAndCows.Data;
using BullsAndCows.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BullsAndCows.WebApi.Controllers
{
    public class ScoresController : BaseApiController
    {
        public ScoresController(IBaCData data)
            : base(data)
        {
        }

        public HttpResponseMessage Get()
        {
            var result = this.data.Users.All().Select(UserRankingModel.FromDbModel).OrderByDescending(u => u.Rank).Take(10);
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }
    }
}

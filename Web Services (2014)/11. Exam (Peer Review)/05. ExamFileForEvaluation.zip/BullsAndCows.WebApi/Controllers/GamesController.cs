﻿namespace BullsAndCows.WebApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Web.Http;
    using BullsAndCows.WebApi.Validators;
    using Microsoft.AspNet.Identity;
    using BullsAndCows.Data;
    using BullsAndCows.Models;
    using BullsAndCows.WebApi.Models;
    using System.Threading;
    using System.Net;

    public class GamesController : BaseApiController
    {
        private static Random rnd = new Random();
        private const int pageSize = 10;
        public GamesController(IBaCData data)
            : base(data)
        {
        }

        [HttpGet]
        public HttpResponseMessage Get()
        {
            return this.Get(0);
        }

        /// <summary>
        /// this method is used by both autenticated and non autenticated users, and does a different thing, depending on who uses it
        /// </summary>
        [HttpGet]
        public HttpResponseMessage Get(int page)
        {
            var games = this.data.Games.All().Where(g =>
                    (g.GameState != GameState.BlueWon) &&
                    (g.GameState != GameState.RedWon));

            games = this.OrderGames(games);

            if (!Thread.CurrentPrincipal.Identity.IsAuthenticated)
            {
                games = games.Where(g => g.GameState == GameState.WaitingForOpponent);
            }
            else
            {
                var userId = Thread.CurrentPrincipal.Identity.GetUserId();
                games = games.Where(g => 
                    g.GameState == GameState.WaitingForOpponent ||
                    g.Red.Id == userId ||
                    g.Blue.Id == userId);
            }

            var results = games
                .Select(GameLightModel.FromDbModel)
                .Skip(page * pageSize)
                .Take(pageSize);

            return Request.CreateResponse(HttpStatusCode.OK, results);
        }

        [HttpGet]
        [Authorize]
        [Route("api/games/{id}")]
        public IHttpActionResult Details(int id)
        {
            var game = this.data.Games.All().FirstOrDefault(g => g.Id == id);
            if (game == null)
            {
                return NotFound();
            }
            var userId = Thread.CurrentPrincipal.Identity.GetUserId();
            if (game.Red.Id != userId && game.Blue.Id != userId)
            {
                return Unauthorized();
            }

            if (game.Red.Id == userId)
            {
                return Ok(GameModel.MakeForCurrentPlayer(game, PlayerColor.red));
            }
            else
            {
                return Ok(GameModel.MakeForCurrentPlayer(game, PlayerColor.blue));
            }
        }


        [HttpPost]
        [Authorize]
        [Route("api/games/{id}")]
        public IHttpActionResult Create(GamePostModel model)
        {
            if (!new BullsAndCowsValidator().CheckNumberValid(model.number))
            {
                return BadRequest("The number is not valid. It must have 4 different digits, and 4 digits only.");
            }

            if (this.data.Games.All()
                .Where(g => 
                    (g.GameState != GameState.BlueWon) && 
                    (g.GameState != GameState.RedWon))
                .FirstOrDefault(g => g.Name == model.name) != null)
            {
                return BadRequest("An unfinished game with that name already exists.");
            }
            var userId = Thread.CurrentPrincipal.Identity.GetUserId();
            var user = this.data.Users.All().FirstOrDefault(u => u.Id == userId);
            var game = model.ToDbModel(user);

            this.data.Games.Add(game);
            this.data.SaveChanges();

            var gameFromDb = this.data.Games.All().FirstOrDefault(g => g.Id == game.Id);
            return Created<GameLightModel>("/api/games/" + game.Id, GameLightModel.MakeFromDbModel(gameFromDb));
        }

        [HttpPut]
        [Authorize]
        [Route("api/games/{id}")]
        public IHttpActionResult Join(int id) 
        {
            var game = this.data.Games.All().FirstOrDefault(g => g.Id == id);

            if (game == null)
            {
                return NotFound();
            }

            if (game.GameState != GameState.WaitingForOpponent)
            {
                return BadRequest("Game is not open for joining.");
            }

            var userId = Thread.CurrentPrincipal.Identity.GetUserId();

            if (game.RedId == userId)
            {
                return BadRequest("You can not join your own game");
            }

            game.BlueId = userId;
            game.Blue = this.data.Users.All().FirstOrDefault(u => u.Id == userId);


            this.data.Notifications.Add(new Notification()
            {
                Game = game,
                State = NotificationState.Unread,
                Type = NotificationType.GameJoined,
                ApplicationUserId = game.Red.Id,
                Message = game.Blue.UserName + " joined your game \"" + game.Name + "\""
            });

            string userInTurnId;
            if (rnd.Next()%2==0)
            {
                game.GameState = GameState.RedInTurn;
                userInTurnId = game.RedId;
            }
            else
            {
                game.GameState = GameState.BlueInTurn;
                userInTurnId = game.BlueId;
            }

            this.data.Notifications.Add(new Notification()
            {
                Game = game,
                State = NotificationState.Unread,
                Type = NotificationType.YourTurn,
                ApplicationUserId = userInTurnId,
                Message = "It is your turn in game \"" + game.Name + "\""
            });

            this.data.SaveChanges();

            return Ok("You joined game \"" + game.Name + "\"");
        }

        [HttpPost]
        [Authorize]
        [Route("api/games/{id}/guess")]
        public IHttpActionResult Guess(int id, GuessPostModel guessModel)
        {
            string number = guessModel.number;

            var game = this.data.Games.All().FirstOrDefault(g => g.Id == id);

            if (game == null)
            {
                return NotFound();
            }

            var userId = Thread.CurrentPrincipal.Identity.GetUserId();

            if (game.RedId != userId && game.BlueId != userId)
            {
                return BadRequest("This is not your game");
            }

            if (game.GameState != GameState.RedInTurn || game.GameState != GameState.BlueInTurn)
            {
                return BadRequest("This game is not being played right now.");
            }

            if ((game.GameState != GameState.RedInTurn && game.RedId == userId) ||
                (game.GameState != GameState.BlueInTurn && game.BlueId == userId))
            {
                return BadRequest("It is not your turn");
            }

            var validator = new BullsAndCowsValidator();
            if (!validator.CheckNumberValid(number))
            {
                return BadRequest("Invalid guess number");
            }

            string actual;
            if (game.GameState != GameState.RedInTurn)
            {
                actual = game.BlueNumber;
            }
            else
            {
                actual = game.RedNumber;
            }

            var guess = new Guess()
            {
                ApplicationUserId = userId,
                GameId = game.Id,
                Number = number,
                BullsCount = validator.CountBulls(actual, number),
                CowsCount = validator.CountCows(actual, number)
            };

            bool gameWon = guess.BullsCount == 4;

            if (game.GameState != GameState.RedInTurn)
            {
                game.RedGuesses.Add(guess);
                if (gameWon)
                {
                    this.HandleGameOver(game, game.Red, game.Blue, PlayerColor.red);
                }
                else
                {
                    game.GameState = GameState.BlueInTurn;
                }
            }
            else
            {
                game.BlueGuesses.Add(guess);
                if (gameWon)
                {
                    this.HandleGameOver(game, game.Blue, game.Red, PlayerColor.blue);
                }
                else
                {
                    game.GameState = GameState.RedInTurn;
                }
            }


            this.data.SaveChanges();
            GuessModel model = GuessModel.MakeFromDbModel(guess);
            return Ok(model);
        }

        private void HandleGameOver(Game game, ApplicationUser winner, ApplicationUser loser, PlayerColor winnerColor)
        {
            switch (winnerColor)
            {
                case PlayerColor.red:
                    game.GameState = GameState.RedWon;
                    break;
                case PlayerColor.blue:
                    game.GameState = GameState.BlueWon;
                    break;
                default:
                    break;
            }

            winner.WinsCount++;
            loser.LosesCount++;

            winner.SetUserRank();
            loser.SetUserRank();

            this.data.Notifications.Add(new Notification()
            {
                Game = game,
                State = NotificationState.Unread,
                Type = NotificationType.GameWon,
                ApplicationUserId = winner.Id,
                Message = "You beat " + loser.UserName + " in game \"" + game.Name + "\""
            });

            this.data.Notifications.Add(new Notification()
            {
                Game = game,
                State = NotificationState.Unread,
                Type = NotificationType.GameLost,
                ApplicationUserId = loser.Id,
                Message = "You were beaten by " + winner.UserName + " in game \"" + game.Name + "\""
            });
        }

        private IQueryable<Game> OrderGames(IQueryable<Game> games)
        {
            //•	By game state
            //•	Then by the name of the game
            //•	Then by the date of creation
            //•	Then by the name of the red player
            return games.OrderBy(g => g.GameState).ThenBy(g => g.Name).ThenBy(g => g.DateCreated).ThenBy(g => g.Red.UserName);
        }
    }
}
﻿using BullsAndCows.Data;
using BullsAndCows.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Web.Http;
using Microsoft.AspNet.Identity;
using BullsAndCows.Models;

namespace BullsAndCows.WebApi.Controllers
{
    public class NotificationsController : BaseApiController
    {
        private const int pageSize = 10;

        public NotificationsController(IBaCData data)
            : base(data)
        {
        }

        [Authorize]
        public IHttpActionResult Get()
        {
            return this.Get(0);
        }

        [Authorize]
        public IHttpActionResult Get(int page)
        {
            var userId = Thread.CurrentPrincipal.Identity.GetUserId();

            var notifications = this.data.Notifications.All()
                .Where(n => n.ApplicationUserId == userId)
                .OrderBy(u => u.DateCreated)
                             .Skip(page * pageSize)
                             .Take(pageSize);

            var result = notifications.Select(NotificationModel.FromDbModel);

            foreach (var not in notifications)
            {
                not.State = NotificationState.Read;
            }

            return Ok(result);
        }

        [Authorize]
        [Route("api/notifications/next")]
        [HttpGet]
        public HttpResponseMessage GetNext()
        {
            var userId = Thread.CurrentPrincipal.Identity.GetUserId();
            var notification = this.data.Notifications.All()
                .Where(n => n.ApplicationUserId == userId)
                .Where(n => n.State == NotificationState.Unread)
                .OrderBy(u => u.DateCreated)
                .Take(1);

            var result = notification.Select(NotificationModel.FromDbModel).FirstOrDefault();

            if (result == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotModified);
            }
            else
            {
                notification.FirstOrDefault().State = NotificationState.Read;
                this.data.SaveChanges();
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
        }
    }
}

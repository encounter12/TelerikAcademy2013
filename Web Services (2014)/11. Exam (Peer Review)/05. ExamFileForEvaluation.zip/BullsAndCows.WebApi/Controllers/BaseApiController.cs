﻿namespace BullsAndCows.WebApi.Controllers
{
    using BullsAndCows.Data;

    using System;
    using System.Web;
    using System.Web.Http;

    public class BaseApiController : ApiController
    {
        protected IBaCData data;

        public BaseApiController(IBaCData data)
        {
            this.data = data;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BullsAndCows.WebApi.Validators
{
    public class BullsAndCowsValidator
    {
        private const int sizeOfNumber = 4;

        public bool CheckNumberValid(string number) 
        {
            if (number.Length != sizeOfNumber)
            {
                return false;
            }

            int[] arr = new int[10];

            foreach (char digit in number)
            {
                if (!char.IsDigit(digit))
                {
                    return false;
                }
                int index = int.Parse(digit.ToString());
                arr[index]++;
                if (arr[index] > 1)
                {
                    return false;
                }
            }

            return true;
        }

        public int CountBulls(string actual, string guess)
        {
            int bulls = 0;
            for (int i = 0; i < sizeOfNumber; i++)
            {
                if (actual[i] == guess[i])
                {
                    bulls++;
                }
            }
            return bulls;
        }

        public int CountCows(string actual, string guess)
        {
            int cows = 0;
            for (int ai = 0; ai < sizeOfNumber; ai++)
            {
                for (int gi = 0; gi < sizeOfNumber; gi++)
                {
                    if (ai == gi)
                    {
                        continue;
                    }
                    if (actual[ai] == guess[gi])
                    {
                        cows++;
                    }
                }
            }
            return cows;
        }

    }
}
﻿namespace BullsAndCows.Data
{
    using BullsAndCows.Data.Repositories;
    using BullsAndCows.Models;

    public interface IBaCData
    {
        IRepository<Game> Games { get; }
        IRepository<Guess> Guesses { get; }
        IRepository<Notification> Notifications { get; }
        IRepository<ApplicationUser> Users { get; }
        int SaveChanges();
    }
}

﻿namespace BullsAndCows.Data
{
    using BullsAndCows.Data.Repositories;
    using BullsAndCows.Models;

    public interface IWcfData
    {
        IRepository<ApplicationUser> Users { get; }
        int SaveChanges();
    }
}

﻿namespace BullsAndCows.Data
{
    using System.Data.Entity;

    using Microsoft.AspNet.Identity.EntityFramework;

    using BullsAndCows.Models;
    using BullsAndCows.Data.Migrations;

    public class BaCDbContext : IdentityDbContext<ApplicationUser>
    {
        public BaCDbContext()
            : base("BullsAndCows", throwIfV1Schema: false)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<BaCDbContext, Configuration>());
        }

        public static BaCDbContext Create()
        {
            return new BaCDbContext();
        }

        public DbSet<Game> Games { get; set; }
        public DbSet<Guess> Guesses { get; set; }
        public DbSet<Notification> Notifications { get; set; }

        public override IDbSet<ApplicationUser> Users
        {
            get
            {
                return base.Users;
            }
            set
            {
                base.Users = value;
            }
        }

        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
        //{
        //    /*
        //        An exception of type 'System.Data.SqlClient.SqlException' occurred in EntityFramework.dll but was not handled in user code
        //        Additional information: Introducing FOREIGN KEY constraint 'FK_dbo.Guesses_dbo.Games_GameId'
        //        on table 'Guesses' may cause cycles or multiple cascade paths. Specify ON DELETE NO ACTION or 
        //        ON UPDATE NO ACTION, or modify other FOREIGN KEY constraints.
        //        Could not create constraint. See previous errors.
        //     */

        //    // deliting game wont delete guesses
        //    modelBuilder.Entity<Game>()
        //        .HasMany(p => p.RedGuesses)
        //        .WithRequired()
        //        .HasForeignKey(c => c.ApplicationUserId)
        //        .WillCascadeOnDelete(false);

        //    // deliting game wont delete guesses
        //    modelBuilder.Entity<Game>()
        //        .HasMany(p => p.BlueGuesses)
        //        .WithRequired()
        //        .HasForeignKey(c => c.ApplicationUserId)
        //        .WillCascadeOnDelete(false);

        //    base.OnModelCreating(modelBuilder);
        //}
    }
}

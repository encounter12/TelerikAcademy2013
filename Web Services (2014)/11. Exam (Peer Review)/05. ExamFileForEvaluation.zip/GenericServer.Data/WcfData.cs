﻿namespace BullsAndCows.Data
{
    using System;
    using System.Collections.Generic;

    using BullsAndCows.Data.Repositories;
    using BullsAndCows.Models;

    public class WcfData : IWcfData
    {
        private BaCDbContext context;
        private IDictionary<Type, object> repositories;

        public WcfData(BaCDbContext context)
        {
            this.context = context;
            this.repositories = new Dictionary<Type, object>();
        }

        private IRepository<T> GetRepository<T>() where T : class
        {
            var typeOfRepository = typeof(T);
            if (!this.repositories.ContainsKey(typeOfRepository))
            {
                var newRepository = Activator.CreateInstance(typeof(Repository<T>), context);
                this.repositories.Add(typeOfRepository, newRepository);
            }

            return (IRepository<T>)this.repositories[typeOfRepository];
        }

        public int SaveChanges()
        {
            return this.context.SaveChanges();
        }

        public IRepository<ApplicationUser> Users
        {
            get { return this.GetRepository<ApplicationUser>(); }
        }
    }
}

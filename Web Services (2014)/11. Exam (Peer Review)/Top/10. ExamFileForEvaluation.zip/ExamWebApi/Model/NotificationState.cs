﻿namespace Model
{
    public enum NotificationState
    {
        Unread = 0,
        Read=1
    }
}

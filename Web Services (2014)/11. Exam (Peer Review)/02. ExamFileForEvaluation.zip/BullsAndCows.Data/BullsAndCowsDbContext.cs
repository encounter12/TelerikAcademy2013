﻿namespace BullsAndCows.Data
{
    using System.Data.Entity;

    using BullsAndCows.Models;
    using BullsAndCows.Data.Migrations;

    using Microsoft.AspNet.Identity.EntityFramework;

    public class BullsAndCowsDbContext : IdentityDbContext<User>
    {
        public BullsAndCowsDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<BullsAndCowsDbContext, Configuration>());
        }

        public static BullsAndCowsDbContext Create()
        {
            return new BullsAndCowsDbContext();
        }

        public virtual IDbSet<Game> Games { get; set; }

        public virtual IDbSet<Notification> Notifications { get; set; }
    }
}

﻿namespace BullsAndCows.WebApi.DataModels
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    
    public class JoinGameModel
    {
        public string Number { get; set; }
    }
}
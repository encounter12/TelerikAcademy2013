﻿namespace BullsAndCows.WebApi.Models
{
    public class GameCreateModel
    {
        public string Name { get; set; }
        public string Number { get; set; }
    }
}
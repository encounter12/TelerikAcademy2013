﻿namespace BullsAndCows.WebApi.Infrastructure
{
    public interface IUserIdProvider
    {
        string GetUserId();
    }
}

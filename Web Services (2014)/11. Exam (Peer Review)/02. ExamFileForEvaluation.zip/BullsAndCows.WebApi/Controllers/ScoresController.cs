﻿namespace BullsAndCows.WebApi.Controllers
{
    using BullsAndCows.Data;
    using System.Web.Http;

    public class ScoresController : ApiController
    {
        private IBullsAndCowsData data;
        // Get all scores
        [HttpGet]
        public IHttpActionResult Get()
        {
            var allUsers = this.data.Users.All();
            return Ok();
        }
    }
}
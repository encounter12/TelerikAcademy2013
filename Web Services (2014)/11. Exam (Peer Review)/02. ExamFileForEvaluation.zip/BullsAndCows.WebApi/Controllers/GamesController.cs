﻿namespace BullsAndCows.WebApi.Controllers
{
    using System.Linq;
    using Microsoft.AspNet.Identity;

    using BullsAndCows.Data;
    using BullsAndCows.GameLogic;
    using BullsAndCows.Models;
    using BullsAndCows.WebApi.Infrastructure;
    using BullsAndCows.WebApi.Models;
    using System;
    using System.Web.Http;
    using BullsAndCows.WebApi.DataModels;
        
    public class GamesController : ApiController
    {
        private IBullsAndCowsData data;
        private IGameResultValidator resultValidator;
        private IUserIdProvider userIdProvider;

        public GamesController(IBullsAndCowsData data)
        {
            this.data = data;
        }

        public GamesController()
            : this(new BullsAndCowsData(new BullsAndCowsDbContext()))
        {
        }

        public GamesController(
             IBullsAndCowsData data,
             IGameResultValidator resultValidator,
             IUserIdProvider userIdProvider)
            : this(data)
        {
            this.resultValidator = resultValidator;
            this.userIdProvider = userIdProvider;
        }

        // Get all games - not authorized - WITHOUT paging
        [HttpGet]
        public IHttpActionResult GetAll(int page)
        {
            var availableGames = this.data.Games
                .All()
                .Where(game => game.State == GameState.WaitingForOpponent)
                .Select(g => new GameCreatedTemplate
                {
                    Id = g.Id,
                    Name = g.Name,
                    Blue = "No blue player yet",
                    Red = g.FirstPlayer.UserName,
                    GameState = ((GameState)g.State).ToString(),
                    DateCreated = g.DateCreated
                })
                .OrderBy(game => game.Name)
                .ThenBy(game => game.DateCreated)
                .ThenBy(game => game.Red)
                .Skip(10 * page)
                .Take(10);

            return Ok(availableGames);
        }

        //// Get all games - not authorized - WITH paging
        //[Authorize]
        //[HttpGet]
        //public IHttpActionResult GetAuthenticated()
        //{
        //    var currentUserId = this.User.Identity.GetUserId();

        //    var availableGames = this.data.Games
        //        .All()
        //        .Where(game => game.State == GameState.WaitingForOpponent
        //            || game.FirstPlayerId == currentUserId
        //            || game.SecondPlayerId == currentUserId)
        //        .Select(g => new GameCreatedTemplate
        //        {
        //            Id = g.Id,
        //            Name = g.Name,
        //            Blue = "No blue player yet",
        //            Red = g.FirstPlayer.UserName,
        //            GameState = ((GameState)g.State).ToString(),
        //            DateCreated = g.DateCreated
        //        })
        //        .OrderBy(game => game.Name)
        //        .ThenBy(game => game.DateCreated)
        //        .ThenBy(game => game.Red)
        //        .Take(10);

        //    return Ok(availableGames);
        //}

        // Get all games - not authorized - WITH paging
        [HttpGet]
        public IHttpActionResult Get()
        {
            var availableGames = this.data.Games
                .All()
                .Where(game => game.State == GameState.WaitingForOpponent)
                .Select(g => new GameCreatedTemplate
                {
                    Id = g.Id,
                    Name = g.Name,
                    Blue = "No blue player yet",
                    Red = g.FirstPlayer.UserName,
                    GameState = ((GameState)g.State).ToString(),
                    DateCreated = g.DateCreated
                })
                .OrderBy(game => game.Name)
                .ThenBy(game => game.DateCreated)
                .ThenBy(game => game.Red)
                .Take(10);
                
            return Ok(availableGames);
        }

        

        // Creating a valid game - must be logged in
        [HttpPost]
        [Authorize]
        public IHttpActionResult Create(GameCreateModel game)
        {
            var currentUserId = this.User.Identity.GetUserId();

            var newGame = new Game
            {
                DateCreated = DateTime.Now,
                InitialNumber = game.Number,
                Name = game.Name,
                FirstPlayerId = currentUserId,
                FirstPlayer = this.data.Users.All().Where(u => u.Id == currentUserId).FirstOrDefault()
            };            

            this.data.Games.Add(newGame);
            this.data.SaveChanges();

            // Create some kind of view model
            var resultGame = new GameCreatedTemplate
            {
               Id = newGame.Id,
               Name = newGame.Name,
               Blue = "No blue player yet",
               Red = this.data.Users.All().Where( u => u.Id == currentUserId).FirstOrDefault().UserName,
               GameState = ((GameState)newGame.State).ToString(),
               DateCreated = newGame.DateCreated
            };

            return Created("http://localhost:4658/api/games", resultGame);
        }

        // Join a game request - must be authorized
        [Authorize]
        [HttpPut]
        public IHttpActionResult Join(int id, [FromBody]JoinGameModel newNumber)
        {
            var currentUserId = this.User.Identity.GetUserId();

            var game = this.data.Games
                .All()
                .Where(g => g.State == GameState.WaitingForOpponent 
                    && g.FirstPlayerId != currentUserId 
                    && g.Id == id)
                .FirstOrDefault();

            if (game == null)
            {
                return BadRequest("Not a valid game or already in it!");
            }

            game.SecondPlayerId = currentUserId;
            game.SecondPlayer = this.data.Users.All().Where(u => u.Id == currentUserId).FirstOrDefault();
            game.GuessNumber = newNumber.Number;

            // Make a random turn generator to decide turns on game join
            Random r = new Random();
            int rInt = r.Next(1, 3);
            if (rInt == 1)
            {
                game.State = GameState.TurnRed;
            }
            else
            {
                game.State = GameState.TurnBlue;
            }

            var resultBody = new
            {
                result = @"You joined game \" + "\"" + game.Name + @"\" + "\""
            };

            var newNotification = new Notification()
            {
                Message = "It is your turn in game " + resultBody.result,
                DateCreated = DateTime.Now,
                Type = rInt == 1 ? GameState.TurnBlue : GameState.TurnRed,
                State = NotificationState.Unread,
                GameID = game.Id
            };

            if(rInt == 1)
            {
                game.FirstPlayer.Notifications.Add(newNotification);
            }
            else
            {
                game.SecondPlayer.Notifications.Add(newNotification);
            }
                        
            this.data.SaveChanges();

            return Ok(resultBody);
        }
    }
}
﻿namespace BullsAndCows.WebApi.Controllers
{
    using BullsAndCows.Data;
    using System.Web.Http;

    public abstract class BaseApiController : ApiController
    {
        public IBullsAndCowsData data;

        public BaseApiController(IBullsAndCowsData data)
        {
            this.data = data;
        }
    }
}
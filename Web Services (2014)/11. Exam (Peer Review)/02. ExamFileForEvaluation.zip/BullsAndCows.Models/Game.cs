﻿namespace BullsAndCows.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Game
    {
        public Game()
        {
            this.State = GameState.WaitingForOpponent;
            this.Notifications = new HashSet<Notification>();
        }

        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        [StringLength(4)]
        [MinLength(4)]
        public string InitialNumber { get; set; }

        [StringLength(4)]
        [MinLength(4)]
        public string GuessNumber { get; set; }

        public GameState State { get; set; }

        public DateTime DateCreated { get; set; }

        [Required]
        public string FirstPlayerId { get; set; }

        public virtual User FirstPlayer { get; set; }
                
        public string SecondPlayerId { get; set; }

        public virtual User SecondPlayer { get; set; }

        public virtual ICollection<Notification> Notifications { get; set; }
    }
}

﻿using System;
namespace BullsAndCows.Models
{
    public class Notification
    {
        public int Id { get; set; }

        public string Message { get; set; }

        public DateTime DateCreated { get; set; }

        public NotificationState State { get; set; }

        public GameState Type { get; set; }

        public string UserId { get; set; }

        public int GameID { get; set; }

        public virtual Game Game { get; set; }

        public virtual User User { get; set; }
    }
}

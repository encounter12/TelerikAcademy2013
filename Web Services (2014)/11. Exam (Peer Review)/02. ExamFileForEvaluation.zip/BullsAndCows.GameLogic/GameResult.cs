﻿namespace BullsAndCows.GameLogic
{
    public enum GameResult
    {
        NotFinished,
        Won,
        Lost
    }
}

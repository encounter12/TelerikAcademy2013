﻿namespace BullsAndCows.GameLogic
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class GameResultValidator : IGameResultValidator
    {
        //TODO: Implement game logic
        private const int MAX_NUMBER_LENGTH = 4;

        public int CheckBullsCount(string searchNumber, string guessNumber)
        {
            int bullCount = 0;

            for (int i = 0; i < MAX_NUMBER_LENGTH; i++)
            {
                if(searchNumber[i] == guessNumber[i])
                {
                    bullCount++;
                }
            }

            return bullCount;
        }

        public int CheckCowsCount(string searchNumber, string guessNumber)
        {
            int cowsCount = 0;
            int currentNumber;

            for (int i = 0; i < MAX_NUMBER_LENGTH; i++)
            {
                currentNumber = guessNumber[i];
                for (int j = 0; j < MAX_NUMBER_LENGTH; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }
                    else
                    {
                        if (currentNumber == guessNumber[j])
                        {
                            cowsCount++;
                        }
                    }
                }
            }

            return cowsCount;
        }

        public GameResult GetResult(string game, string searchNumber, string guessNumber)
        {
            if (CheckBullsCount(searchNumber, guessNumber) == 4)
            {
                return GameResult.Won;
            }
            else
            {
                return GameResult.NotFinished;
            }
        }
    }
}

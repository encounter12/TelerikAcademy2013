﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BullsAndCows.GameLogic
{
    public interface IGameResultValidator
    {
        int CheckCowsCount(string searchNumber, string guessNumber);
        int CheckBullsCount(string searchNumber, string guessNumber);
        GameResult GetResult(string game, string searchNumber, string guessNumber);
    }
}

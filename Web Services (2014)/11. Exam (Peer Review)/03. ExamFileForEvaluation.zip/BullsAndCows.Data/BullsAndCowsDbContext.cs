﻿namespace BullsAndCows.Data
{
    using System.Data.Entity;
    using BullsAndCows.Data.Migrations;
    using BullsAndCows.Models;
    using Microsoft.AspNet.Identity.EntityFramework;

    public class BullsAndCowsDbContext : IdentityDbContext<BullsAndCowsUser>
    {
        public BullsAndCowsDbContext() : base("BullsAndCowsConnectionString", throwIfV1Schema: false)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<BullsAndCowsDbContext, Configuration>());
        }

        public IDbSet<Game> Games { get; set; }

        public IDbSet<Guess> Guesses { get; set; }

        public IDbSet<Score> Scores { get; set; }

        public IDbSet<Notification> Notifications { get; set; }

        public static BullsAndCowsDbContext Create()
        {
            return new BullsAndCowsDbContext();
        }
    }
}
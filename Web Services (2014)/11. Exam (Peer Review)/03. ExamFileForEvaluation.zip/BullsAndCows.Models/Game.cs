﻿namespace BullsAndCows.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Game
    {
        private ICollection<Guess> guesses;

        public Game()
        {
            this.GameState = GameState.WaitingForOpponent;
            this.guesses = new HashSet<Guess>();
        }

        public int Id { get; set; }

        [MinLength(3)]
        [MaxLength(40)]
        [Required]
        public string Name { get; set; }

        public GameState GameState { get; set; }

        [Required]
        public string RedNumber { get; set; }

        [Required]
        public string RedId { get; set; }

        public virtual BullsAndCowsUser Red { get; set; }

        public string BlueNumber { get; set; }

        public string BlueId { get; set; }

        public virtual BullsAndCowsUser Blue { get; set; }

        public DateTime DateCreated { get; set; }

        public virtual ICollection<Guess> Guesses
        {
            get
            {
                return this.guesses;
            }
            
            set
            {
                this.guesses = value;
            }
        }
    }
}
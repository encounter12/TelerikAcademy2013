﻿namespace BullsAndCows.Models
{
    public enum NotificationState
    {
        Read,
        Unread
    }
}
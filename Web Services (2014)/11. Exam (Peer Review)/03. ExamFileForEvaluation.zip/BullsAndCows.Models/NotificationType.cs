﻿namespace BullsAndCows.Models
{
    public enum NotificationType
    {
        YourTurn,
        GameJoined,
        GameWon,
        GameLost
    }
}
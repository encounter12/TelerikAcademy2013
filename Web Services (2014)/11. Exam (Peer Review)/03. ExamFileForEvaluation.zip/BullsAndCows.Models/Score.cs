﻿namespace BullsAndCows.Models
{
    public class Score
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public virtual BullsAndCowsUser User { get; set; }

        public int Wins { get; set; }

        public int Losses { get; set; }

        public int Rank { get; set; }
    }
}
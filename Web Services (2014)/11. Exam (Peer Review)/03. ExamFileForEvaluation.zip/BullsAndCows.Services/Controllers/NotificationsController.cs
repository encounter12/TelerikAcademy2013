﻿namespace BullsAndCows.Services.Controllers
{
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;
    using BullsAndCows.Data;
    using BullsAndCows.Models;
    using Microsoft.AspNet.Identity;

    public class NotificationsController : BaseApiController
    {
        public NotificationsController(IBullsAndCowsData data) : base(data)
        {
        }
        
        [HttpGet]
        [Authorize]
        public IHttpActionResult GetAllNotifications()
        {
            return this.GetAllNotifications(0);
        }

        [HttpGet]
        [Authorize]
        public IHttpActionResult GetAllNotifications(int page)
        {
            var currentUserID = this.User.Identity.GetUserId();

            var notifications = this.data.Notifications.All()
                                    .Where(u => u.UserId == currentUserID)
                                    .OrderByDescending(n => n.DateCreated)
                                    .Skip(10 * page)
                                    .Take(10);

            return this.Ok(notifications);
        }

        [HttpGet]
        [Route("api/notifications/next")]
        [Authorize]
        public HttpResponseMessage GetNextNotification()
        {
            var currentUserID = this.User.Identity.GetUserId();

            var notification = this.data.Notifications.All()
                                   .Where(u => u.UserId == currentUserID && u.State == NotificationState.Unread)
                                   .OrderBy(n => n.DateCreated)
                                   .FirstOrDefault();

            if (notification == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotModified);
            }

            return Request.CreateResponse(HttpStatusCode.OK, notification);
        }
    }
}
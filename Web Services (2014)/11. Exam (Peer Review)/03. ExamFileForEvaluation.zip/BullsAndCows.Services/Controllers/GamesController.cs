﻿namespace BullsAndCows.Services.Controllers
{
    using System;
    using System.Linq;
    using System.Web.Http;
    using BullsAndCows.Data;
    using BullsAndCows.Models;
    using BullsAndCows.Services.DataModels;
    using Microsoft.AspNet.Identity;

    public class GamesController : BaseApiController
    {
        private static Random randomGenerator = new Random();

        public GamesController(IBullsAndCowsData data) : base(data)
        {
        }

        [HttpGet]
        public IHttpActionResult GetGames()
        {
            return this.GetGames(0);
        }

        [HttpGet]
        public IHttpActionResult GetGames(int page)
        { 
            IQueryable<ViewGameDataModel> games;

            if (this.User.Identity.IsAuthenticated)
            {
                games = this.GetPublicAndOwnGames(page);
            }
            else
            {
                games = this.GetPublicGames(page);
            }

            return this.Ok(games);
        }

        [HttpGet]
        [Authorize]
        public IHttpActionResult GetGameById(int id)
        {
            var currentUserID = this.User.Identity.GetUserId();

            var game = this.data.Games.All().Where(g => g.Id == id).FirstOrDefault();

            if (game == null)
            {
                return this.NotFound();
            }

            if (game.RedId != currentUserID && game.BlueId != currentUserID)
            {
                return this.BadRequest("This is not your game!");
            }

            string playerNumber;
            string playerColor;

            if (currentUserID == game.RedId)
            {
                playerColor = "red";
                playerNumber = game.RedNumber;
            }
            else
            {
                playerColor = "blue";
                playerNumber = game.BlueNumber;
            }

            var dataModel = new GameDetailsDataModel
            {
                Id = game.Id,
                Name = game.Name,
                DateCreated = game.DateCreated,
                Red = game.Red.UserName,
                Blue = game.Blue.UserName,
                YourNumber = playerNumber,
                YourGuesses = game.Guesses.AsQueryable().Where(y => y.UserId == currentUserID).ToArray(),
                OpponentGuesses = game.Guesses.AsQueryable().Where(o => o.UserId != currentUserID).ToArray(),
                YourColor = playerColor,
                GameState = game.GameState.ToString()
            };

            return this.Ok(dataModel);
        }

        [HttpPost]
        [Authorize]
        public IHttpActionResult CreateGame(CreateGameDataModel game)
        {
            if (!ModelState.IsValid)
            {
                return this.BadRequest();
            }

            var currentUserID = this.User.Identity.GetUserId();
            var newGame = new Game
            {
                Name = game.Name,
                RedId = currentUserID,
                RedNumber = game.Number,
                DateCreated = DateTime.Now,
            };

            this.data.Games.Add(newGame);
            this.data.SaveChanges();            

            return this.Created(
                "http://localhost:3169/api/games/" + newGame.Id,
                this.data.Games.All().Where(g => g.Id == newGame.Id).Select(ViewGameDataModel.FromGame));  
        }

        [HttpPut]
        [Authorize]
        public IHttpActionResult JoinGame(int id, NumberDataModel number)
        {
            if (!ModelState.IsValid)
            {
                return this.BadRequest();
            }

            var currentUserID = this.User.Identity.GetUserId();

            var game = this.data.Games.All()
                           .Where(g => g.Id == id && g.GameState == GameState.WaitingForOpponent && g.RedId != currentUserID)
                           .FirstOrDefault();

            if (game == null)
            {
                return this.NotFound();
            }

            game.BlueId = currentUserID;
            game.BlueNumber = number.Number;

            var playerTurn = randomGenerator.Next(1, 3);
            game.GameState = (GameState)playerTurn;

            this.data.SaveChanges();

            var responseMessage = new
            {
                result = string.Format("You joined game \"{0}\"", game.Name)
            };

            return this.Ok(responseMessage);
        }

        [HttpPost]
        [Authorize]
        [Route("api/games/{id}/guess")]
        public IHttpActionResult GuessNumber(int id, NumberDataModel number)
        {
            var game = this.data.Games.All()
                           .Where(g => g.Id == id && g.GameState != GameState.WonByBlue && g.GameState != GameState.WonByRed)
                           .FirstOrDefault();

            if (game == null)
            {
                return this.BadRequest();
            }

            var currentUserID = this.User.Identity.GetUserId();

            if (game.RedId != currentUserID && game.BlueId != currentUserID)
            {
                return this.BadRequest("This is not your game!");
            }

            return this.Ok();
        }

        private IQueryable<Game> GetAllGamesOrdered()
        {
            return this.data.Games.All()
                       .OrderBy(g => g.GameState)
                       .ThenBy(g => g.Name)
                       .ThenBy(g => g.DateCreated)
                       .ThenBy(g => g.Red.UserName);
        }

        private IQueryable<ViewGameDataModel> GetPublicGames(int page)
        {
            var games = this.GetAllGamesOrdered()
                            .Where(g => g.GameState == GameState.WaitingForOpponent)
                            .Skip(10 * page)
                            .Take(10)
                            .Select(ViewGameDataModel.FromGame);

            return games;
        }

        private IQueryable<ViewGameDataModel> GetPublicAndOwnGames(int page)
        {
            var currentUserID = this.User.Identity.GetUserId();

            var games = this.GetAllGamesOrdered()
                            .Where(g => g.GameState == GameState.WaitingForOpponent || g.RedId == currentUserID || g.BlueId == currentUserID)
                            .Skip(10 * page)
                            .Take(10)
                            .Select(ViewGameDataModel.FromGame);

            return games;
        }
    }
}
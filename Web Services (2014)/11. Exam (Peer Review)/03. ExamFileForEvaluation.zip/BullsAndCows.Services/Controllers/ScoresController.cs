﻿namespace BullsAndCows.Services.Controllers
{
    using System.Linq;
    using System.Web.Http;
    using BullsAndCows.Data;
    using BullsAndCows.Models;
    using BullsAndCows.Services.DataModels;

    public class ScoresController : BaseApiController
    {
        public ScoresController(IBullsAndCowsData data) : base(data)
        {
        }

        [HttpGet]
        public IHttpActionResult GetTopPlayers()
        {
            var players = this.data.Scores.All()
                              .OrderBy(s => s.Rank)
                              .Take(10)
                              .Select(s => new ScoresDataModel
                                     {
                                         Username = s.User.UserName,
                                         Rank = s.Rank
                                     });

            return this.Ok(players);
        }

        private int CalculateRank(Score score)
        {
            return (score.Wins * 100) + (score.Losses * 15);
        }
    }
}
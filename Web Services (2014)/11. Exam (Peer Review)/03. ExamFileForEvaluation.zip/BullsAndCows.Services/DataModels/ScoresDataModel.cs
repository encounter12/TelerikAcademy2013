﻿namespace BullsAndCows.Services.DataModels
{
    public class ScoresDataModel
    {
        public string Username { get; set; }

        public int Rank { get; set; }
    }
}
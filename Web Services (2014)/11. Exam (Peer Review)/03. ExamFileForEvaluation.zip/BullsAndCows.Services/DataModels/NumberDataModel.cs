﻿namespace BullsAndCows.Services.DataModels
{
    using System.ComponentModel.DataAnnotations;

    public class NumberDataModel
    {
        [Required]
        [MinLength(4)]
        [MaxLength(4)]
        public string Number { get; set; }
    }
}
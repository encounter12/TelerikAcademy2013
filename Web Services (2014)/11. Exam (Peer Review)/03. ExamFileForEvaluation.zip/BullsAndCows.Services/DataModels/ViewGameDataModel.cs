﻿namespace BullsAndCows.Models
{
    using System;
    using System.Linq.Expressions;

    public class ViewGameDataModel
    {
        public static Expression<Func<Game, ViewGameDataModel>> FromGame
        {
            get
            {
                return g => new ViewGameDataModel
                {
                    Id = g.Id,
                    Name = g.Name,
                    Blue = g.Blue.UserName ?? "No blue player yet",
                    Red = g.Red.UserName,
                    GameState = g.GameState.ToString(),
                    DateCreated = g.DateCreated
                };
            }
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Red { get; set; }

        public string Blue { get; set; }

        public string GameState { get; set; }

        public DateTime DateCreated { get; set; }
    }
}
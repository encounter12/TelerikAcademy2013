﻿namespace BullsAndCows.Wcf
{
    using System.Collections.Generic;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using BullsAndCows.Wcf.DataModels;

    [ServiceContract]
    public interface IUsers
    {
        [OperationContract]
        [WebGet(UriTemplate = "")]
        ICollection<UserDataModel> GetUsers();

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "/{ID}")]
        UserDetailsDataModel GetUserByID(string id);
    }
}
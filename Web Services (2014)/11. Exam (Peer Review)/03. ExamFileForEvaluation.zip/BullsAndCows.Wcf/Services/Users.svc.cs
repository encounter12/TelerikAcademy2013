﻿namespace BullsAndCows.Wcf
{
    using System.Collections.Generic;
    using System.Linq;
    using BullsAndCows.Data;
    using BullsAndCows.Wcf.DataModels;

    public class Users : IUsers
    {
        private BullsAndCowsDbContext context;

        public Users()
        {
            this.context = new BullsAndCowsDbContext();
        }

        public ICollection<UserDataModel> GetUsers()
        {
            var allUsers = this.context.Users
                               .OrderBy(x => x.UserName)
                               .Take(10)
                               .Select(x => new UserDataModel
                                      {
                                          Id = x.Id,
                                          Username = x.UserName
                                      });

            return allUsers.ToArray();
        }

        public UserDetailsDataModel GetUserByID(string id)
        {
            var user = this.context.Users.Where(x => x.Id == id)
                           .Select(x => new UserDetailsDataModel
                                  {
                                      Id = x.Id,
                                      Losses = 0,
                                      Rank = 0,
                                      Username = x.UserName,
                                      Wins = 0
                                  })
                           .FirstOrDefault();

            return user;
        }
    }
}
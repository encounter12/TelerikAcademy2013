﻿namespace BullsAndCows.Wcf.DataModels
{
    public class UserDataModel
    {
        public string Id { get; set; }

        public string Username { get; set; }
    }
}
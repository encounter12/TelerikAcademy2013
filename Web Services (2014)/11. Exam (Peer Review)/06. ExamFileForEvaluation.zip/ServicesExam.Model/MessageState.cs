﻿namespace ServicesExam.Model
{
    public enum MessageState
    {
        Read,
        Unread
    }
}

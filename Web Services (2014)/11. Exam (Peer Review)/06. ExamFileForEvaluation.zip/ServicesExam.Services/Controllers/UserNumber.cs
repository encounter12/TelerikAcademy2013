﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServicesExam.Services.Controllers
{
   public class UserNumber
    {
        public string Number { get; set; }
    }
}

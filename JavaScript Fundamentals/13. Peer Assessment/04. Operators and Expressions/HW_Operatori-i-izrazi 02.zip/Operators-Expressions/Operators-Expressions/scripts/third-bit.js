﻿// 05. Is the third bit of an integer number 0 or 1
var n = 12,
    thirdBit = (n >> 3) & 1;
jsConsole.writeLine('The third bit of ' + n + ' = ' + thirdBit);
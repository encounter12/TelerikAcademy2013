﻿// 01. Odd or even
var n = 55,
    isOdd = (n % 2) === 1;
jsConsole.writeLine(n + ' is odd --> ' + isOdd);


﻿// 03. Rectangle area
var a = 5.356,
    b = 55,
    rectArea = a * b;
jsConsole.writeLine('Area of a rectangle ' + a + ' x ' + b + ' = ' + rectArea);
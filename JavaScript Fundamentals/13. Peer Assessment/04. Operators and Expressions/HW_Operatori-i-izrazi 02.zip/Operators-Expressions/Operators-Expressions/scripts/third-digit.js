﻿// 04. Is the third digit of an integer number (right-to-left) 7
var n = 1732,
    digit = 7,
    checkDigit = Math.floor((n / 100) % 10) === digit;
jsConsole.writeLine('The third digit of ' + n + ' is ' + digit + ' --> ' + checkDigit);
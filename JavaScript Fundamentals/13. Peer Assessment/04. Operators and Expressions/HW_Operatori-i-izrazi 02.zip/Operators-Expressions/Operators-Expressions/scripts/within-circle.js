﻿// 06. Is (x,y) within circle K(0,5)
var x = 1.25,
    y = 0.45,
    radius = 5,
    isWithinCircle = (x * x + y * y < radius * radius);
jsConsole.writeLine('(' + x + ', ' + y + ') ' + 'is within the circle with radius = ' +
    radius + ' --> ' + isWithinCircle);
﻿// 08. Trapezoid area
var a = 12.32,
    b = 10,
    h = 5,
    trapezoidArea = ((a + b) * h) / 2;
jsConsole.writeLine('Area of trapezoid (a, b, h) = (' + a + ', ' + b + ', ' + h + ') = ' +
    trapezoidArea);
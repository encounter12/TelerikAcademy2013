﻿//09. Within circle K( (1,1), 3) and out of rectangle R(top=1, left=-1, width=6, height=2)
var x = 1.1,
    y = 0.5;

var kx = 1, // Centre of circle
    ky = 1, // Centre of circle
    kr = 3, // Radius
    rLeft = -1, // Left x of rectangle
    rTop = 1, // Top y of rectangle
    rWidth = 6, // Width
    rHeight = 2, // Height
    isInCircle = Math.pow(x - kx, 2) + Math.pow(y - ky, 2) < kr * kr,
    isOutOfRectangle = x < rLeft || x > rLeft + rWidth || y > rTop || y < rTop - rHeight;

jsConsole.writeLine('(' + x + ', ' + y + ') is within the circle and outside of rectangle --> ' +
    (isInCircle && isOutOfRectangle));

﻿// 07. Is Prime
var n = 101,
    isPrime = true;

for (var i = 2; i <= Math.sqrt(n) ; i += 1) {
    if (n % i === 0) {
        isPrime = false;
        break;
    }
}
jsConsole.writeLine(n + ' is prime --> ' + isPrime);
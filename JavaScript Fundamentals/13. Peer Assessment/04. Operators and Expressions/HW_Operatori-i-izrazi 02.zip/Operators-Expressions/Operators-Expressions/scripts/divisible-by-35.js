﻿// 02. Divisible by 5 and by 7
var n = 105,
isDivisible = (n % 35) === 0;
jsConsole.writeLine(n + ' is divisible by 5 and by 7 --> ' + isDivisible);


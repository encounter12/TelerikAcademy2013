﻿jsConsole.writeLine("04. Write a script that finds the maximal increasing sequence in an array. Example: {3, 2, 3, 4, 2, 2, 4} --> {2, 3, 4}.");
jsConsole.writeLine("\n");

var length = parseInt(prompt("Please enter the length of the array."));
var array = new Array(length);
for (var i = 0; i < array.length; i++) {
    array[i] = parseInt(prompt("Enter element \"" + i + "\" of the first array."));
}

var start = 0,
    count = 1,
    bestCount = 1;

for (var i = 0; i < array.length - 1; i++) {
    if (array[i] + 1 === array[i + 1]) {
        count++;
    } else {
        count = 1;
    }

    if (count >= bestCount) {
        bestCount = count;
        start = array[i + 1] - bestCount + 1;
    }
}

if (bestCount == 1) {
    jsConsole.writeLine("There is no sequence of increasing elements.");
} else {
    for (var i = 0; i < bestCount; i++) {
        if (i < bestCount - 1) {
            jsConsole.write(start + i + ", ");
        } else {
            jsConsole.write(start + i);
        }
    }
}

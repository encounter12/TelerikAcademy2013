﻿jsConsole.writeLine("07. Write a program that finds the index of given element in a sorted array of integers by using the binary search algorithm (find it in Wikipedia).");
jsConsole.writeLine("\n");

var length = parseInt(prompt("Please enter the length of the sorted array."));
var array = new Array(length);
for (var i = 0; i < array.length; i++) {
    array[i] = parseInt(prompt("Enter element \"" + i + "\" of the first array."));
}

var searched = parseInt(prompt("Enter the element for which index you are searching for."));

var start = 0;
var delta = 0;
var index = 0;
var end = length - 1;

do {
    delta = parseInt((end - start) / 2);
    if (delta == 0 && length > 1) {
        delta = 1;
    }

    index = start + delta;

    if (searched < array[index]) {
        end = end - delta;
    } else {
        start = parseInt(start + delta + 0.5);
    }
} while (start != end);

if (array[start] !== searched) {
    jsConsole.writeLine("No such number in the array");
} else {
    jsConsole.writeLine(start);
}
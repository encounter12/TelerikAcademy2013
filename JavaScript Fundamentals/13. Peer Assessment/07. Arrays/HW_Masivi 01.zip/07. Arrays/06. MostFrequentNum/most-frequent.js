﻿jsConsole.writeLine("06. Write a program that finds the most frequent number in an array. Example: {4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3} --> 4 (5 times)");
jsConsole.writeLine("\n");

var length = parseInt(prompt("Please enter the length of the array."));
var array = new Array(length);
for (var i = 0; i < array.length; i++) {
    array[i] = parseInt(prompt("Enter element \"" + i + "\" of the first array."));
}

var freqNum;
var bestCount = 1;
for (var i = 0; i < array.length - 1; i++) {
    var count = 1;
    for (var j = i + 1; j < array.length; j++) {
        if (array[i] === array[j]) {
            count++;
        }

        if (count > bestCount) {
            freqNum = array[i];
            bestCount = count;
        }
    }
}

if (bestCount === 1) {
    jsConsole.writeLine("No repeating numbers");
} else {
    jsConsole.writeLine(freqNum + " (" + bestCount + " times)"); 
}
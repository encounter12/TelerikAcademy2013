﻿jsConsole.writeLine("03. Write a script that finds the maximal sequence of equal elements in an array. Example: {2, 1, 1, 2, 3, 3, 2, 2, 2, 1} --> {2, 2, 2}.");
jsConsole.writeLine("\n");

var length = parseInt(prompt("Please enter the length of the array."));
var array = new Array(length);
for (var i = 0; i < array.length; i++) {
    array[i] = parseInt(prompt("Enter element \"" + i + "\" of the first array."));
}

var start = 0,
    count = 1,
    bestCount = 1;

for (var i = 0; i < array.length - 1; i++) {
    if (array[i] === array[i + 1]) {
        count++;
    } else {
        count = 1;
    }

    if (count >= bestCount) {
        bestCount = count;
        start = array[i];
    }
}

if (bestCount == 1) {
    jsConsole.writeLine("There is no sequence of equal elements.");
} else {
    for (var i = 0; i < bestCount; i++) {
        if (i < bestCount - 1) {
            jsConsole.write(start + ", ");
        } else {
            jsConsole.write(start);
        }
    }
}
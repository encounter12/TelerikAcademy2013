﻿jsConsole.writeLine("05. Sorting an array means to arrange its elements in increasing order. Write a script to sort an array. Use the \"selection sort\" algorithm: Find the smallest element, move it at the first position, find the smallest from the rest, move it at the second position, etc. Hint: Use a second array");
jsConsole.writeLine("\n");

var length = parseInt(prompt("Please enter the length of the array."));
var array = new Array(length);
for (var i = 0; i < array.length; i++) {
    array[i] = parseInt(prompt("Enter element \"" + i + "\" of the first array."));
}

jsConsole.writeLine("Unsorted: " + array);

var min, temp;
for (var i = 0; i < array.length; i++) {
    min = i;
    for (var j = i + 1; j < array.length; j++) {
        if (array[j] < array[min]) {
            min = j;
        }
    }

    temp = array[i];
    array[i] = array[min];
    array[min] = temp;
}

jsConsole.writeLine("Sorted: " + array);

//for (var i = 0; i < array.length - 1; i++) {
//    for (var j = 0; j < array.length - 1; j++) {
//        if (array[j] > array[j + 1]) {
//            var temp = array[j];
//            array[j] = array[j + 1];
//            array[j + 1] = temp;
//        }
//    } 
//}

//jsConsole.writeLine(array);


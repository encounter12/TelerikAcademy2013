﻿jsConsole.writeLine("02. Write a script that compares two char arrays lexicographically (letter by letter).");
jsConsole.writeLine("\n");

var length = parseInt(prompt("Please enter the length of the arrays."));
var arrOne = new Array(length);
for (var i = 0; i < arrOne.length; i++) {
    arrOne[i] = prompt("Enter element \"" + i + "\" of the first array.");
}

var arrTwo = new Array(length);
for (var i = 0; i < arrOne.length; i++) {
    arrTwo[i] = prompt("Enter element \"" + i + "\" of the second array.");
}

for (var i = 0; i < length; i++) {
    jsConsole.writeLine(arrOne[i] === arrTwo[i] ? arrOne[i] + " === " + arrTwo[i] + " true" : arrOne[i] + " === " + arrTwo[i] + " false");
}
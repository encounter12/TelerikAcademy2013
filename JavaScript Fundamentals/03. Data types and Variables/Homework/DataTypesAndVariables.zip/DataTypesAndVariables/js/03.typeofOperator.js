﻿/*global jsConsole, intLit, floatLit, stringLit, booleanLit, doe, arr*/

jsConsole.writeLine("Variable (integer): " + intLit + ", Type: " + typeof (intLit));
jsConsole.writeLine("Variable (float): " + floatLit + ", Type: " + typeof (floatLit));
jsConsole.writeLine("Variable (boolean): " + booleanLit + ", Type: " + typeof (booleanLit));
jsConsole.writeLine("Variable (object): " + doe + ", Type: " + typeof (doe));
jsConsole.writeLine("Variable (array): " + arr + ", Type: " + typeof (arr));
/*global jsConsole, intLit, floatLit, stringLit, booleanLit, doe, arr*/

var string = "'How you doin'?', Joey said.";
jsConsole.writeLine(string);
define(['chai', 'ui'], function (chai, ui){
    var expect = chai.expect;

});
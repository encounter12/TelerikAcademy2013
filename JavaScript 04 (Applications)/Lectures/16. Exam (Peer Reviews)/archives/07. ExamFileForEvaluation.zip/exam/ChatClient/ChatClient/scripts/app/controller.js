/// <reference path="http-requester.js" />
/// <reference path="ui.js" />


define(['jquery', 'sammy', 'httpRequester', 'ui', 'crypto'], function ($, sammy, httpRequester, ui, crypto) {
    var app = function (div, resourceUrl) {

        // keeping data about the logged user
        var user = localStorage.getItem('user'),
            sessionKey = localStorage.getItem('sessionKey');

        function saveUserData(userData) {
            localStorage.setItem('user', userData.user);
            localStorage.setItem('sessionKey', userData.sessionKey);
            user = userData.user;
            sessionKey = userData.sessionKey;
        }

        function clearUserData() {
            localStorage.removeItem('user');
            localStorage.removeItem('sessionKey');
            user = '';
            sessionKey = '';
        }

        function isLoggedIn() {
            console.log('user' + user);
            if (user !== null) {
                return true;
            }            
            return false;
        }


        return sammy(div, function() {
            this.get('#/', function () {
                if (isLoggedIn()) {
                    ui.getHomeUi('#main', true);
                }
                else {
                    ui.getHomeUi('#main', false);
                }

                $('#btn-register').on('click', function () {
                    var userData,
                        username,
                        userpass,
                        authCode;

                    username = $('#Username').val();
                    userpass = $('#Password').val();
                    // couldn't make crypto work through require
                    authCode = CryptoJS.SHA1(username + userpass).toString();

                    userData = {
                        username: username,
                        authCode: authCode
                    };
                    // register user
                    httpRequester.postJson(resourceUrl + 'user', userData)
                        .then(function (result) {
                                ui.getUserRegisteredUi('#main', username, true);
                        }, function (error) {
                            console.log(error);
                            ui.getUserRegisteredUi('#main', username, false);
                        });

                });


                $('#btn-login').on('click', function () {                    
                    var userData,
                        username,
                        userpass,
                        authCode;

                    // TO DO export repeated code
                    username = $('#Username').val();
                    userpass = $('#Password').val();
                    authCode = CryptoJS.SHA1(username + userpass).toString();
                    userData = {
                        username: username,
                        authCode: authCode
                    };

                    // login user
                    httpRequester.postJson(resourceUrl + 'auth', userData)
                        .then(function (result) {
                            if (result) {
                                ui.getUserLoggedInUi('#main', username);
                                saveUserData({ user: username, sessionKey: result.sessionKey });
                            }
                        });
                });

                $('#btn-logout').on('click', function () {
                    var header = { "X-SessionKey": sessionKey };
                    
                    // logout user
                    httpRequester.putJson(resourceUrl + 'user', header)
                        .then(function (result) {
                            if (result) {
                                ui.getUserLoggedOutUi('#main', user);
                                clearUserData();
                            }
                        });

                });
            });
            
            this.get('#/chat', function () {
                ui.getChatUi('#main', isLoggedIn());
                // this selector brakes occasionally -> $('#btn-send').on('click', function () {
                $('#main').on('click', function (ev) {                    
                    if ($(ev.target).is(":button")) {
                        var messageTitle,
                            messageBody,
                            messageData,
                            header;

                        messageTitle = $('#MessageTitle').val();
                        messageBody = $('#MessageBody').val();
                        messageData = {
                            title: messageTitle,
                            body: messageBody
                        };
                        header = { "X-SessionKey": sessionKey };

                        // send message
                        httpRequester.postJson(resourceUrl + 'post', messageData, header)
                            .then(function (result) {
                                if (result) {
                                    console.log('posting' + result);
                                }
                            });
                    }
                });

                // get all messages
                httpRequester.getJson(resourceUrl + 'post')
                        .then(function (result) {
                            ui.getChatUi('#main', isLoggedIn());
                            ui.renderPostsUi(result);
                        }, function (error) {
                            console.log(error);
                        });
            });
        });
    }

    return app;
});
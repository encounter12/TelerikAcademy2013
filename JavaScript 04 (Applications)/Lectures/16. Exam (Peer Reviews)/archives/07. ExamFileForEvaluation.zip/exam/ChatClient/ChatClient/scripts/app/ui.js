﻿define(['jquery', 'mustache', 'underscore'], function ($, mustache, _) {
    // this visualization is messy but the not messy one failed
    var getUI = (function (){       
        var getHomeUi = function (selector, isloggedIn) {
            var html = '<div><h4>This is the chat home</h4>' +
                '<div id="user-area">' +
                    '<div id="login-area">' +
                        '<label for="Username">Your name: </label>'+
                        '<input type="text" id="Username" />'+
                        '<label for="Password">Your password: </label>'+
                        '<input type="text" id="Password" />'+
                        '<input type="button" value="Register" id="btn-register" />' +
                        '<input type="button" value="Login" id="btn-login" />' +
                    '</div>' +
                    '<div id="logout-area">' +
                        '<input type="button" value="Logout" id="btn-logout" />' +
                    '</div>' +
                '</div>'
            '</div>';

            $(selector).empty();
            $(selector).append(html);
            if (isloggedIn) {
                $('#logout-area').show();
                $('#login-area').hide();
            }
            else {
                $('#logout-area').hide();
                $('#login-area').show();
            }           
        }

        var getUserRegisteredUi = function (selector, user, success) {
            var stateWords = success ? ' is ' : ' was not ',
                html = '<div>' +
                'User ' + user + stateWords + ' successfully registered.' +
                '</div>';

            $(selector).append(html);
        }

        var getUserLoggedInUi = function (selector, user) {
            $('#logout-area').show();
            $('#login-area').hide();

            var html = '<div>' +
                'User ' + user + ' is successfully logged in.' +
                '</div>';
            $(selector).append(html);
        }

        var getUserLoggedOutUi = function (selector, user) {
            $('#logout-area').hide();
            $('#login-area').show();

            var html = '<div>' +
                'User ' + user + ' is successfully logged out.' +
                '</div>';
            $(selector).append(html);
        }

        var getChatUi = function (selector, isLoggedIn) {
            var html = '<div id="submit-area">' +
                            '<label for="MessageTitle">Message title: </label>' +
                            '<input type="text" id="MessageTitle" />' +
                            '<label for="MessageBody">Message body: </label>' +
                            '<input type="text" id="MessageBody" />' +
                            '<input type="button" value="Send" id="btn-send" />' +
                    '</div>';

            $(selector).empty();
            $(selector).append(html);

            if (!isLoggedIn) {
                $('#submit-area').hide();
            }            
        }

        var renderPostsUi = function (chatData) {
            if (chatData) {
                // a simple Mustache template
                var template = '<div id="chat-template">' +
                                    '<p><span class="title">{{title}} :</span>' +
                                    '<span class="message">{{body}}</span></p>' +
                                    '<p><span class="postedon">Posted on: {{postDate}}</span></p>' +
                                    '<span class="user">by {{user.username}}</span>' +
                                    '</div>',
                    output;


                _.each(chatData, function (chatMessage) {
                    output = mustache.render(template, chatMessage);
                    $('#rendered-chat-template')
                        .prepend(output); // prepend -> recent messages on top
                });
            }
        }

        return {
            getHomeUi: getHomeUi,
            getUserRegisteredUi: getUserRegisteredUi,
            getUserLoggedInUi: getUserLoggedInUi,
            getUserLoggedOutUi: getUserLoggedOutUi,
            getChatUi: getChatUi,
            renderPostsUi: renderPostsUi
        }

    }())

    return getUI;    
});
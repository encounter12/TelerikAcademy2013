(function () {
    'use strict';

    require.config({
        paths: {
            jquery: 'libs/jquery-2.0.2',
            q: 'libs/q',
            httpRequester: 'app/http-requester',
            sammy: 'libs/sammy',
            controller: 'app/controller',
            ui: 'app/ui',
            mustache: 'libs/mustache',            
            underscore: 'libs/underscore',
            crypto: 'libs/cryptojs-sha1'
        },
        // to make underscore work with require
        shim: {
            "underscore": {
                exports: "_"
            }
        }

    });

    // note: pages sometimes need refresh (F5) to get their actual state.
    // for ex. if you logged out and you go to the home page, you may still see the "Logout" button,
    // even if the user is indeed logged out. F5 to fix the visualization.
    // same goes for chat messages, if you go to home page and still see chat messages, they will disappear after F5

    require(['jquery', 'controller'], function ($, controller) {
        var resourceUrl = 'http://localhost:3000/',
            divId = '#main',
            app;

        app = controller(divId, resourceUrl);
        app.run('#/');
    });
}());
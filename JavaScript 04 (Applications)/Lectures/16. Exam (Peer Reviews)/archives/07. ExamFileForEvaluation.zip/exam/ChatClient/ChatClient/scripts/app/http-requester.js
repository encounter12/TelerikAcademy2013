﻿/// <reference path="Scripts/q.js" />
/// <reference path="Scripts/jquery-2.0.2.js" />

define(['jquery', 'q'], function ($, Q) {

    var httpRequester = (function () {

        var promiseAjaxRequest = function (url, type, data, headers) {
            var ajaxDeferred = Q.defer();

            if(data){
                data = JSON.stringify(data);
            }

            $.ajax({
                url: url,
                type: type,
                data: data,
                contentType: "application/json",
                headers: headers,
                success: function (responseData) {
                    ajaxDeferred.resolve(responseData);
                },
                error: function (errorData) {
                    ajaxDeferred.reject(errorData);
                }
            });

            return ajaxDeferred.promise;
        }

        var promiseAjaxRequestGet = function (url) {
            return promiseAjaxRequest(url, "get");
        }

        var promiseAjaxRequestPost = function (url, data, headers) {
            return promiseAjaxRequest(url, "post", data, headers);
        }

        var promiseAjaxRequestPut = function (url, headers) {
            return promiseAjaxRequest(url, "put", '', headers);
        }

        return {
            getJson: promiseAjaxRequestGet,
            postJson: promiseAjaxRequestPost,
            putJson: promiseAjaxRequestPut
        }
    }())

    return httpRequester;
});
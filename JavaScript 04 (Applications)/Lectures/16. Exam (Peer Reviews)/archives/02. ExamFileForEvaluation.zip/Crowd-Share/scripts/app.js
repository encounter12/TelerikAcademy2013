(function () {

    require.config({
        paths: {

            'Q': 'libs/q',
            'jquery': 'libs/jquery-2.1.1.min',
            'data': 'app/data',
            'sammy': 'libs/sammy-0.7.5.min',
            'httpRequester': 'app/httpRequester',
            'view': 'views/view',
            'post-controler': 'app/post-controler',
            'login-controler': 'app/login-controler',
            'crypto.SHA1': 'libs/sha1'
        },
        shim: {
            'crypto.AES': ['crypto.SHA1']
        }

    });

    require(["jquery", "sammy", 'post-controler', 'login-controler', 'views/view-models', 'view', 'app/data'], function ($, sammy, postControler, loginControler, vmFactory, viewsFactory, persisters) {
        var data = persisters.get("http://jsapps.bgcoder.com/");
        vmFactory.setPersister(data);
        var app = sammy("#main-content", function () {
            this.get("#/", function () {
                //  postControler.loadPosts();
            });

            this.get("#/post", function (context) {
                postControler.init(context);
            });
            this.get("#/auth", function (context) {
                loginControler.init(context);
            });
        });

        app.run("#/post");

        $("header").on("click", "nav ul li", function () {
            $(this).siblings().removeClass("selected");
            $(this).addClass("selected");
        });

        /*POST	/user	Registers an user. Needs a username and authentication code
         POST	/auth	Logs-in an user. Needs a username and authentication code. Returns a session key.
         PUT	/user	Logs-out an user. Needs a session key
         POST	/post	Creates a new post. Needs a session key
         GET	/post	Fetch posts from server. Can filter posts either by User or by search pattern
         */
    })
}());
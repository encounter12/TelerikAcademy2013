define(['Q', 'jquery'], function (Q, $) {
    var View = (function () {
        var rootUrl = 'scripts/partials/';

        var templates = {};

        var loadHtml = function (name) {
            var deferred = Q.defer();

            $.ajax({
                url: 'scripts/partials/user-posts.html',
                type: 'GET',
                success: function (data) {
                    deferred.resolve(data)
                },
                error: function (err) {
                    deferred.reject(err)
                }});
            return deferred.promise;


        };

        var loadLoginHtml = function (name) {
            var deferred = Q.defer();

            $.ajax({
                url: 'scripts/partials/login-form.html',
                type: 'GET',
                success: function (data) {
                    deferred.resolve(data)
                },
                error: function (err) {
                    deferred.reject(err)
                }});
            return deferred.promise;


        };


        return {
            postsView: loadHtml,
            loadLoginHtml:loadLoginHtml
        }
    }());
    return View;
});

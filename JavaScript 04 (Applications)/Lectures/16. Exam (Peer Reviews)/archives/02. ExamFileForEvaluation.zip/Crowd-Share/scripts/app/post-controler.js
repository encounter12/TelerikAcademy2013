define(['Q', 'jquery', 'httpRequester', 'view', 'libs/mustache'], function (Q, $, httpRequester, view, Mustache) {
    var postUrl = "http://localhost:3000/";
    var $viewContainer = null;

    var loadView = function() {
        $viewContainer.empty();
        $viewContainer.load('scripts/partials/chat-view.html');
    };

    var loadPosts = function() {
        var data;
        $.get(postUrl+ 'post')
            .then(function (data) {
                var posts = data;
                return $.get('scripts/partials/user-posts.html')
            })
            .then(function success(posts, template) {
                var rendered = Mustache.render(template, {posts: posts});
                $viewContainer.find('#messages').empty();
                $viewContainer.find('#messages').append(rendered);
            }, function error(err) {
                console.log(err);
            });

        $viewContainer.find('#messages').scrollTop($viewContainer.find('#messages')[0].scrollHeight);
    };

    var onSendBtnClick = function() {
        var msg = $viewContainer.find('#chat').find('input').val();
        var nick = localStorage.getItem('Nickname');

        $.post(postUrl +'auth', {
            text: msg,
            user: nick
        }, function success(msg) {
            loadPosts();
        }, 'json');

        $viewContainer.find('#chat').find('input').val('');
    };

    var init = function(app) {
        $viewContainer = app.$element();

        loadView();

        setInterval(loadPosts, 1500);

        $viewContainer.on('click', '#send', onSendBtnClick);
    };

    return {
        init: init
    };
});
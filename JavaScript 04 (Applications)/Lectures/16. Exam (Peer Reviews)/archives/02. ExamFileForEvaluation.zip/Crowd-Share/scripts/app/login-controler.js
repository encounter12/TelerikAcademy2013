define(['Q', 'jquery', 'app/data', 'views/view-models', 'view', 'app/data', 'httpRequester' ], function (Q, $, persiter, vmFactory, viewsFactory, persisters) {
    'use strict';
    var postUrl = "http://localhost:3000/";
    var appContext = null,
        $viewContainer = null,
        nickname = null,
        data = persisters.get("http://jsapps.bgcoder.com/");
    vmFactory.setPersister(data);

    function Post(url, type, data) {
        var deferred = Q.defer();

        var stringifiedData = "";
        if (data) {
            stringifiedData = JSON.stringify(data);
        }

        $.ajax({
            url: url,
            type: type,
            contentType: "application/json",
            data: JSON.stringify(data),
            success: function (result) {
                deferred.resolve(result);
            },

            error: function (errorData) {
                deferred.reject(errorData);
            }
        });

        return deferred.promise;
    };

    var isValidNikcname = function (nick) {
        if (typeof nick !== 'string') {
            return false;
        }

        if (nick.length < 6 || nick.length > 40) {
            return false;
        }

        return true;
    };

    var enterRegisterBtn = function () {
        var nick = $viewContainer.find('#nick').val();
        var password = $('#tb-password').val();

        if (isValidNikcname(nick)) {
            localStorage.setItem('Nickname', nick);
            var user = {
                username: nick,
                authCode: CryptoJS.SHA1(password).toString()
            };

            Post(postUrl + 'user', 'POST', user)
                .then(function (data) {
                    var key = data.sessionKey;
                },
                function (err) {
                    console.log(err);
                }
            );

        } else {
            alert('Nickname must be between 6 and 40 symbols');
        }
    };

    var enterLoginBtn = function () {
        var nick = $viewContainer.find('#nick').val();
        var password = $('#tb-password').val();

        if (isValidNikcname(nick)) {
            localStorage.setItem('Nickname', nick);
            var user = {
                username: nick,
                authCode: CryptoJS.SHA1(password).toString()
            };
            Post(postUrl + 'auth', 'POST', user)
                .then(function (data) {
                    var key = data.sessionKey;
                    if (!sessionStorage. data) {
                        sessionStorage.setItem(" data ", 0);
                    }
                    sessionStorage.setItem('data', data.sessionKey);
                    $viewContainer.empty();
                    appContext.redirect('#/post');
                },
                function (err) {
                    console.log(err);
                }
            );

        } else {
            alert('Nickname must be between 2 and 14 symbols');
        }
    };

    var loadView = function () {
        $viewContainer.empty();
        viewsFactory.loadLoginHtml()
            .then(function (loginViewHtml) {

                $("#main-content").append(loginViewHtml);
                var loginVm = vmFactory.getLoginVM(
                    this.redirect('#/')
                )
            });
        $viewContainer.on('click', '#login', enterLoginBtn);
        $viewContainer.on('click', '#register', enterRegisterBtn);
    };

    var init = function (app) {
        appContext = app;
        $viewContainer = app.$element();
        loadView();
    };

    return {
        init: init
    };
});

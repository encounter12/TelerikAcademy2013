define(['libs/rsvp.min', 'jquery', 'httpRequester', 'view', 'libs/mustache', 'libs/class', 'libs/sha1'],
    function (RSVP, $, httpRequester, view, Mustache) {
        /// <reference path="http://crypto-js.googlecode.com/svn/tags/3.1.2/build/rollups/sha1.js />

        function performPostRequest(requestUrl, requestData, headers) {
            var promise = new RSVP.Promise(function (resolve, reject) {
                $.ajax({
                    url: requestUrl,
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(requestData),
                    headers: headers,
                    success: function (data) {
                        resolve(data);
                    },
                    error: function (err) {
                        reject(err.message);
                    }
                });
            });
            return promise;
        };

        function performGetRequest(requestUrl, headers) {
            var promise = new RSVP.Promise(function (resolve, reject) {
                $.ajax({
                    url: requestUrl,
                    type: "GET",
                    dataType: "json",
                    contentType: "application/json",
                    headers: headers,
                    success: function (data) {
                        resolve(data);
                    },
                    error: function (err) {
                        reject(err.message);
                    }
                });
            });
            return promise;
        };


        var UsersPersister = Class.create({
            init: function (apiUrl) {
                this.apiUrl = apiUrl;
            },
            login: function (username, password) {
                var self = this;
                var promise = new RSVP.Promise(function (resolve, reject) {
                    var user = {
                        username: username,
                        authCode: CryptoJS.SHA1(password).toString()
                    };
                    return performPostRequest(self.apiUrl, user)
                        .then(function (data) {
                            this.sessionKey = data.sessionKey;
                            debugger;
                            resolve(data);
                        });
                });
                return promise;
            },
            register: function (username, password) {
                var self = this;
                var promise = new RSVP.Promise(function (resolve, reject) {
                    var user = {
                        username: username,
                        authCode: CryptoJS.SHA1(password).toString()
                    };
                    return performPostRequest(self.apiUrl + 'user', user)
                        .then(function (data) {
                            this.sessionKey = data.sessionKey;
                            resolve(data);
                        },
                        function (err) {
                            console.log(err);
                        }
                    );
                });
                return promise;
            }
        });


        var DataPersister = Class.create({
            init: function (apiUrl) {
                this.apiUrl = apiUrl;
                this.users = new UsersPersister(this.apiUrl + "/auth");
            }
        });

        return {
            get: function (apiUrl) {
                return new DataPersister(apiUrl);
            }
        };
    });


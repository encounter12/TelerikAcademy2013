﻿(function () {
    var user = 
    function login() {
        RemoteController.post("http://jsapps.bgcoder.com/user", )
            


    }


    login();

}())
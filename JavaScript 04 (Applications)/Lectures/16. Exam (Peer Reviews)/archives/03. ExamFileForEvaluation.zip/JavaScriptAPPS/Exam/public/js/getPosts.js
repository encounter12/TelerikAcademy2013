﻿(function () {

    function getpPosts() {
        RemoteController.get("http://jsapps.bgcoder.com/post")
            .then(function (data) {
                var $list = $("#posts-list").empty();
                var postsFragment = document.createDocumentFragment();
                for (var i = 0; i < data.length; i++) {
                    var $posts = $("<li>")
                        .attr("id", data[i].id)
                        .append($("<header>").append(data[i].user.username))
                        .append($("<div>").append(data[i].title)).attr("id","title")
                        .append(data[i].body)
                        .append(data[i].id)
                        .appendTo(postsFragment);
                }

                $list.append(postsFragment);
            }).done();


    }


    getpPosts();

}())
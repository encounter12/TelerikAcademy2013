﻿var RemoteController = (function () {
    function getJSON(url, username, headers) {
        var deferred = $.Deferred();
        $.ajax({
            type: "GET",
            url: url,
            //data:username,
            headers: headers || {},
            success: deferred.resolve,
            error: deferred.reject
        });
        return deferred.promise();
    };
    function registerPostJson(url, username, authCode, headers) {
        var deferred = $.Deferred();
        return $.ajax({
            type: "POST",
            url: url,
            data: JSON.stringify({ "username": username, "authCode": authCode }),
            headers: headers || {},
            success: deferred.resolve,
            error: deferred.reject
        });
        return deferred.promise();
    }
    function putJSON(url, headers) {
        var deferred = $.Deferred();
        return $.ajax({
            type: "PUT",
            url: url,
            data: { _method: 'put' },
            headers: headers || {},
            success: deferred.resolve,
            error: deferred.reject
        });
        return deferred.promise();
    }
    return {
        get: getJSON,
        post: registerPostJson,
        put: putJSON
    };
}());
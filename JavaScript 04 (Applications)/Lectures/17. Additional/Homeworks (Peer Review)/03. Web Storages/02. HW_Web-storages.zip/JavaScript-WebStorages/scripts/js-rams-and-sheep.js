/*
 Rams and Sheep Game
 Create a simple number guessing game
    The computer generates a random number with four different digits (abcd)
    - The leftmost digit must not be 0 (zero)
    At each turn the player enters a four-digit number (xyzw)
    When the game ends:
    - Ask the player for a nickname
    - Save the nickname inside the localStorage
    Implement a high-score list
    Rules:
    - Sheep means that a digit from xyzw is contained in abcd, but not on the same position
      If two such digits exists, there are 2 sheep
    - Ram means that a digit from xyzw is contained in abcd and it is on the same position
      If two such digits exists, there are 2 rams
    - The game continues until the player guesses the number abcd
      i.e. has 4 rams
 
 */
(function () {
    'use strict';

    var secretNumber,
        playerGuess;

    var output = document.getElementById('guess-info');
    var input = document.getElementById('guessNumber');
    
    var guessInfoLine = document.createElement('p');

    // Button event handlers
    var generateButton = document.getElementById('generateRandomNumber');

    generateButton.addEventListener('click', function () {
        secretNumber = generateRandomNumber();console.log(secretNumber);
        clearOutputInfo();
    }, false);

    var evaluateButton = document.getElementById('evaluateButton');

    evaluateButton.addEventListener('click', function () {
        playerGuess = input.value;
        evaluateResult();
    }, false);

    // Evaluates the input guess
    function evaluateResult() {
        var guessInfo = guessInfoLine.cloneNode();
        var rams = 0;
        var sheep = 0;

        if (secretNumber === playerGuess) {
            guessInfo.innerHTML = 'Correct guess! The secret number is ' + secretNumber;
        } else {
            var len = secretWord.length;

            for (var guessSymbol = 0; guessSymbol < len; guessSymbol++) {
                if (playerGuess[guessSymbol] === secretNumber[guessSymbol]) {
                    rams++;
                }
                else {
                    for (var secretSymbol = 0; secretSymbol < len && secretSymbol != guessSymbol; secretSymbol++) {
                        if (playerGuess[guessSymbol] === secretNumber[secretSymbol]) {
                            sheep++;
                        }
                    }
                }
            }

            guessInfo.innerHTML = 'You have ' + rams + ' rams and ' + sheep + ' sheep';
        }

        output.appendChild(guessInfo);
    }

    // Generates a random number
    function generateRandomNumber() {
        return Math.floor(Math.random() * 10000).toString();
    }

    // Clears the input field (where player submits their guesses)
    // and the output field (where the evaluation of the guess is displayed)
    function clearOutputInfo() {
        output.innerHTML = '';
        input.value = '0000';
    }
})();
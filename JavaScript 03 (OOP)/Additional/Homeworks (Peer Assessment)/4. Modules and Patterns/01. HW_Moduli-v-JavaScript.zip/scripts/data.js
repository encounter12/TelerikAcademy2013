define(function () {
    'use strict';

    var data = (function () {
        
         var carCollection = [
             { id: 1, 
			   name: "Audi", 
			   src: "images/Audi.jpg" }, 
             { id: 2, 
			   name: "Chevrolet", 
			   src: "images/Chevrolet.jpg" },
             { id: 3,
			   name: "Jaguar", 
			   src: "images/Jaguar.jpg" },
             { id: 4, 
			   name: "Lamborghini", 
			   src: "images/Lambo.jpg" }
         ];

        return {
            carCollection: carCollection
        }

    })();

    return data;
});
var specialConsole = (function () {
    function parsePlaceholderMessage(options) {
        var message, i,len;
        message = options[0];

        for (i = 1, len = options.length; i < len; i += 1) {
            while (message.indexOf('{' + (i - 1) + '}') !== -1) {
                message = message.replace('{' + (i - 1) + '}', options[i]);
            }
        }

        return message;
    }

    var consoleInner, wrapper;
    consoleInner = {};

    consoleInner.display = document.createElement('div');
    consoleInner.display.style.position = 'absolute';
    consoleInner.display.style.left = '100px';
    consoleInner.display.style.top = '50px';
    consoleInner.display.style.width = '500px';
    consoleInner.display.style.height = '300px';
    consoleInner.display.style.padding = '15px';
    consoleInner.display.style.backgroundColor = 'gray';
    consoleInner.display.style.color = 'white';

    wrapper = document.querySelector('#wrapper');
    wrapper.appendChild(consoleInner.display);

    consoleInner.writeLine = function () {
        var message = arguments[0];
        if (arguments.length > 1) {
            message = parsePlaceholderMessage(arguments);
        }

        consoleInner.display.innerHTML += message + '<br />';
    };

    consoleInner.writeError = consoleInner.writeLine;
    consoleInner.writeWarning = consoleInner.writeLine;

    return consoleInner;
}());
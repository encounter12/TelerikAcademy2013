//'use strict';
var domModule = (function() {
    var module, buffer;
    module = {};
    buffer = {};

    module.appendChild = function (child, parentSelector) {
        var parent = document.querySelector(parentSelector);
        parent.appendChild(child);
    };

    module.removeChild = function (parentSelector, childselector) {
        var parent, child;
        parent = document.querySelector(parentSelector);
        child = parent.querySelector(childselector);
        parent.removeChild(child);
    };

    module.addHandler = function (elementSelector, eventType, functionAttached) {
        var element = document.querySelector(elementSelector);
        element.addEventListener(eventType, functionAttached);
    };

    module.appendToBuffer = function (parentSelector, element) {
        var sameElementsBuffered,fragment, i, len, parent;

        if(buffer[parentSelector]) {
            buffer[parentSelector].push(element);

            if(buffer[parentSelector].length === 100) {
                sameElementsBuffered = buffer[parentSelector];
                fragment = document.createDocumentFragment();
                for (i = 0, len = 100; i < len; i += 1) {
                     fragment.appendChild(sameElementsBuffered[i]);
                }
                parent = document.querySelector(parentSelector);
                parent.appendChild(fragment);
                buffer[parentSelector] = [];
            }
        }
        else {
            buffer[parentSelector] = [];
        }
    };

    module.select = function (elementSelector) {
        var element = document.querySelector(elementSelector);
        return element;
    };

    return module;
}());
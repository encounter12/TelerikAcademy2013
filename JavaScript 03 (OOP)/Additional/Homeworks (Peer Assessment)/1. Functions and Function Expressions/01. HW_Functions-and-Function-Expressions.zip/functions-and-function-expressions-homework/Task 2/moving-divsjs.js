var movingShapes = (function () {
    var shape;
    shape = {};

    function getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    function getRandomColor() {
        var rgbColor, red, green, blue;

        red = getRandomInt(0, 255);
        green = getRandomInt(0, 255);
        blue = getRandomInt(0, 255);

        rgbColor = "rgb(" + red + ', ' + green + ', ' + blue + ")";

        return rgbColor;
    }

    function getDiv() {
        var div = document.createElement('div');
        div.style.width = '50px';
        div.style.height = '50px';
        div.style.borderRadius = '50px';
        div.style.backgroundColor = getRandomColor();
        div.style.position = 'absolute';
        div.style.left = getRandomInt(100, 600) + 'px';
        div.style.top = getRandomInt(100, 300) + 'px';

        return div.cloneNode(true);
    }

    function move(element ,movement) {
        var positionX, positionY, speed;
        speed = getRandomInt(30, 80);

        positionX = parseInt(element.style.left);
        positionY = parseInt(element.style.left);

        if (movement === 'ellipse') {
            var radius, angle;
            radius = getRandomInt(20,60);
            angle = 0;

            setInterval(function moveDivs() {
                var leftPosition, topPosition;

                angle++;
                if (angle === 360) {
                    angle = 0;
                }

                leftPosition = positionX + Math.cos((2 * 3.14 / 180) * (angle)) * radius;
                topPosition = positionY + Math.sin((2 * 3.14 / 180) * (angle)) * radius;

                element.style.left = leftPosition + 'px';
                element.style.top = topPosition + 'px';
            }, speed);
        }
        else if (movement === 'rect') {
            var initialX, initialY, direction;
            initialX = positionX;
            initialY = positionY;
            direction = 0;

            setInterval(function moveDivs() {
                if (direction > 3) {
                    direction = 0;
                }

                switch (direction) {
                    case 0: positionX += 5;
                        if (positionX > initialX + 200) {
                            direction++;
                        }
                        break;
                    case 1: positionY += 5;
                        if (positionY > initialY + 200) {
                            direction++;
                        }
                        break;
                    case 2: positionX -= 5;
                        if (positionX < initialX - 200) {
                            direction++;
                        }
                        break;
                    case 3: positionY -= 5;
                        if (positionY < initialY - 200) {
                            direction++;
                        }
                        break;
                }

                element.style.left = positionX + 'px';
                element.style.top = positionY + 'px';
            }, speed);
        }
    }

    shape.add = function(movement) {
       var div, wrapper;
       div = getDiv();
       wrapper = document.getElementById('wrapper');
       wrapper.appendChild(div);

       move(div, movement);
    };

    return shape;
}());
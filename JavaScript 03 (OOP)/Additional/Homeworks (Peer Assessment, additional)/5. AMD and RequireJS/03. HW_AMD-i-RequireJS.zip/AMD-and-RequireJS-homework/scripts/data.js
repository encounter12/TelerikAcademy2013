﻿define(function () {
    var pictures = [{
        image: 'images/IMG100_0670.JPG',
        title: 'Popovo ezero lake, Pirin mountain'
    }, {
        image: 'images/IMG100_143.JPG',
        title: 'Kademliisko praskalo waterfall, Balkan range mountain'
    }, {
        image: 'images/IMG101_2447.jpg',
        title: 'Sinanica lake and Sinanica hut, Pirin mountain'
    }, {
        image: 'images/IMG101_2516.jpg',
        title: 'Sinanica peak, Pirin mountain'
    }, {
        image: 'images/IMG101_4824.jpg',
        title: 'Ribni ezera lakes, Rila mountain'
    }, {
        image: 'images/P1150508.JPG',
        title: 'Kamenica peak and Tevno ezero lake, Pirin mountain'
    }];

    return pictures;
})

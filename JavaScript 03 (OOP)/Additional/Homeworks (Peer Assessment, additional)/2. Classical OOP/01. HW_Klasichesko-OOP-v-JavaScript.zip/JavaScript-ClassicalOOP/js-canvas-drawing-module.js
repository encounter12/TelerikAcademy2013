var canvas = document.getElementById('container');

var draw = (function() {    
    var context = canvas.getContext('2d');
    
    context.fillStyle = 'rgba(0, 0, 200, 0.5)';
    context.lineWidth = 3;
    context.strokeStyle = 'darkorchid';
    
    function drawRectangle(x, y, width, height) {
        //clear();
        
        context.fillRect(x, y, width, height);
        context.strokeRect(x, y, width, height);
    }
     
    function drawCircle(x, y, radius) {
        //clear();
        
        var circleBeginRadAngle = 0;
        var circleEndRadAngle = 2 * Math.PI;
        
        context.fillStyle = 'orange'; // orange
        
        context.beginPath();
        context.arc(x, y, radius, circleBeginRadAngle, circleEndRadAngle, true);
        context.fill();
        context.stroke();
    }
     
    function drawLine (startX, startY, endX, endY) {
        context.strokeStyle = 'aqua';
        
        context.beginPath();
        context.moveTo(startX, startY);
        context.lineTo(endX, endY);
        context.stroke();
    }
    
    function clear() {
        context.clearRect(0, 0, canvas.width, canvas.height);
    }
    
    return {
        rectangle: drawRectangle,
        circle: drawCircle,
        line: drawLine
    }
})();
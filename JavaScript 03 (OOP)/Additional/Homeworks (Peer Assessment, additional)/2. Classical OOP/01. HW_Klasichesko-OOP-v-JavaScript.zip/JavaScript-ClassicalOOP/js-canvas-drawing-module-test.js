(function () {
    function Point(x, y) {
        this.x = x;
        this.y = y;
    }

    function Circle(centre, radius) {
        this.centre = centre;
        this.radius = radius;
    }

    function Line(start, end) {
        this.start = start;
        this.end = end;
    }

    // draw rectangle
    draw.rectangle(50, 50, 90, 70);
    
    // draw circle
    var centreX = canvas.width / 2;
    var centreY = canvas.height / 2;
    var radius = 55;

    var textCentre = new Point(centreX, centreY);
    var testCircle = new Circle(textCentre, radius);

    //draw.circle(centreX, centreY, radius);
    draw.circle(testCircle.centre.x, testCircle.centre.y, testCircle.radius);
    
    // draw line
    var startX = 35;
    var startY = 70;
    var endX = 185;
    var endY = 210;

    var lineStart = new Point(startX, startY);
    var lineEnd = new Point(endX, endY);
    
    var testLine = new Line(lineStart, lineEnd);
    
    //draw.line(startX, startY, endX, endY);
    draw.line(testLine.start.x, testLine.start.y, testLine.end.x, testLine.end.y);
})();
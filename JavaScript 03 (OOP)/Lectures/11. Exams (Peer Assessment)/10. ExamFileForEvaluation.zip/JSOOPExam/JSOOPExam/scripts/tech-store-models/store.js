define(function () {
    'use strict'
    var Store;
    Store = (function () {

        function Store(item) {
            this._items = [];
        }
        Store.prototype.addItem = function (item) {
            this._items.push(item)
        }

        Store.prototype.filterItemsByPrice = function (price) {
            priceSort(item, name, price);
        }

        Store.prototype.getSmartPhones = function (item) {
            return {
                item: 'smart-phone'
            }
        }

        Store.prototype.getMobiles = function (firstItem, secondItem) {

            return {
                firstItems: 'smart-phone',
                secondItem: 'tablet'
            }
        }

        Store.prototype.filterItemsByType = function (type) {
            type.sort(function (name) {
                return name('accessory');
            })
        }

        function priceSort(item, name, price) {
            item.sort(function (firstPrice, secondPrice) {
                return firstPrice.price - secondPrice.price;
            })
            var minPrice = item.slice(0, price) || 0;
            return minPrice;

            var maxPrice = item.slice(0, price) || 0;
            return maxPrice;
        }
        return Store;
    })
    return Store;
})
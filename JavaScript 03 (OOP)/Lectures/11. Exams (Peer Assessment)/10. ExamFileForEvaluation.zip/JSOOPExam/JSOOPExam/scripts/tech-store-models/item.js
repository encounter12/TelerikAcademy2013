define(function () {
    'use strict';
    var Item;
    Item = (function () {
        function Item(type, name, price) {
            this._type = type;
            this.name = name;
            this._price = price;
            if (name.lenght < 6 || name.lenght > 40) {
                throw {
                    message:'The lenght of name is too short ot to long'
                }
            }
        }

        Item.prototype = function (item, name, price) {
            if (!(item instanceof Item)) {
                throw {
                    message: 'The type of item is incorrect'
                };
            }
            this._type.push(item);
            return this;
            if (!(name instanceof Item)) {
                throw {
                    message: 'The type of name is incorrect'
                }
            }
            this._type.push(name);
            return this;
            if (!(price instanceof Item)) {
                throw {
                    message: 'The type of number is incorrect'
                }
            }
            this._type.push(price);
            return this;
        };

        return Item;
    })();
    return Item;
});
define(["tech-store-models/item"], function (Item) {
    'use strict';
    var Store;
    
    Store = (function () {
        function Store(title) {
            this.title = "";
            
            if (title.length >= 6 && title.length <= 30) {
                this.title = title;
            }
            else {
                throw new Error("Invalid store title. Titles should be between 6 and 30 characters long.");
            }
            
            this.items = [];
        };
        
        Store.prototype.addItem = function (item) {
            if (!(item instanceof Item)) {
                throw new Error("The item you are trying to add is not an instance of Item.");
            }
            
            this.items.push(item);
            
            return this;
        };
        
        Store.prototype.getAll = function () {
            return sortAlphabetically.call(this, []);
        };
        
        Store.prototype.getSmartPhones = function () {
            return sortAlphabetically.call(this, ["smart-phone"]);
        };
        
        Store.prototype.getMobiles = function () {
            return sortAlphabetically.call(this, ["smart-phone", "tablet"]);
        };
        
        Store.prototype.getComputers = function () {
            return sortAlphabetically.call(this, ["pc", "notebook"]);
        };
        
        Store.prototype.filterItemsByType = function (filterType) {
            var filterArray = [filterType];
            
            return sortAlphabetically.call(this, filterArray);
        };
        
        Store.prototype.filterItemsByPrice = function (options) {
            var itemsForSorting = [];
            
            if (options === undefined) {
                options = {};
            }
            
            options.min = options.min || 0;
            options.max = options.max || Infinity;
            
            for (var i = 0; i < this.items.length; i += 1) {
                if (this.items[i].price >= options.min && this.items[i].price <= options.max) {
                    itemsForSorting.push(this.items[i]);
                }
            }
            
            itemsForSorting.sort(function (item1, item2) {
                return item1.price - item2.price;
            });
            
            return itemsForSorting;
        };
        
        Store.prototype.countItemsByType = function () {
            var itemsCount = [];
            
            for (var i = 0; i < this.items.length; i += 1) {
                if (itemsCount[this.items[i].type] === undefined) {
                    itemsCount[this.items[i].type] = 1;
                }
                else {
                    itemsCount[this.items[i].type]++;
                }
            }
            
            return itemsCount;
        };
        
        Store.prototype.filterItemsByName = function (partOfName) {
            var filteredItems = [];
            
            partOfName = partOfName.toLowerCase();
            
            for (var i = 0; i < this.items.length; i += 1) {
                if (this.items[i].name.toLowerCase().indexOf(partOfName) >= 0) {
                    filteredItems.push(this.items[i]);
                }
            }
            
            filteredItems.sort(function(a, b) {
                var textA = a.name.toLowerCase();
                var textB = b.name.toLowerCase();
                return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
            });
            
            return filteredItems;
        };
        
        var sortAlphabetically = function (itemTypes) {
            var itemsForSorting = [];
            
            if (itemTypes.length === 0) {
                for (var i = 0; i < this.items.length; i += 1) {
                    itemsForSorting.push(this.items[i]);
                }
            }
            else {
                for (var i = 0; i < this.items.length; i += 1) {
                    if (itemTypes.indexOf(this.items[i].type) >= 0) {
                        itemsForSorting.push(this.items[i]);
                    }
                }
            }
            
            itemsForSorting.sort(function(a, b) {
                var textA = a.name.toLowerCase();
                var textB = b.name.toLowerCase();
                return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
            });
            
            return itemsForSorting;
        };
        
        return Store;
    }());
    
    return Store;
});
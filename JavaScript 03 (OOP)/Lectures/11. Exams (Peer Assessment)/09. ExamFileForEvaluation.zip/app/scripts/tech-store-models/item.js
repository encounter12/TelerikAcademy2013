define([], function () {
    'use strict';
    var Item;
    
    Item = (function () {
        var Item = function (type, name, price) {
            var validTypes = ["accessory", "smart-phone", "notebook", "pc", "tablet"];
            
            if (validTypes.indexOf(type) >= 0) {
                this.type = type;
            }
            else {
                throw new Error("Invalid item type: " + type);
            }
            
            if (name.length >= 6 && name.length <= 40) {
                this.name = name;
            }
            else {
                throw new Error("Invalid name. Names should be between 6 and 40 characters long");
            }
            
            this.price = parseFloat(price);
        };
        
        return Item;
    }());
    
    return Item;
});
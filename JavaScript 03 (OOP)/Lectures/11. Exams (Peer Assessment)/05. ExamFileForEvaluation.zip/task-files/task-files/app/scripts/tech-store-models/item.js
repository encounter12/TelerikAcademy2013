define(function () {
    'use strict';
    var Item;
    Item = (function () {
        function Item(type, name, price) {
            if (type === 'accessory' || type === 'smart-phone' || type === 'notebook' || type === 'tablet' || type === 'pc') {
                this.type = type;
            }
            else {
                console.log('Invalid type!');
            }
			
            if (name.length >= 6 && name.length <= 40) {
                this.name = name;
            }
            else {
                console.log('Invalid name length!');
            }

            this.price = price;
        }

        return Item;
    }());

    return Item;
});
define(function () {
    'use strict';
    var Store;
    Store = (function () {
        function Store(name) {
            this.name = name;
            this._items = [];
        }

        Store.prototype.addItem = function (item) {
            this._items.push(item);
            return this;
        };

        Store.prototype.getAll = function () {
            var byName = this._items.slice(0);
            return byName.sort(function (a, b) {
                var x = a.name.toLowerCase();
                var y = b.name.toLowerCase();
                return x < y ? -1 : x > y ? 1 : 0;
            });
        };

        Store.prototype.getSmartPhones = function () {
            var i;
            var arrLen = this._items.length;
            var smartPhonesArr = [];
            for (i = 0; i < arrLen; i += 1) {
                if (this._items[i].type === 'smart-phone') {
                    smartPhonesArr.push(this._items[i]);
                }
            }

            return smartPhonesArr.sort(function (a, b) {
                var x = a.name.toLowerCase();
                var y = b.name.toLowerCase();
                return x < y ? -1 : x > y ? 1 : 0;
            });
        };

        Store.prototype.getMobiles = function () {
            var i;
            var arrLen = this._items.length;
            var mobilesArr = [];
            for (i = 0; i < arrLen; i += 1) {
                if (this._items[i].type === 'smart-phone' || this._items[i].type === 'tablet') {
                    mobilesArr.push(this._items[i]);
                }
            }

            return mobilesArr.sort(function (a, b) {
                var x = a.name.toLowerCase();
                var y = b.name.toLowerCase();
                return x < y ? -1 : x > y ? 1 : 0;
            });
        };

        Store.prototype.getComputers = function () {
            var i;
            var arrLen = this._items.length;
            var computersArr = [];
            for (i = 0; i < arrLen; i += 1) {
                if (this._items[i].type === 'pc' || this._items[i].type === 'notebook') {
                    computersArr.push(this._items[i]);
                }
            }

            return computersArr.sort(function (a, b) {
                var x = a.name.toLowerCase();
                var y = b.name.toLowerCase();
                return x < y ? -1 : x > y ? 1 : 0;
            });
        };

        Store.prototype.filterItemsByType = function (filterType) {
            var i;
            var arrLen = this._items.length;
            var filteredItemsArr = [];
            for (i = 0; i < arrLen; i += 1) {
                if (this._items[i].type === filterType) {
                    filteredItemsArr.push(this._items[i]);
                }
            }

            return filteredItemsArr.sort(function (a, b) {
                var x = a.name.toLowerCase();
                var y = b.name.toLowerCase();
                return x < y ? -1 : x > y ? 1 : 0;
            });
        };

        Store.prototype.filterItemsByPrice = function (options) {
            if (!options) {
                var byPrice = this._items.slice(0);
                return byPrice.sort(function (a, b) {
                    return a.price - b.price;
                });
            }
            else if (options) {
                var min;
                if (options.hasOwnProperty('min')) {
                    min = options.min;
                } else {
                    min = 0;
                }

                var max;
                if (options.hasOwnProperty('max')) {
                    max = options.max;
                } else {
                    max = Number.POSITIVE_INFINITY;
                }
                
                var i;
                var arrLen = this._items.length;
                var filteredItemsByPrice = [];
                for (i = 0; i < arrLen; i += 1) {
                    if (this._items[i].price >= min && this._items[i].price <= max) {
                        filteredItemsByPrice.push(this._items[i]);
                    }
                }

                return filteredItemsByPrice.sort(function (a, b) {
                    return a.price - b.price;
                });
            }
        };

        Store.prototype.filterItemsByName = function (partOfName) {
            var i;
            var arrLen = this._items.length;
            var filteredItemsArr = [];
            for (i = 0; i < arrLen; i += 1) {
                if (this._items[i].name.toLowerCase().indexOf(partOfName) >= 0) {
                    filteredItemsArr.push(this._items[i]);
                }
            }

            return filteredItemsArr.sort(function (a, b) {
                var x = a.name.toLowerCase();
                var y = b.name.toLowerCase();
                return x < y ? -1 : x > y ? 1 : 0;
            });
        };

        Store.prototype.countItemsByType = function () {
            console.log('The Last Function is Not Implemented Yet!');
        };

        return Store;
    }());

    return Store;
});
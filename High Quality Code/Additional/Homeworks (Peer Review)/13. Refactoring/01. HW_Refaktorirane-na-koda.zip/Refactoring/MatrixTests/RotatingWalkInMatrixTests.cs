﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RotatingWalkInMatrix;

namespace MatrixTests
{
    [TestClass]
    public class RotatingWalkTest
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestGenerateRotatingWalkMatrixNegativeSize()
        {
            int[,] expectedMatrix = new int[0, 0];
            int[,] actualMatrix = RotatingWalk.GenerateRotatingWalkMatrix(RotatingWalk.MIN_MATRIX_SIZE - 1);
            bool areEqual = this.AreEqualMatrices(expectedMatrix, actualMatrix);
            Assert.IsTrue(areEqual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestGenerateRotatingWalkMatrixAboveMaxSize()
        {
            int[,] expectedMatrix = new int[0, 0];
            int[,] actualMatrix = RotatingWalk.GenerateRotatingWalkMatrix(RotatingWalk.MAX_MATRIX_SIZE + 1);
            bool areEqual = this.AreEqualMatrices(expectedMatrix, actualMatrix);
            Assert.IsTrue(areEqual);
        }

        [TestMethod]
        public void TestGenerateRotatingWalkMatrixSize0()
        {
            int[,] expectedMatrix = new int[0, 0];
            int[,] actualMatrix = RotatingWalk.GenerateRotatingWalkMatrix(0);
            bool areEqual = this.AreEqualMatrices(expectedMatrix, actualMatrix);
            Assert.IsTrue(areEqual);
        }

        [TestMethod]
        public void TestGenerateRotatingWalkMatrixSize1()
        {
            int[,] expectedMatrix = { { 1 } };
            int[,] actualMatrix = RotatingWalk.GenerateRotatingWalkMatrix(1);
            bool areEqual = this.AreEqualMatrices(expectedMatrix, actualMatrix);
            Assert.IsTrue(areEqual);
        }

        [TestMethod]
        public void TestGenerateRotatingWalkMatrixSize2()
        {
            int[,] expectedMatrix =
            {
                { 1, 4 },
                { 3, 2 }
            };
            int[,] actualMatrix = RotatingWalk.GenerateRotatingWalkMatrix(2);
            bool areEqual = this.AreEqualMatrices(expectedMatrix, actualMatrix);
            Assert.IsTrue(areEqual);
        }

        [TestMethod]
        public void TestGenerateRotatingWalkMatrixSize3()
        {
            int[,] expectedMatrix =
            {
                { 1, 7, 8 },
                { 6, 2, 9 },
                { 5, 4, 3 }
            };
            int[,] actualMatrix = RotatingWalk.GenerateRotatingWalkMatrix(3);
            bool areEqual = this.AreEqualMatrices(expectedMatrix, actualMatrix);
            Assert.IsTrue(areEqual);
        }

        [TestMethod]
        public void TestGenerateRotatingWalkMatrixSize5()
        {
            int[,] expectedMatrix =
            {
                { 1, 13, 14, 15, 16 },
                { 12, 2, 21, 22, 17 },
                { 11, 23, 3, 20, 18 },
                { 10, 25, 24, 4, 19 },
                { 9, 8, 7, 6, 5 }
            };
            int[,] actualMatrix = RotatingWalk.GenerateRotatingWalkMatrix(5);
            bool areEqual = this.AreEqualMatrices(expectedMatrix, actualMatrix);
            Assert.IsTrue(areEqual);
        }

        private bool AreEqualMatrices(int[,] expectedMatrix, int[,] actualMatrix)
        {
            int expectedMatrixRows = expectedMatrix.GetLength(0);
            int expectedMatrixCols = expectedMatrix.GetLength(1);
            int actualMatrixRows = actualMatrix.GetLength(0);
            int actualMatrixCols = actualMatrix.GetLength(1);

            if (expectedMatrixRows != actualMatrixRows || expectedMatrixCols != actualMatrixCols)
            {
                return false;
            }

            for (int row = 0; row < expectedMatrixRows; row++)
            {
                for (int col = 0; col < expectedMatrixCols; col++)
                {
                    if (expectedMatrix[row, col] != actualMatrix[row, col])
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}


﻿namespace Figures
{
    using System;

    public class Test
    {
        public static void Main()
        {
            double width = 22d;
            double height = 22d;
            double rotationAngle = 10d;

            Figure testFigure = new Figure(width, height);

            Console.WriteLine("Figure width: {0:0.00}", testFigure.Width);
            Console.WriteLine("Figure height: {0:0.00}", testFigure.Height);

            testFigure = Figure.GetRotatedFigure(testFigure, rotationAngle);

            Console.WriteLine("\nWidth and height after rotation");
            Console.WriteLine("Figure width: {0:0.00}", testFigure.Width);
            Console.WriteLine("Figure height: {0:0.00}", testFigure.Height);
        }
    }
}

﻿namespace Figures
{
    using System;

    public class Figure
    {
        private double width;
        private double height;

        public Figure(double width, double height)
        {
            this.Width = width;
            this.Height = height;
        }

        public double Width
        {
            get
            {
                return this.width;
            }

            set
            {
                if (value > 0)
                {
                    this.width = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Width should be positive!");
                }
            }
        }

        public double Height
        {
            get
            {
                return this.height;
            }

            set
            {
                if (value > 0)
                {
                    this.height = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Height should be positive!");
                }
            }
        }

        public static Figure GetRotatedFigure(Figure figure, double rotationAngle)
        {
            double rotationAngleCosinus = Math.Cos(rotationAngle);
            double rotationAngleSinus = Math.Sin(rotationAngle);

            double rotatedSizeWidth = (Math.Abs(rotationAngleCosinus) * figure.Width) + (Math.Abs(rotationAngleSinus) * figure.Height);
            double rotatedSizeHeight = (Math.Abs(rotationAngleSinus) * figure.Width) + (Math.Abs(rotationAngleCosinus) * figure.Height);

            Figure rotatedFigure = new Figure(rotatedSizeWidth, rotatedSizeHeight);

            return rotatedFigure;
        }
    }
}

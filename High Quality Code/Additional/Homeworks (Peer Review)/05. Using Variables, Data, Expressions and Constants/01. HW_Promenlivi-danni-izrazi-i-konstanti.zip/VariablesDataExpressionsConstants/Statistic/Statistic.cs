﻿namespace Statistic
{
    using System;

    public static class Statistic
    {
        public static void Print(double[] array)
        {
            Console.WriteLine("Max Number: {0:0.00}", GetMaxValue(array));
            Console.WriteLine("Min Number: {0:0.00}", GetMinValue(array));
            Console.WriteLine("Average: {0:0.00}", GetAverage(array));
        }

        private static double GetAverage(double[] numbers)
        {
            double sum = 0;

            for (int i = 0; i < numbers.Length; i++)
            {
                sum += numbers[i];
            }

            double average = sum / numbers.Length;

            return average;
        }

        private static double GetMinValue(double[] numbers)
        {
            double minNumber = 0;

            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] < minNumber)
                {
                    minNumber = numbers[i];
                }
            }

            return minNumber;
        }

        private static double GetMaxValue(double[] numbers)
        {
            double maxNumber = double.MinValue;

            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i] > maxNumber)
                {
                    maxNumber = numbers[i];
                }
            }

            return maxNumber;
        }
    }
}

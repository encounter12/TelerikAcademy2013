﻿namespace Statistic
{
    using System;

    public class Test
    {
        public static void Main()
        {
            double[] arrayOfNumbers = new double[] { 3.2d, 2.1d, 5d, 8.6d, 0, 1.1d };

            Statistic.Print(arrayOfNumbers);
        }
    }
}

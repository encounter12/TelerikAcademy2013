﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    class ChannelOneK : Channel
    {
        public override TalkShow TalkShow()
        {
            var show = new TalkShow("The day begins");
            return show;
        }

        public override NewsShow News()
        {
            var show = new NewsShow("Across the world news");
            return show;
        }

        public override Movie Movie()
        {
            var show = new Movie("Enemy at the gate");
            return show;
        }
        public override string Name
        {
            get { return "ChannelOneK"; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            var ctv = new Ctv();
            var pickShow = new ShowChanger(ctv);
            var movie = pickShow.AirMovie();

            Console.WriteLine("Now airing {0} at {1}", movie.Name, ctv.Name);
        }
    }
}

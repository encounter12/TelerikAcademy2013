﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    class ShowChanger
    {
        private Channel channel;

        public ShowChanger(Channel channel)
        {
            this.channel = channel;
        }

        public TalkShow AirTalkShow()
        {
            return channel.TalkShow();
        }
        public NewsShow AirNewsShow()
        {
            return channel.News();
        }
        public Movie AirMovie()
        {
            return channel.Movie();
        }
    }
}

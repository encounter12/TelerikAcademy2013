﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    class Ctv : Channel
    {
        public override TalkShow TalkShow()
        {
            var show = new TalkShow("This morning");
            return show;
        }

        public override NewsShow News()
        {
            var show = new NewsShow("Ctv news");
            return show;
        }

        public override Movie Movie()
        {
            var show = new Movie("Taxi");
            return show;
        }

        public override string Name
        {
            get { return "Ctv"; }
        }
    }
}

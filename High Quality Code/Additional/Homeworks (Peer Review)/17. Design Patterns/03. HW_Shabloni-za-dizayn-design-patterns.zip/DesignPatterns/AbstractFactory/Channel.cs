﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    public abstract class Channel
    {

        public abstract string Name { get; }
        public abstract TalkShow TalkShow();
        public abstract NewsShow News();
        public abstract Movie Movie();

    }
}

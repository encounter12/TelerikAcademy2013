﻿namespace AbstractFactory
{
    using System;
    using System.Collections.Generic;

    public abstract class Show
    {
        public Show(string name)
        {
            this.Name = name;
        }

        public string Name { get; set; }
    }
}

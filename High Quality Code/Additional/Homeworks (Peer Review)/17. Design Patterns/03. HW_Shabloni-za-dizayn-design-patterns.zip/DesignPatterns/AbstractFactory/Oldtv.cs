﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    class Oldtv : Channel
    {
        public override TalkShow TalkShow()
        {
            var show = new TalkShow("Hallo, Bulgaria");
            return show;
        }

        public override NewsShow News()
        {
            var show = new NewsShow("Oldtv news");
            return show;
        }

        public override Movie Movie()
        {
            var show = new Movie("Frozen");
            return show;
        }

        public override string Name
        {
            get { return "Oldtv"; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    class GeometricFigures
    {
        public double sideA { get; private set; }
        public double sideB { get; private set; }
        public GeometricFigures(double a, double b)
        {
            this.sideA = a;
            this.sideB = b;
        }

        public void Area(AreaPattern shape)
        {
            shape.Area(sideA, sideB);
        }
    }
}

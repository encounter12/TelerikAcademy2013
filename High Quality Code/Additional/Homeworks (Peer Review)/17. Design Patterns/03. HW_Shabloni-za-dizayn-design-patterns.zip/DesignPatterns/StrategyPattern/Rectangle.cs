﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    class Rectangle : AreaPattern
    {
        public override void Area(double a, double height)
        {
            double result = a * height;
            Console.WriteLine("Area of a rectangle {0:F2}", result);
        }
    }
}

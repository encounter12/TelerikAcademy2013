﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    abstract class AreaPattern
    {
        public abstract void Area(double a, double height);
    }
}

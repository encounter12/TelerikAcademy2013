﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    class Ellipse : AreaPattern
    {
        public override void Area(double a, double b)
        {
            double result = a * b * Math.PI;
            Console.WriteLine("Area of a rectangle {0:F2}", result);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            GeometricFigures shapesArea = new GeometricFigures(7.35, 2.15);
            var triangle = new Triangle();
            var ellipse = new Ellipse();
            var rectangle = new Rectangle();
            shapesArea.Area(triangle);
            shapesArea.Area(ellipse);
            shapesArea.Area(rectangle);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MementoPattern
{
    class Momento
    {
        public Momento(int level, int punch, int health)
        {
            this.Health = health;
            this.Level = level;
            this.Punch = punch;
        }

        public int Level { get; set; }
        public int Punch { get; set; }
        public int Health { get; set; }
    }
}

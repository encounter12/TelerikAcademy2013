﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MementoPattern
{
    abstract class Boxer
    {
        public abstract int Level { get; set; }
        public abstract int Punch { get; set; }
        public abstract int Health { get; set; }
        public abstract bool isAlive { get; }

        public abstract void Attack(Boxer target);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MementoPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            var player = new Player(1);
            var enemy = new Enemy(1);
            Momento momento = null;
            int stage = 1;

            Random turnAttacking = new Random();

            GameLoop(player, ref enemy, ref momento, ref stage, turnAttacking);

            Undo(player, momento);

            GameLoop(player, ref enemy, ref momento, ref stage, turnAttacking);

        }

        private static void Undo(Player player, Momento momento)
        {
            player.Level = momento.Level;
            player.Punch = momento.Punch;
            player.Health = momento.Health;
        }

        private static void GameLoop(Player player, ref Enemy enemy, ref Momento momento, ref int stage, Random turnAttacking)
        {
            while (stage < 10)
            {
                if (player.isAlive)
                {
                    if (turnAttacking.Next(2) % 2 == 0)
                    {
                        player.Attack(enemy);
                        if (!enemy.isAlive)
                        {
                            stage++;
                            enemy = new Enemy(stage);
                            Console.WriteLine("Advace to the next level!");
                        }
                    }
                    else
                    {
                        enemy.Attack(player);
                    }
                }
                else
                {
                    Console.WriteLine("Game Over");
                    break;
                }

                if (stage == 2)
                {
                    player.Level++;
                    player.lvlUp();
                    momento = new Momento(player.Level, player.Punch, player.Health);
                }
            }
        }

    }
}

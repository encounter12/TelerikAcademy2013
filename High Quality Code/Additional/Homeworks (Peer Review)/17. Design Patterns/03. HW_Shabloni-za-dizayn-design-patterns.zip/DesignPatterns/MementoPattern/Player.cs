﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MementoPattern
{
    class Player : Boxer
    {

        public Player(int level)
        {
            this.Level = level;
            this.Health = 100 + (level * 10);
            this.Punch = 10 * level;
        }
        public override void Attack(Boxer target)
        {
            target.Health -= this.Punch;
            Console.WriteLine("Enemy health now is {0}", target.Health);
        }

        public override int Health { get; set; }

        public override bool isAlive
        {
            get
            {
                if (this.Health >= 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public override int Level { get; set; }

        public override int Punch { get; set; }

        public void lvlUp()
        {
            Console.WriteLine("Player increase in level!");
            this.Health = 100 + (this.Level * 10);
            this.Punch = 10 * this.Level;
        }
    }
}

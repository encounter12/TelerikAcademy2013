﻿namespace Memento
{
    using System;
    using System.Linq;

    public class RepositoryMemory
    {
        public Memento Memento { get; set; }
    }
}
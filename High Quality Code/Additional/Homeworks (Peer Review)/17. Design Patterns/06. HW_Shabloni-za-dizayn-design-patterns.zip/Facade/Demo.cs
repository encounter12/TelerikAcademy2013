﻿namespace Facade
{
    public class Demo
    {
        static void Main()
        {
            GameEngine game = new GameEngine();

            game.StartGame();
        }
    }
}
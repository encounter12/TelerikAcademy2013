﻿// <copyright file="Carrot.cs" company="Telerik Academy">
// Copyright (c) 2014 Telerik Academy. All rights reserved.
// </copyright>

namespace Chef
{
    /// <summary>
    /// Represents a carrot.
    /// </summary>
    public class Carrot : Vegetable
    {
    }
}

﻿// <copyright file="Vegetable.cs" company="Telerik Academy">
// Copyright (c) 2014 Telerik Academy. All rights reserved.
// </copyright>

namespace Chef
{
    /// <summary>
    /// Represents a vegetable.
    /// </summary>
    public class Vegetable
    {
        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Chef.Vegetable"/> is rotten.
        /// </summary>
        public bool IsRotten { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="Chef.Vegetable"/> is peeled.
        /// </summary>
        public bool IsPeeled { get; set; }
    }
}

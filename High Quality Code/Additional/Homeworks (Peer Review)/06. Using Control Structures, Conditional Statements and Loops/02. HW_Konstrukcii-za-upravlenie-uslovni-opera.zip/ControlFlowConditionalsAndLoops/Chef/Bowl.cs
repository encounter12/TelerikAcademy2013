﻿// <copyright file="Bowl.cs" company="Telerik Academy">
// Copyright (c) 2014 Telerik Academy. All rights reserved.
// </copyright>

namespace Chef
{
    /// <summary>
    /// Represents a bowl.
    /// </summary>
    public class Bowl
    {
        /// <summary>
        /// Adds a vegetable to the bowl.
        /// </summary>
        /// <param name="vegetable">Vegetable to add.</param>
        public void Add(Vegetable vegetable)
        {
        }
    }
}

﻿// <copyright file="TestChef.cs" company="Telerik Academy">
// Copyright (c) 2014 Telerik Academy. All rights reserved.
// </copyright>

namespace Chef
{
   public class TestChef
    {
        public void Main()
        {
            // Here is the first part from the task
            // Potato potato;
            Potato potato = new Potato();

            //// ...
            
            if (potato != null)
            {
                if (!potato.IsRotten && potato.IsPeeled)
                {
                   this.Cook(potato);
                }
            }

            // And the second
            const int MinX = -10;
            const int MaxX = 10;

            const int MaxY = 10;
            const int MinY = -10;

            int x = 0;
            int y = 0;

            bool shoudVisitCell = true;
            bool isYInRange = (MinY <= y) && (y <= MaxY);
            bool isXInRange = (MinX <= x) && (x <= MaxX);

            if (shoudVisitCell && (isXInRange && isYInRange))
            {
               this.VisitCell();
            }
        }

        private void VisitCell()
        {
            throw new System.NotImplementedException();
        }

        private void Cook(Vegetable vegetable)
        {
            // This method is different from those in Chef class. That is why I create it here.
        }
    }
}

﻿// <copyright file="Refactoring.cs" company="Telerik Academy">
// Copyright (c) 2014 Telerik Academy. All rights reserved.
// </copyright>

namespace LoopRefactoring
{
    using System;

    public class Refactoring
    {
        public static void Main()
        {
            int[] array = new int[100];
            int expectedValue = 123;

            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);

                if (array[i] == expectedValue)
                {
                    Console.WriteLine("Value Found");
                    break;
                }
            }
        }
    }
}

﻿namespace Abstraction
{
    using System;

    public class FiguresExample
    {
        private static void Main()
        {
            Circle circle = new Circle(5);
            double circlePerimeter = circle.CalculatePerimeter();
            double circleSurface = circle.CalculateSurface();

            Console.WriteLine(
                "I am a circle. " +
                "My perimeter is {0:f2}. My surface is {1:f2}.",
                circlePerimeter,
                circleSurface);

            Rectangle rectangle = new Rectangle(2, 3);
            double rectanglePerimeter = rectangle.CalculatePerimeter();
            double rectangleSurface = rectangle.CalculateSurface();

            Console.WriteLine(
                "I am a rectangle. " +
                "My perimeter is {0:f2}. My surface is {1:f2}.",
                rectanglePerimeter,
                rectangleSurface);
        }
    }
}

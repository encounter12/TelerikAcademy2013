﻿namespace Abstraction
{
    using System;

    public class Circle : IFigure
    {
        private double radius;
       
        public Circle(double radius)
        {
            this.Radius = radius;
        }

        public double Radius
        {
            get
            {
                return this.radius;
            }

            set
            {
                try
                {
                    if (value <= 0)
                    {
                        throw new ArgumentOutOfRangeException();
                    }
                    else if (value == null)
                    {
                        throw new ArgumentNullException();
                    }
                    else
                    {
                        this.radius = value;
                    }
                }
                catch (ArgumentOutOfRangeException ex)
                {
                    Console.Error.WriteLine(ex.Message);
                }
                catch (ArgumentNullException ne) 
                {
                    Console.Error.WriteLine(ne.Message);
                }
            }
        }

        public double CalcPerimeter()
        {
            double perimeter = 2 * Math.PI * this.Radius;
            return perimeter;
        }

        public double CalcSurface()
        {
            double surface = Math.PI * this.Radius * this.Radius;
            return surface;
        }
    }
}

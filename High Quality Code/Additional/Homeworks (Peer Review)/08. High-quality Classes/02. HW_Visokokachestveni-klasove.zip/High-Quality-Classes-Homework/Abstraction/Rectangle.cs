﻿namespace Abstraction
{
    using System;

    public class Rectangle : IFigure
    {
        private double width;
        private double height;

        public Rectangle(double width, double height)
        {
            this.Width = width;
            this.Height = height;
        }

        public double Width
        {
            get
            {
                return this.width;
            }

            set
            {
                try
                {
                    if (value <= 0 || value == null)
                    {
                        throw new ArgumentOutOfRangeException();
                    }
                    else if (value == null)
                    {
                        throw new ArgumentNullException();
                    }
                    else
                    {
                        this.width = value;
                    }
                }
                catch (ArgumentOutOfRangeException ex)
                {
                    Console.Error.WriteLine(ex.Message);
                }
                catch (ArgumentNullException ne)
                {
                    Console.Error.WriteLine(ne.Message);
                }
            }
        }

        public double Height
        {
            get
            {
                return this.height;
            }

            set
            {
                try
                {
                    if (value <= 0 || value == null)
                    {
                        throw new ArgumentOutOfRangeException();
                    }
                    else if (value == null)
                    {
                        throw new ArgumentNullException();
                    }
                    else
                    {
                        this.height = value;
                    }
                }
                catch (ArgumentOutOfRangeException ex)
                {
                    Console.Error.WriteLine(ex.Message);
                }
                catch (ArgumentNullException ne)
                {
                    Console.Error.WriteLine(ne.Message);
                }
            }
        }

        public double CalcPerimeter()
        {
            double perimeter = 2 * (this.Width + this.Height);
            return perimeter;
        }

        public double CalcSurface()
        {
            double surface = this.Width * this.Height;
            return surface;
        }
    }
}

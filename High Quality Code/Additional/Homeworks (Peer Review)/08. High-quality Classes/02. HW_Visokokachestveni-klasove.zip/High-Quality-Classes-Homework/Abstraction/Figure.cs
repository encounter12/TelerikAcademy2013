﻿namespace Abstraction
{
    using System;

    interface IFigure
    {
        double CalcPerimeter();

        double CalcSurface();
    }
}

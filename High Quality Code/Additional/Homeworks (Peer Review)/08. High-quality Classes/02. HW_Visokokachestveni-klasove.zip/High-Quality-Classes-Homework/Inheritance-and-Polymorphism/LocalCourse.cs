﻿namespace InheritanceAndPolymorphism
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class LocalCourse : Cource
    {
        private string lab;

        public LocalCourse(string name)
            : base(name)
        {
            this.Lab = null;
        }

        public LocalCourse(string courseName, string teacherName)
            : base(courseName, teacherName)
        {
            this.Lab = null;
        }

        public LocalCourse(string courseName, string teacherName, IList<string> students)
            : base(courseName, teacherName, students)
        {
            this.Lab = null;
        }

        public string Lab
        {
            get
            {
                return this.lab;
            }

            set
            {
                try
                {
                    if (value == string.Empty)
                    {
                        throw new ArgumentNullException();
                    }
                    else
                    {
                        this.lab = value;
                    }
                }
                catch (ArgumentNullException ex)
                {
                    Console.Error.WriteLine(ex.Message);
                }
            }
        }

        public override string ToString()
        {
            return this.ToStringHelper(new KeyValuePair<string, string>("Lab", this.Lab));
        }
    }
}

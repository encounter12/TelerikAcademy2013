﻿namespace Poker
{
    using System;
    using System.Collections.Generic;

    public class PokerHandsChecker : IPokerHandsChecker
    {
        public bool IsValidHand(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            if (hand.Cards.Count != 5)
            {
                return false;
            }

            HashSet<Card> currentHand = new HashSet<Card>();
            foreach (var card in hand.Cards)
            {
                if (currentHand.Contains(card as Card))
                {
                    return false;
                }

                currentHand.Add(card as Card);
            }

            return true;
        }

        public bool IsStraightFlush(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            if (this.IsStraight(hand) && this.IsFlush(hand))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsFourOfAKind(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            Dictionary<int, int> currentHand = new Dictionary<int, int>();

            foreach (var card in hand.Cards)
            {
                int cardFaceKey = (int)card.Face;

                if (currentHand.ContainsKey(cardFaceKey))
                {
                    currentHand[cardFaceKey]++;
                }
                else
                {
                    currentHand[cardFaceKey] = 1;
                }
            }

            if (currentHand.ContainsValue(4))
            {
                return true;
            }

            return false;
        }

        public bool IsFullHouse(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            Dictionary<int, int> currentHand = new Dictionary<int, int>();

            foreach (var card in hand.Cards)
            {
                int cardFaceKey = (int)card.Face;

                if (currentHand.ContainsKey(cardFaceKey))
                {
                    currentHand[cardFaceKey]++;
                }
                else
                {
                    currentHand[cardFaceKey] = 1;
                }
            }

            if (currentHand.ContainsValue(3) && currentHand.ContainsValue(2))
            {
                return true;
            }

            return false;
        }

        public bool IsFlush(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            CardSuit firstCardSuit = hand.Cards[0].Suit;

            foreach (var card in hand.Cards)
            {
                if (firstCardSuit != card.Suit)
                {
                    return false;
                }
            }

            return true;
        }

        public bool IsStraight(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            var sortedHand = hand.Cards as List<ICard>;
            sortedHand.Sort((x, y) => x.Face.CompareTo(y.Face));

            for (int i = 1; i < sortedHand.Count; i++)
            {
                if (sortedHand[i - 1].Face - sortedHand[i].Face != -1)
                {
                    return false;
                }
            }

            return true;
        }

        public bool IsThreeOfAKind(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            Dictionary<int, int> currentHand = new Dictionary<int, int>();

            foreach (var card in hand.Cards)
            {
                int cardFaceKey = (int)card.Face;

                if (currentHand.ContainsKey(cardFaceKey))
                {
                    currentHand[cardFaceKey]++;
                }
                else
                {
                    currentHand[cardFaceKey] = 1;
                }
            }

            if (currentHand.ContainsValue(3) && !currentHand.ContainsValue(2))
            {
                return true;
            }

            return false;
        }

        public bool IsTwoPair(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            Dictionary<int, int> currentHand = new Dictionary<int, int>();

            foreach (var card in hand.Cards)
            {
                int cardFaceKey = (int)card.Face;

                if (currentHand.ContainsKey(cardFaceKey))
                {
                    currentHand[cardFaceKey]++;
                }
                else
                {
                    currentHand[cardFaceKey] = 1;
                }
            }

            if (currentHand.Keys.Count == 3 && !currentHand.ContainsValue(3))
            {
                return true;
            }

            return false;
        }

        public bool IsOnePair(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            HashSet<int> currentHand = new HashSet<int>();

            foreach (var card in hand.Cards)
            {
                int cardFaceAsInt = (int)card.Face;

                currentHand.Add(cardFaceAsInt);
            }

            if (currentHand.Count == 4)
            {
                return true;
            }

            return false;
        }

        public bool IsHighCard(IHand hand)
        {
            if (hand == null)
            {
                throw new ArgumentNullException("Error: hand cannot be null");
            }

            if (this.IsStraightFlush(hand) || this.IsFourOfAKind(hand) || this.IsFullHouse(hand) ||
                this.IsFlush(hand) || this.IsStraight(hand) || this.IsThreeOfAKind(hand) ||
                this.IsTwoPair(hand) || this.IsOnePair(hand))
            {
                return false;
            }

            return true;
        }

        public int CompareHands(IHand firstHand, IHand secondHand)
        {
            if (!this.IsValidHand(firstHand))
            {
                throw new ArgumentException("Error: first hand is not valid");
            }

            if (!this.IsValidHand(secondHand))
            {
                throw new ArgumentException("Error: second hand is not valid");
            }

            if (this.CheckHandType(firstHand) - this.CheckHandType(secondHand) > 0)
            {
                return 1;
            }
            else if (this.CheckHandType(firstHand) - this.CheckHandType(secondHand) == 0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }

        private HandType CheckHandType(IHand hand)
        {
            if (this.IsStraightFlush(hand))
            {
                return HandType.StraightFlush;       
            }
            else if (this.IsFourOfAKind(hand))
            {
                return HandType.FourOfKind;
            }
            else if (this.IsFullHouse(hand))
            {
                return HandType.FullHouse;
            }
            else if (this.IsFlush(hand))
            {
                return HandType.Flush;
            }
            else if (this.IsStraight(hand))
            {
                return HandType.Straight;
            }
            else if (this.IsThreeOfAKind(hand))
            {
                return HandType.ThreeOfAKind;
            }
            else if (this.IsTwoPair(hand))
            {
                return HandType.TwoPair;
            }
            else if (this.IsOnePair(hand))
            {
                return HandType.OnePair;
            }
            else 
            {
                return HandType.HighCard;
            }
        }
    }
}

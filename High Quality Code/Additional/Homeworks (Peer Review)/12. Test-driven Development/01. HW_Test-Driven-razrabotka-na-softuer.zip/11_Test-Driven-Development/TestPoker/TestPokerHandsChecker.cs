﻿namespace TestPoker
{
    using System;    
    using System.Collections.Generic;
    using System.Diagnostics;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Poker;

    [TestClass]
    public class TestPokerHandsChecker
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void IsValidHandThrowExceptionIfHandIsNull()
        {
            IHand testHand = null;
            PokerHandsChecker checker = new PokerHandsChecker();

            checker.IsValidHand(testHand);
        }

        [TestMethod]
        public void IsValidHandReturnFalseIfCardsCountIsNotFive()
        {
            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Ace, CardSuit.Clubs),
                new Card(CardFace.Ace, CardSuit.Diamonds),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Spades),
            });

            PokerHandsChecker checker = new PokerHandsChecker();

            bool isValidHandOutput = checker.IsValidHand(testHand);
            bool expectedOutput = false;

            Debug.Assert(isValidHandOutput == expectedOutput, "Method must return false, cards count is 4");
        }

        [TestMethod]
        public void IsValidHandReturnFalseIfHaveDuplicateCard()
        {
            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Ace, CardSuit.Clubs),
                new Card(CardFace.Ace, CardSuit.Diamonds),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Spades),
                new Card(CardFace.King, CardSuit.Spades)
            });

            PokerHandsChecker checker = new PokerHandsChecker();

            bool isValidHandOutput = checker.IsValidHand(testHand);
            bool expectedOutput = false;

            Debug.Assert(isValidHandOutput == expectedOutput, "Duplicate card exists, metho should return false");
        }

        [TestMethod]
        public void IsStraightFlushReturnTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Six, CardSuit.Clubs),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Three, CardSuit.Clubs)
            });

            bool isStraightFlushOutput = checker.IsStraightFlush(testHand);
            bool expectedOutput = true;

            Assert.AreEqual(expectedOutput, isStraightFlushOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Ten, CardSuit.Clubs),
                new Card(CardFace.Jack, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Clubs),
                new Card(CardFace.King, CardSuit.Clubs),
                new Card(CardFace.Ace, CardSuit.Clubs)
            });

            isStraightFlushOutput = checker.IsStraightFlush(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isStraightFlushOutput);
        }

        [TestMethod]
        public void IsStraightFlushReturnFalse()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Three, CardSuit.Clubs),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Six, CardSuit.Spades)
            });

            bool isStraightFlushOutput = checker.IsStraightFlush(testHand);
            bool expectedOutput = false;

            Assert.AreEqual(expectedOutput, isStraightFlushOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Three, CardSuit.Clubs),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Seven, CardSuit.Clubs)
            });

            isStraightFlushOutput = checker.IsStraightFlush(testHand);
            expectedOutput = false;

            Assert.AreEqual(expectedOutput, isStraightFlushOutput);
        }

        [TestMethod]
        public void IsFourOfAKindReturnTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Two, CardSuit.Spades),
                new Card(CardFace.Two, CardSuit.Hearts),
                new Card(CardFace.Two, CardSuit.Diamonds),
                new Card(CardFace.Six, CardSuit.Spades)
            });

            bool isFourOfAKindOutput = checker.IsFourOfAKind(testHand);
            bool expectedOutput = true;

            Assert.AreEqual(expectedOutput, isFourOfAKindOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.King, CardSuit.Clubs),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Queen, CardSuit.Clubs),
                new Card(CardFace.King, CardSuit.Diamonds),
                new Card(CardFace.King, CardSuit.Spades)
            });

            isFourOfAKindOutput = checker.IsFourOfAKind(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isFourOfAKindOutput);
        }

        [TestMethod]
        public void IsFourOfAKindReturnFalse()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Two, CardSuit.Spades),
                new Card(CardFace.Two, CardSuit.Hearts),
                new Card(CardFace.Seven, CardSuit.Diamonds),
                new Card(CardFace.Six, CardSuit.Spades)
            });

            bool isFourOfAKindOutput = checker.IsFourOfAKind(testHand);
            bool expectedOutput = false;

            Assert.AreEqual(expectedOutput, isFourOfAKindOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.King, CardSuit.Clubs),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.King, CardSuit.Diamonds),
                new Card(CardFace.Ace, CardSuit.Spades)
            });

            isFourOfAKindOutput = checker.IsFourOfAKind(testHand);
            expectedOutput = false;

            Assert.AreEqual(expectedOutput, isFourOfAKindOutput);
        }

        [TestMethod]
        public void IsFullHouseReturnTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Two, CardSuit.Spades),
                new Card(CardFace.Two, CardSuit.Hearts),
                new Card(CardFace.Six, CardSuit.Diamonds),
                new Card(CardFace.Six, CardSuit.Spades)
            });

            bool isFullHouseOutput = checker.IsFullHouse(testHand);
            bool expectedOutput = true;

            Assert.AreEqual(expectedOutput, isFullHouseOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.King, CardSuit.Clubs),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Queen, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Diamonds),
                new Card(CardFace.King, CardSuit.Spades)
            });

            isFullHouseOutput = checker.IsFullHouse(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isFullHouseOutput);
        }

        [TestMethod]
        public void IsFullHouseReturnFalse()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Two, CardSuit.Spades),
                new Card(CardFace.Two, CardSuit.Hearts),
                new Card(CardFace.Six, CardSuit.Diamonds),
                new Card(CardFace.Seven, CardSuit.Spades)
            });

            bool isFullHouseOutput = checker.IsFullHouse(testHand);
            bool expectedOutput = false;

            Assert.AreEqual(expectedOutput, isFullHouseOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.King, CardSuit.Clubs),
                new Card(CardFace.Ace, CardSuit.Hearts),
                new Card(CardFace.Queen, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Diamonds),
                new Card(CardFace.King, CardSuit.Spades)
            });

            isFullHouseOutput = checker.IsFullHouse(testHand);
            expectedOutput = false;

            Assert.AreEqual(expectedOutput, isFullHouseOutput);
        }

        [TestMethod]
        public void IsFlushRetunTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Three, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Clubs),
                new Card(CardFace.King, CardSuit.Clubs),
                new Card(CardFace.Seven, CardSuit.Clubs)
            });

            bool isFlushOutput = checker.IsFlush(testHand);
            bool expectedOutput = true;

            Assert.AreEqual(expectedOutput, isFlushOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Three, CardSuit.Hearts),
                new Card(CardFace.Queen, CardSuit.Hearts),
                new Card(CardFace.Jack, CardSuit.Hearts),
                new Card(CardFace.Ten, CardSuit.Hearts)
            });

            isFlushOutput = checker.IsFlush(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isFlushOutput);
        }

        [TestMethod]
        public void IsFlushRetunFalse()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Clubs),
                new Card(CardFace.Three, CardSuit.Clubs),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Diamonds),
                new Card(CardFace.Six, CardSuit.Clubs)
            });

            bool isFlushOutput = checker.IsFlush(testHand);
            bool expectedOutput = false;
            
            Assert.AreEqual(expectedOutput, isFlushOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Three, CardSuit.Hearts),
                new Card(CardFace.Queen, CardSuit.Diamonds),
                new Card(CardFace.Jack, CardSuit.Hearts),
                new Card(CardFace.Ten, CardSuit.Hearts)
            });

            isFlushOutput = checker.IsFlush(testHand);
            expectedOutput = false;

            Assert.AreEqual(expectedOutput, isFlushOutput);
        }

        [TestMethod]
        public void IsStraightReturnTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Hearts),
                new Card(CardFace.Three, CardSuit.Clubs),
                new Card(CardFace.Four, CardSuit.Diamonds),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Six, CardSuit.Spades)
            });

            bool isStraightOutput = checker.IsStraight(testHand);
            bool expectedOutput = true;
            
            Assert.AreEqual(expectedOutput, isStraightOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Ace, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Queen, CardSuit.Diamonds),
                new Card(CardFace.Jack, CardSuit.Clubs),
                new Card(CardFace.Ten, CardSuit.Spades)
            });

            isStraightOutput = checker.IsStraight(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isStraightOutput);
        }

        [TestMethod]
        public void IsStraightReturnFalse()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Two, CardSuit.Hearts),
                new Card(CardFace.Three, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Diamonds),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Six, CardSuit.Spades)
            });

            bool isStraightOutput = checker.IsStraight(testHand);
            bool expectedOutput = false;

            Assert.AreEqual(expectedOutput, isStraightOutput);            
        }

        [TestMethod]
        public void IsThreeOfAKindReturnTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Three, CardSuit.Clubs),
                new Card(CardFace.Four, CardSuit.Diamonds),
                new Card(CardFace.Six, CardSuit.Clubs),
                new Card(CardFace.Six, CardSuit.Spades)
            });

            bool isThreeOfAKindOutput = checker.IsThreeOfAKind(testHand);
            bool expectedOutput = true;

            Assert.AreEqual(expectedOutput, isThreeOfAKindOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Ace, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Queen, CardSuit.Diamonds),
                new Card(CardFace.Ace, CardSuit.Clubs),
                new Card(CardFace.Ace, CardSuit.Spades)
            });

            isThreeOfAKindOutput = checker.IsThreeOfAKind(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isThreeOfAKindOutput);
        }

        [TestMethod]
        public void IsThreeOfAKindReturnFalse()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Four, CardSuit.Diamonds),
                new Card(CardFace.Six, CardSuit.Clubs),
                new Card(CardFace.Six, CardSuit.Spades)
            });

            bool isThreeOfAKindOutput = checker.IsThreeOfAKind(testHand);
            bool expectedOutput = false;

            // Return false (full house)
            Assert.AreEqual(expectedOutput, isThreeOfAKindOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Ace, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Diamonds),
                new Card(CardFace.Ace, CardSuit.Clubs),
                new Card(CardFace.Ace, CardSuit.Spades)
            });

            isThreeOfAKindOutput = checker.IsThreeOfAKind(testHand);
            expectedOutput = false;
            
            // Return false (full house)
            Assert.AreEqual(expectedOutput, isThreeOfAKindOutput);
        }

        [TestMethod]
        public void IsTwoPairReturnTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Four, CardSuit.Diamonds),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Spades)
            });

            bool isTwoPairsOutput = checker.IsTwoPair(testHand);
            bool expectedOutput = true;
                        
            Assert.AreEqual(expectedOutput, isTwoPairsOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Ace, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Diamonds),
                new Card(CardFace.Ace, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Spades)
            });

            isTwoPairsOutput = checker.IsTwoPair(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isTwoPairsOutput);
        }

        [TestMethod]
        public void IsTwoPairReturnFalse()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Diamonds),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Spades)
            });

            bool isTwoPairsOutput = checker.IsTwoPair(testHand);
            bool expectedOutput = false;

            Assert.AreEqual(expectedOutput, isTwoPairsOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Jack, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Diamonds),
                new Card(CardFace.Ace, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Spades)
            });

            isTwoPairsOutput = checker.IsTwoPair(testHand);
            expectedOutput = false;

            Assert.AreEqual(expectedOutput, isTwoPairsOutput);
        }

        [TestMethod]
        public void IsOnePairReturnTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Diamonds),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Spades)
            });

            bool isTwoPairsOutput = checker.IsOnePair(testHand);
            bool expectedOutput = true;

            Assert.AreEqual(expectedOutput, isTwoPairsOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Jack, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Diamonds),
                new Card(CardFace.Ace, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Spades)
            });

            isTwoPairsOutput = checker.IsOnePair(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isTwoPairsOutput);
        }

        [TestMethod]
        public void IsOnePairReturnFalse()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Four, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Diamonds),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Spades)
            });

            bool isTwoPairsOutput = checker.IsOnePair(testHand);
            bool expectedOutput = false;

            Assert.AreEqual(expectedOutput, isTwoPairsOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Jack, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Two, CardSuit.Diamonds),
                new Card(CardFace.Ace, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Spades)
            });

            isTwoPairsOutput = checker.IsOnePair(testHand);
            expectedOutput = false;

            Assert.AreEqual(expectedOutput, isTwoPairsOutput);
        }

        [TestMethod]
        public void IsHighCardReturnTrue()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Jack, CardSuit.Clubs),
                new Card(CardFace.Five, CardSuit.Diamonds),
                new Card(CardFace.Queen, CardSuit.Clubs),
                new Card(CardFace.Three, CardSuit.Spades)
            });

            bool isHighCardOutput = checker.IsHighCard(testHand);
            bool expectedOutput = true;

            Assert.AreEqual(expectedOutput, isHighCardOutput);

            testHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Jack, CardSuit.Hearts),
                new Card(CardFace.King, CardSuit.Hearts),
                new Card(CardFace.Two, CardSuit.Diamonds),
                new Card(CardFace.Five, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Spades)
            });

            isHighCardOutput = checker.IsHighCard(testHand);
            expectedOutput = true;

            Assert.AreEqual(expectedOutput, isHighCardOutput);
        }

        [TestMethod]
        public void CompareHandsStraightFlushVsFourOfAKind()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand firstHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Seven, CardSuit.Hearts),
                new Card(CardFace.Eight, CardSuit.Hearts),
                new Card(CardFace.Nine, CardSuit.Hearts),
                new Card(CardFace.Ten, CardSuit.Hearts)
            });            

            IHand secondHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Jack, CardSuit.Hearts),
                new Card(CardFace.Jack, CardSuit.Spades),
                new Card(CardFace.Jack, CardSuit.Diamonds),
                new Card(CardFace.Jack, CardSuit.Clubs),
                new Card(CardFace.Queen, CardSuit.Spades)
            });

            int comparisonResult = checker.CompareHands(firstHand, secondHand);
            int expectedOutput = 1;

            Assert.AreEqual(expectedOutput, comparisonResult);
        }

        [TestMethod]
        public void CompareHandsStraightFlushVsStraightFlush()
        {
            PokerHandsChecker checker = new PokerHandsChecker();

            IHand firstHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Six, CardSuit.Hearts),
                new Card(CardFace.Seven, CardSuit.Hearts),
                new Card(CardFace.Eight, CardSuit.Hearts),
                new Card(CardFace.Nine, CardSuit.Hearts),
                new Card(CardFace.Ten, CardSuit.Hearts)
            });

            IHand secondHand = new Hand(new List<ICard>()
            {
                new Card(CardFace.Ten, CardSuit.Spades),
                new Card(CardFace.Jack, CardSuit.Spades),
                new Card(CardFace.Queen, CardSuit.Spades),
                new Card(CardFace.King, CardSuit.Spades),
                new Card(CardFace.Ace, CardSuit.Spades)
            });

            int comparisonResult = checker.CompareHands(firstHand, secondHand);
            int expectedOutput = 0;

            Assert.AreEqual(expectedOutput, comparisonResult);
        }
    }
}

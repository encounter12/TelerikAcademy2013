﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniTestingHomework
{
    public class Course
    {
        public const byte MaxStudentsCountInCourse = 29;
        private HashSet<Student> students = new HashSet<Student>();
        private string name;

        public Course() { }
        public Course(string name)
        {
            Name = name;
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("Name can not be missing!");
                    
                }
                this.name = value;
            }
        }

        public List<Student> Students
        {
            get
            {
                return this.students.ToList();
            }
        }

        public void AddStudent(Student student)
        {
            if (students.Count == MaxStudentsCountInCourse)
            {
                throw new ArgumentException("Can't add more than 30 Students in one Course!");
            }

            students.Add(student);
        }

        public void RemoveStudent(Student student)
        {
            if (students.Count == null || students.Count < 1)
            {
                throw new ArgumentException("Can't remove students from empty course.");
            }

            students.Remove(student);
        }
    }
}

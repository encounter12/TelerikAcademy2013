﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniTestingHomework
{
    public class School
    {
        public School(List<Course> courses)
        {
            this.Courses = new List<Course>();
        }

        public List<Course> Courses { get; set; }

        public void AddCourse(Course course)
        {
            this.Courses.Add(course);
        }

    }
}

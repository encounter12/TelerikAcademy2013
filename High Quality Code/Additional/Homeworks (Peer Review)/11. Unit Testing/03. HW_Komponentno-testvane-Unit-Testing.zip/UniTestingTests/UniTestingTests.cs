﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UniTestingHomework;

namespace UniTestingTests
{
    [TestClass]
    public class UniTestingTests
    {
        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void CheckStudenNameThrowExeption()
        {
            var pesho = new Student(null, 10000);
        }

        [TestMethod]
        public void CheckStudenName()
        {
            var pesho = new Student("Pesho Petrov", 10002);
            var excpected = "Pesho Petrov";
            var actual = pesho.Name;
            Assert.AreEqual(excpected, actual);
        }

        [TestMethod]
        public void CheckStudenID()
        {
            var pesho = new Student("Pesho Petrov", 20002);
            var excpected = 20002;
            var actual = pesho.ID;
            Assert.AreEqual(excpected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CheckStudenIDThrowExeption()
        {
            var pesho = new Student();
            pesho.ID = 21;
        }

        [TestMethod]
        public void CheckCourseAddMethod()
        {
            var newCourse = new Course();
            for (int i = 0; i < 29; i++)
            {
                newCourse.AddStudent(new Student("Pesho" + i, 10000+i+2));
            }
            var excpected = 29;
            var actual = newCourse.Students.Count;
            Assert.AreEqual(excpected, actual);
        }

        [TestMethod]
        public void CheckCourseConstructorWithName()
        {
            var newCourse = new Course("JavaScript");
            var excpected = "JavaScript";
            var actual = newCourse.Name;
            Assert.AreEqual(excpected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CheckCourseConstructorWithNameThrowExeptionForNull()
        {
            var newCourse = new Course(null);
        }
    }
}

(function () {

    var browser = navigator.appName;
    var addScroll = false;
    var theLayer;
    var positionX = 0;
    var positionX = 0;

    if ((navigator.userAgent.indexOf('MSIE 5') > 0) || (navigator.userAgent.indexOf('MSIE 6')) > 0) {
        addScroll = true;
    }

    if (browser === "Netscape") {
        document.captureEvents(Event.MOUSEMOVE);
    }

    document.onmousemove = mouseMove;

    function mouseMove(event) {
        if (browser === "Netscape") {
            positionX = event.pageX - 5;
            positionX = event.pageY;

            try {
                if (document.layers.ToolTip.visibility === "show") {
                    popTip();
                }
            } catch (error) {
                // log the error
                throw new Error(error);
            }
        }
        else {
            positionX = event.x - 5;
            positionX = event.y;

            try {
                if (document.all.ToolTip.style.visibility === "visible") {
                    popTip();
                }
            } catch (error) {
                // log the error
                throw new Error(error);
            }
        }        
    }

    function popTip() {
        if (browser === "Netscape") {
            theLayer = eval("document.layers.ToolTip");

            if ((positionX + 120) > window.innerWidth) {
                positionX = window.innerWidth - 150;
            }

            theLayer.left = positionX + 10;
            theLayer.top = positionX + 15;
            theLayer.visibility = "show";
        }
        else {
            theLayer = eval("document.all.ToolTip");
            if (theLayer) {
                positionX = event.x - 5;
                positionX = event.y;

                if (addScroll) {
                    positionX = positionX + document.body.scrollLeft;
                    positionX = positionX + document.body.scrollTop;
                }

                if ((positionX + 120) > document.body.clientWidth) {
                    positionX = positionX - 150;
                }

                theLayer.style.pixelLeft = positionX + 10;
                theLayer.style.pixelTop = positionX + 15;
                theLayer.style.visibility = "visible";
            }
        }
    }

    function hideTip() {
        if (browser === "Netscape") {
            document.layers.ToolTip.visibility = "hide";
        }
        else {
            document.all.ToolTip.style.visibility = "hidden";
        }
    }

    function hideMenu(menu) {
        if (browser === "Netscape") {
            document.layers[menu].visibility = "hide";
        }
        else {
            document.all[menu].style.visibility = "hidden";
        }
    }

    function showMenu(menu) {
        if (browser === "Netscape") {
            theLayer = eval("document.layers[" + menu + "]");
            theLayer.visibility = "show";
        }
        else {
            theLayer = eval("document.all[" + menu + "]");
            theLayer.style.visibility = "visible";
        }
    }
})();
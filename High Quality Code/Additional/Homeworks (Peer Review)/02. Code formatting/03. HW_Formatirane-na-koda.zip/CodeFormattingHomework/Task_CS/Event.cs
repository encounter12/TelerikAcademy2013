﻿namespace Events
{
    using System;
    using System.IO;
    using System.Text;

    /// <summary>
    /// Class which is representing an event
    /// Called by EventHolder class
    /// </summary>
    public class Event : IComparable
    {
        #region Variable fields

        private readonly string dateFormat = "yyyy-MM-ddTHH:mm:ss";
        private DateTime currentDate;
        private string title;
        private string location;

        #endregion Variable fields

        #region Constructors

        public Event(DateTime currentDate, string title, string location)
        {
            this.CurrentDate = currentDate;
            this.Title = title;
            this.Location = location;
        }

        #endregion Constructor 

        #region Property fields

        public DateTime CurrentDate
        {
            get
            {
                return this.currentDate;
            }

            private set
            {
                this.currentDate = value;
            }
        }

        public string Title
        {
            get
            {
                return this.title;
            }

            private set
            {
                this.title = value;
            }
        }

        public string Location
        {
            get
            {
                return this.location;
            }

            private set
            {
                this.location = value;
            }
        }

        #endregion Property fields

        #region Methods
        public int CompareTo(object comparedObject)
        {
            if (comparedObject == null)
            {
                return 1;
            }

            Event comparedEvent = comparedObject as Event;
            if (comparedEvent != null)
            {
                int byDate = this.CurrentDate.CompareTo(comparedEvent.CurrentDate);
                int byTitle = this.Title.CompareTo(comparedEvent.Title);
                int byLocation = this.Location.CompareTo(comparedEvent.Location);

                if (byDate == 0)
                {
                    if (byTitle == 0)
                    {
                        return byLocation;
                    }
                    else
                    {
                        return byTitle;
                    }
                }
                else
                {
                    return byDate;
                }
            }
            else
            {
                throw new ArgumentException("The given event is not initialized correctly");
            }
        }

        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.Append(this.CurrentDate.ToString(this.dateFormat));

            stringBuilder.Append(" | " + this.Title);

            if (!string.IsNullOrWhiteSpace(this.Location))
            {
                stringBuilder.Append(" | " + this.Location);
            }

            return stringBuilder.ToString();
        }

        #endregion
    }
}

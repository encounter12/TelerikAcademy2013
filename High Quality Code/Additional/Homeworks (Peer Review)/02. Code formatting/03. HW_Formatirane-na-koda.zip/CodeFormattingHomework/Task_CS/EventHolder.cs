﻿namespace Events
{
    using System;
    using Wintellect.PowerCollections;

    /// <summary>
    /// Class which is representing a storage for events
    /// Called by demo application
    /// </summary>
    public class EventHolder
    {
        private readonly MultiDictionary<string, Event> byTitle = new MultiDictionary<string, Event>(true);
        private readonly OrderedBag<Event> byDate = new OrderedBag<Event>();

        public void AddEvent(DateTime currentDate, string title, string location)
        {
            Event newEvent = new Event(currentDate, title, location);
            this.byTitle.Add(title.ToLower(), newEvent);
            this.byDate.Add(newEvent);
            EventMessage.EventAdded();
        }

        // Deletes all events with a given title, performs a case insensitive search
        public void DeleteEvents(string titleToDelete)
        {
            string title = titleToDelete.ToLower();
            int removed = 0;
            foreach (var eventToRemove in this.byTitle[title])
            {
                removed++;
                this.byDate.Remove(eventToRemove);
            }

            this.byTitle.Remove(title);
            EventMessage.EventDeleted(removed);
        }

        public void ListEvents(DateTime currentDate, int count)
        {
            OrderedBag<Event>.View eventsToShow = this.byDate.RangeFrom(new Event(currentDate, string.Empty, string.Empty), true);
            int shown = 0;
            foreach (var eventToShow in eventsToShow)
            {
                if (shown == count)
                {
                    break;
                }

                EventMessage.PrintEvent(eventToShow);

                shown++;
            }

            if (shown == 0)
            {
                EventMessage.NoEventsFound();
            }
        }
    }
}

﻿namespace Events
{
    using System;
    using System.Text;

    /// <summary>
    /// Class which outputs feedback log information
    /// Called by EventHolder class
    /// </summary>
    public static class EventMessage
    {
        private static StringBuilder stringBuilder = new StringBuilder();

        public static string OutputString
        {
            get
            {
                return stringBuilder.ToString();
            }
        }

        public static void EventAdded()
        {
            stringBuilder.Append("Event added" + Environment.NewLine);
        }

        public static void EventDeleted(int amount)
        {
            if (amount == 0)
            {
                NoEventsFound();
            }
            else
            {
                stringBuilder.AppendFormat("{0} events deleted{1}", amount, Environment.NewLine);
            }
        }

        public static void NoEventsFound()
        {
            stringBuilder.Append("No events found" + Environment.NewLine);
        }

        public static void PrintEvent(Event eventToPrint)
        {
            if (eventToPrint != null)
            {
                stringBuilder.Append(eventToPrint + Environment.NewLine);
            }
        }
    } 
}
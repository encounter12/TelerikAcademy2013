﻿namespace EventsTests
{
    using System;
    using Events;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Some unit tests of the "Events" application
    /// </summary>
    [TestClass]
    public class EventsTest
    {
        /// test event and date initializing
        [TestMethod]
        public void TestEventDate()
        {
            Event meeting = new Event(new DateTime(2014, 4, 1, 10, 0, 0), "Meeting title", "Meeting place");
            Assert.AreEqual("2014-04-01T10:00:00", meeting.CurrentDate.ToString("yyyy-MM-ddTHH:mm:ss"));
        }

        /// test event and title initializing
        [TestMethod]
        public void TestEventTitle()
        {
            Event meeting = new Event(new DateTime(2014, 4, 1, 10, 0, 0), "Meeting title", "Meeting place");
            Assert.AreEqual("Meeting title", meeting.Title);
        }


        /// test event and location initializing
        [TestMethod]
        public void TestEventLocation()
        {
            Event meeting = new Event(new DateTime(2014, 4, 1, 10, 0, 0), "Meeting title", "Meeting place");
            Assert.AreEqual("Meeting place", meeting.Location);
        }

        /// test event and ToString method
        [TestMethod]
        public void TestEventToString()
        {
            Event meeting = new Event(new DateTime(2014, 4, 1, 10, 0, 0), "Meeting title", "Meeting place");
            Assert.AreEqual("2014-04-01T10:00:00 | Meeting title | Meeting place", meeting.ToString());
        }

        /// test event and CompareTo method
        [TestMethod]
        public void TestEventCompareTo3()
        {
            Event meeting1 = new Event(new DateTime(2014, 4, 1, 10, 0, 0), "Meeting title", "Meeting place 1");
            Event meeting2 = new Event(new DateTime(2014, 4, 1, 10, 0, 0), "Meeting title", "Meeting place 2");

            Assert.AreEqual(true, meeting1.CompareTo(meeting2) < 0);
        }

        /// test event and AddEvent method
        [TestMethod]
        public void TestAddEvent()
        {
            EventHolder eventHolder = new EventHolder();
            eventHolder.AddEvent(new DateTime(2014, 4, 1, 10, 0, 0), "Meeting title", "Meeting place 1");

            Assert.AreEqual("Event added" + Environment.NewLine, EventMessage.OutputString);
        }

        /// test event and DeleteEvents method
        [TestMethod]
        public void TestDeleteEvents()
        {
            EventHolder eventHolder = new EventHolder();
            eventHolder.AddEvent(new DateTime(2014, 4, 1, 10, 0, 0), "Meeting title", "Meeting place");
            eventHolder.DeleteEvents("Meeting title");
            Assert.AreEqual("Event added" + Environment.NewLine + "Event added" + Environment.NewLine + "1 events deleted" + Environment.NewLine, EventMessage.OutputString);
        }
    }
}

﻿using System;
using log4net;
using log4net.Config;

namespace Log4NetTest
{
    class Log4NetTest
    {
        static void Main()
        {
            BasicConfigurator.Configure();

            ILog log = LogManager.GetLogger("log");

            log.Debug("Test Debug");
            log.Error("Test Error");
        }
    }
}

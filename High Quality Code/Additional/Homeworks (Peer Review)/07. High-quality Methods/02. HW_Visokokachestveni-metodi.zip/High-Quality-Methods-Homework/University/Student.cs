﻿// <copyright file="Student.cs" company="Telerik Academy">
// Copyright (c) 2013 Telerik Academy. All rights reserved.
// </copyright>

namespace University
{
    using System;

    /// <summary>
    /// Represents a student
    /// </summary>
    class Student
    {
        /// <summary>
        /// Gets ot sets first name of the student
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets last name of the student
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets ot sets date of birth of the student
        /// </summary>
        public string DateOfBirth { get; set; }

        /// <summary>
        /// Gets ot sets hometown of te student
        /// </summary>
        public string Hometown { get; set; }

        /// <summary>
        /// Checks if student is older than <paramref name="otherStudent"/>
        /// </summary>
        /// <param name="otherStudent">The second student</param>
        /// <returns>true or false</returns>
        public bool IsOlderThan(Student otherStudent)
        {
            DateTime firstDate = DateTime.Parse(this.DateOfBirth);
            DateTime secondDate = DateTime.Parse(otherStudent.DateOfBirth);

            return firstDate > secondDate;
        }
    }
}

﻿// <copyright file="UniversityTest.cs" company="Telerik Academy">
// Copyright (c) 2013 Telerik Academy. All rights reserved.
// </copyright>

namespace University
{
    using System;

    /// <summary>
    /// Tests the Student class
    /// </summary>
    public class UniversityTest
    {
        /// <summary>
        /// The entry point of the program
        /// </summary>
        public static void Main()
        {
            Student peter = new Student() { FirstName = "Peter", LastName = "Ivanov" };
            peter.Hometown = "Sofia";
            peter.DateOfBirth = "12.12.1984";

            Student stella = new Student() { FirstName = "Stella", LastName = "Markova" };
            stella.Hometown = "Vidin";
            stella.DateOfBirth = "12.03.1993";

            Console.WriteLine("{0} older than {1} -> {2}", peter.FirstName, stella.FirstName, peter.IsOlderThan(stella));
        }
    }
}

﻿// <copyright file="UtilsTest.cs" company="Telerik Academy">
// Copyright (c) 2013 Telerik Academy. All rights reserved.
// </copyright>

namespace Methods
{
    using System;
    using Utils;

    /// <summary>
    /// Used to demonstrate the use of methods from the
    /// <see cref="Utils"/> namespace.
    /// </summary>
    public class UtilsTest
    {
        /// <summary>
        /// The entry point of the program
        /// </summary>
        public static void Main()
        {
            Console.WriteLine(Calculate.TriangleArea(3, 4, 5));

            Console.WriteLine(Calculate.Distance(3, -1, 3, 2.5));
            Console.WriteLine("Horizontal? " + Calculate.IsLineHorizontal(3, -1, 3, 2.5));
            Console.WriteLine("Vertical? " + Calculate.IsLineVertical(3, -1, 3, 2.5));
            
            Console.WriteLine(Calculate.MaxValue(5, -1, 3, 2, 14, 2, 3));

            Console.WriteLine(Represent.DigitToWord(4));
            
            Console.WriteLine(Represent.AsDecimal(2, 3));
            Console.WriteLine(Represent.AsDecimalWidthAlignment(2, 5, 20));
            Console.WriteLine(Represent.AsPercent(2, 3));
        }
    }
}

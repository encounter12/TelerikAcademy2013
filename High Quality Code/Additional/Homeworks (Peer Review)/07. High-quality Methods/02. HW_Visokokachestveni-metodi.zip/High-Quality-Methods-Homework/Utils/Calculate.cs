﻿// <copyright file="Calculate.cs" company="Telerik Academy">
// Copyright (c) 2013 Telerik Academy. All rights reserved.
// </copyright>

namespace Utils
{
    using System;

    /// <summary>
    /// Contains methods that calculate mathematical problems
    /// </summary>
    public static class Calculate
    {
        /// <summary>
        /// Calculates the area of a triangle whose sides have lengths
        /// <paramref name="a"/>, <paramref name="b"/> and <paramref name="c"/>.
        /// </summary>
        /// <param name="a">The length of side a.</param>
        /// <param name="b">The length of side b.</param>
        /// <param name="c">The length of side c.</param>
        /// <returns>The area of the triangle.</returns>
        /// <exception cref="System.ArgumentException">Thrown when
        /// at least one of the arguments is less than or equal to zero
        /// or when the lengths don't satisfy the triangle inequality theorem.</exception>
        /// <remarks>The triangle area is calculated using Heron's formula.</remarks>
        /// <seealso cref="http://en.wikipedia.org/wiki/Heron%27s_formula"/>
        /// <seealso cref="http://en.wikipedia.org/wiki/Triangle_inequality_theorem"/>
        public static double TriangleArea(double a, double b, double c)
        {
            if ((a <= 0) || (b <= 0) || (c <= 0))
            {
                throw new ArgumentException("Sides should be positive.");
            }

            // calculate the semiperimeter
            double s = (a + b + c) / 2;
            double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));

            return area;
        }

        /// <summary>
        /// Calculates the distance between two points specified by their coordinates
        /// (x1, y1) and (x2, y2).
        /// </summary>
        /// <param name="x1">The x-coordinate of the first point.</param>
        /// <param name="y1">The y-coordinate of the first point.</param>
        /// <param name="x2">The x-coordinate of the second point.</param>
        /// <param name="y2">The y-coordinate of the second point.</param>
        /// <returns>The distance between the two points.</returns>
        public static double Distance(double x1, double y1, double x2, double y2)
        {
            double distance = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
            return distance;
        }

        /// <summary>
        /// Checks if the line defined by the points (x1, y1) and (x2, y2)
        /// is horizontal (parallel to the x-axis).
        /// </summary>
        /// <param name="x1">The x-coordinate of the first point.</param>
        /// <param name="y1">The y-coordinate of the first point.</param>
        /// <param name="x2">The x-coordinate of the second point.</param>
        /// <param name="y2">The y-coordinate of the second point.</param>
        /// <returns>True if the line is horizontal, otherwise - false.</returns>
        public static bool IsLineHorizontal(double x1, double y1, double x2, double y2)
        {
            if (x1 == x2 && y1 == y2)
            {
                throw new ArgumentException("The points shouldn't coincide. A single point cannot define a line.");
            }

            return y1 == y2;
        }

        /// <summary>
        /// Checks if the line defined by the points (x1, y1) and (x2, y2)
        /// is vertical (parallel to the y-axis).
        /// </summary>
        /// <param name="x1">The x-coordinate of the first point.</param>
        /// <param name="y1">The y-coordinate of the first point.</param>
        /// <param name="x2">The x-coordinate of the second point.</param>
        /// <param name="y2">The y-coordinate of the second point.</param>
        /// <returns>True if the line is vertical, otherwise - false.</returns>
        public static bool IsLineVertical(double x1, double y1, double x2, double y2)
        {
            if (x1 == x2 && y1 == y2)
            {
                throw new ArgumentException("The points shouldn't coincide. A single point cannot define a line.");
            }

            return x1 == x2;
        }

        /// <summary>
        /// Find maximal element in array
        /// </summary>
        /// <param name="args">Input array</param>
        /// <returns>Maximal value in the input array</returns>
        public static int MaxValue(params int[] args)
        {
            int maxValue = int.MinValue;

            if (args == null || args.Length < 2)
            {
                throw new ArgumentException("Input data must be array with more then one elements");
            }

            for (int i = 1; i < args.Length; i++)
            {
                if (args[i] > maxValue)
                {
                    maxValue = args[i];
                }
            }

            return maxValue;
        }
    }
}
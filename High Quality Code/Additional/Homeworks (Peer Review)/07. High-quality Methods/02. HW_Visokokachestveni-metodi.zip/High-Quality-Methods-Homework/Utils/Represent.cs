﻿// <copyright file="Represent.cs" company="Telerik Academy">
// Copyright (c) 2013 Telerik Academy. All rights reserved.
// </copyright>

namespace Utils
{
    using System;
    using System.Text;

    /// <summary>
    /// Contains methods that is useful for different representations 
    /// </summary>
    public class Represent
    {
        /// <summary>
        /// Convert digit to word
        /// </summary>
        /// <param name="digit">Digit to be converted to word representation</param>
        /// <returns>String representation of a digit</returns>
        public static string DigitToWord(int digit)
        {
            switch (digit)
            {
                case 0:
                    return "zero";
                case 1:
                    return "one";
                case 2:
                    return "two";
                case 3:
                    return "three";
                case 4:
                    return "four";
                case 5:
                    return "five";
                case 6:
                    return "six";
                case 7:
                    return "seven";
                case 8:
                    return "eight";
                case 9:
                    return "nine";
            }

            return "Invalid digit!";
        }

        /// <summary>
        /// Represent number as a decimal
        /// </summary>
        /// <param name="value">Number to be represented</param>
        /// <param name="decimalPlaces">Decimal places in the displayed value</param>
        /// <returns>String with decimal representation of a number</returns>
        public static string AsDecimal(double value, int decimalPlaces)
        {
            StringBuilder output = new StringBuilder();
            output.AppendFormat("{0:f" + decimalPlaces + "}", value);

            return output.ToString();
        }

        /// <summary>
        /// Represent number as a percent
        /// </summary>
        /// <param name="value">Number to be represented</param>
        /// <param name="decimalPlaces">Decimal places in the displayed value</param>
        /// <returns>String with percent representation of a number</returns>
        public static string AsPercent(double value, int decimalPlaces)
        {
            StringBuilder output = new StringBuilder();
            output.AppendFormat("{0:p" + decimalPlaces + "}", value);

            return output.ToString();
        }

        /// <summary>
        /// Represent <paramref name="value"/> as a decimal with alignment
        /// </summary>
        /// <param name="value">Number to be represented</param>
        /// <param name="decimalPlaces">Decimal places in the displayed value</param>
        /// <param name="totalWidth">The number of characters in the resulting string, equal to
        /// the number of original characters plus any additional padding spaces.</param>
        /// <returns>String with decimal representation of <paramref name="value"/> with alignment</returns>
        public static string AsDecimalWidthAlignment(double value, int decimalPlaces, int totalWidth)
        {
            StringBuilder output = new StringBuilder();
            output.AppendFormat("{0," + totalWidth + ":f" + decimalPlaces + "}", value);

            return output.ToString();
        }
    }
}

﻿using System;

namespace Methods
{
    class Student
    {
        // I haven't performed validation for those
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string AdditionalData { get; set; }

        public Student(string firstName, string lastName)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
        }

        public bool IsOlderThan(Student other)
        {
            string fetchedInstanceData = this.AdditionalData.Substring(this.AdditionalData.Length - 10);
            string fetchedOtherDate = other.AdditionalData.Substring(other.AdditionalData.Length - 10);

            if (fetchedInstanceData == null || fetchedOtherDate == null)
            {
                throw new ArgumentNullException("No date found in AdditionalData.");
            }

            DateTime instanceDate = DateTime.Parse(fetchedInstanceData);
            DateTime otherDate = DateTime.Parse(fetchedOtherDate);

            return (instanceDate > otherDate);
        }
    }
}

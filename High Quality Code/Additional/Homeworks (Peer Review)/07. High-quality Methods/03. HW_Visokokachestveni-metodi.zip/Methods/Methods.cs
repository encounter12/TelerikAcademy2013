﻿using System;

namespace Methods
{
    class Methods
    {
        static double CalcTriangleArea(double a, double b, double c)
        {
            if (a <= 0 || b <= 0 || c <= 0)
            {
                throw new ArgumentException("Sides should be positive.");
            }

            double s = (a + b + c) / 2;
            double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));

            return area;
        }

        static string NumberToDigit(int number)
        {
            switch (number)
            {
                case 0: return "zero";
                case 1: return "one";
                case 2: return "two";
                case 3: return "three";
                case 4: return "four";
                case 5: return "five";
                case 6: return "six";
                case 7: return "seven";
                case 8: return "eight";
                case 9: return "nine";
                default: return String.Empty;
            }
        }

        static int FindMax(params int[] elements)
        {
            if (elements == null || elements.Length == 0)
            {
                throw new ArgumentNullException("There are no given arguments.");
            }

            int max = elements[0];

            for (int i = 1; i < elements.Length; i++)
            {
                if (elements[i] > max)
                {
                    max = elements[i];
                }
            }

            return max;
        }

        static void FormatNumberAs(object number, string format)
        {
            Type[] numberTypes = { typeof(int), typeof(uint), typeof(byte), typeof(sbyte), typeof(byte), typeof(short), typeof(ushort), typeof(long), typeof(ulong), typeof(float), typeof(double), typeof(decimal) };
            bool isNumber = false;

            foreach (Type type in numberTypes)
            {
                if (number.GetType() == type)
                {
                    isNumber = true;
                }
            }

            if (!isNumber)
            {
                throw new ArgumentException("The provided argument is not a number.");
            }

            switch (format)
            {
                case "float": case "f":
                    Console.WriteLine("{0:f2}", number);
                    break;

                case "percent": case "%":
                    Console.WriteLine("{0:p0}", number);
                    break;

                case "right-aligned": case "r":
                    Console.WriteLine("{0,8}", number);
                    break;

                default:
                    Console.WriteLine(number);
                    break;
            }
        }

        static double CalcDistance(double x1, double y1, double x2, double y2)
        {
            double distance = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));

            return distance;
        }

        static bool IsVertical(double x1, double x2)
        {
            return (x1 == x2);
        }

        static bool IsHorizontal(double y1, double y2)
        {
            return (y1 == y2);
        }

        static void Main()
        {
            double triangleArea = CalcTriangleArea(3, 4, 5);
            int maxOfSequence = FindMax(5, -1, 3, 2, 14, 2, 3);
            
            Console.WriteLine(triangleArea);
            Console.WriteLine(NumberToDigit(5));
            Console.WriteLine(maxOfSequence);

            FormatNumberAs(1.3, "float");
            FormatNumberAs(0.75, "percent");
            FormatNumberAs(2.30, "right-aligned");

            bool isHorizontal = IsHorizontal(-1, 2.5);
            bool isVertical = IsVertical(3, 3);
            double distance = CalcDistance(3, -1, 3, 2.5);

            Console.WriteLine(distance);
            Console.WriteLine("Horizontal? {0}", isHorizontal);
            Console.WriteLine("Vertical? {0}", isVertical);

            Student peter = new Student("Peter", "Ivanov");
            peter.AdditionalData = "From Sofia, born at 17.03.1992";

            Student stella = new Student("Stella", "Markova");
            stella.AdditionalData = "From Vidin, gamer, high results, born at 03.11.1993";

            Console.WriteLine("{0} older than {1} -> {2}", peter.FirstName, stella.FirstName, peter.IsOlderThan(stella));
        }
    }
}

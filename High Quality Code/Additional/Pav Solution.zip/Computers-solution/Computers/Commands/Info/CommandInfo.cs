﻿namespace Computers.Commands.Info
{
    public class CommandInfo
    {
        public string CommandName { get; set; }

        public int Argument { get; set; }
    }
}

﻿namespace Computers.Manufacturers
{
    internal class Manufacturer
    {
        internal string Name { get; set; }

        internal Manufacturer(string name)
        {
            this.Name = name;
        }
    }
}

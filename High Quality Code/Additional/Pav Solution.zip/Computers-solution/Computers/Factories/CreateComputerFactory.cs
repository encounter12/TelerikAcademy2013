﻿namespace Computers.Factories
{
    using System;
    using Computers.Manufacturers;    

    internal static class CreateComputerFactory
    {
        internal static AbstractComputerFactory GetComputerFactory(Manufacturer manufacturer)
        {
            AbstractComputerFactory computerFactory;

            if (manufacturer.Name == "HP")
            {
                computerFactory = new HpFactory();
            }
            else if (manufacturer.Name == "Dell")
            {
                computerFactory = new DellFactory();
            }
            else
            {
                throw new ArgumentException("Invalid manufacturer!");
            }

            return computerFactory;
        }
    }
}

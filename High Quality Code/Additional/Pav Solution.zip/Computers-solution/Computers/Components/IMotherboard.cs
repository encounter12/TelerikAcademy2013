﻿namespace Computers.Components
{
    public interface IMotherboard
    {
    }
}

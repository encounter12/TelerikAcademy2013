﻿namespace Computers.Components
{
    internal class Motherboard
    {
        internal Motherboard()
        {

        }
    }
}
﻿namespace Computers.Components
{
    internal class Ram
    {
        private int value;

        internal int Amount { get; private set; }

        internal Ram(int amount)
        {
            this.Amount = amount;
        }  

        public void SaveValue(int newValue)
        {
            this.value = newValue;
        }

        public int LoadValue()
        {
            return this.value;
        }
    }
}
﻿namespace ComputersNamespace.UI.Console
{
    using System;

    public class CommandParser
    {
        public CommandInfo Parse(string command)
        {
            string[] commandParameters = command.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (commandParameters.Length != 2)
            {
                {
                    throw new ArgumentException("Invalid command!");
                }
            }

            string commandName = commandParameters[0];
            int commandData = int.Parse(commandParameters[1]);

            var commandInfo = new CommandInfo
            {
                CommandName = commandName,
                CommandData = commandData
            };

            return commandInfo;
        }
    }
}

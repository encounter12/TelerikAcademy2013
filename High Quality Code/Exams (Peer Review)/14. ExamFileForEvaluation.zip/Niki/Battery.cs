﻿namespace BatteryNamespace
{
    public class Battery
    {
        private const int InitialPercentage = 50,
            MinPercentage = 0,
            MaxPercentage = 100;

        public Battery()
        {
            this.Percentage = InitialPercentage;
        }

        public int Percentage { get; set; }

        public void Charge(int power)
        {
            this.Percentage += power;
            if (this.Percentage > 100)
            {
                this.Percentage = MaxPercentage;
            }

            if (this.Percentage < 0)
            {
                this.Percentage = MinPercentage;
            }
        }      
    }
}

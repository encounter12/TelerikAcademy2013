﻿namespace ComputersNamespace.UI.Console
{
    public enum ComputerType
    {
        PC, LAPTOP, SERVER,
    }
}

﻿namespace ComputersNamespace.UI.Console
{
    using System.Collections.Generic;
    using BatteryNamespace;
    using CpuNamespace;
    using HardDrivesNamespace;
    using RAMMemoryNamespace;

    public class Computer
    {
        public readonly Battery Battery;

        public Computer(ComputerType type, Cpu cpu, RAMMemory ram, IEnumerable<HardDrive> hardDrives, VideoCard videoCard, Battery battery)
        {
            this.Cpu = cpu;
            this.Ram = ram;
            this.HardDrives = hardDrives;
            VideoCard = videoCard;
            if (type != ComputerType.LAPTOP && type != ComputerType.PC)
            {
                VideoCard.IsMonochrome = true;
            }

            this.Battery = battery;
        }

        public IEnumerable<HardDrive> HardDrives { get; set; }

        public Cpu Cpu { get; set; }

        public RAMMemory Ram { get; set; }

        public VideoCard VideoCard { get; set; }

        public void ChargeBattery(int percentage)
        {
            this.Battery.Charge(percentage);
            VideoCard.Draw(string.Format("Battery status: {0}", this.Battery.Percentage));
        }

        public void Play(int guessNumber)
        {
            Cpu.GenerateRandomNumber(1, 10);
            var number = this.Ram.LoadValue();
            if (number != guessNumber)
            {
                VideoCard.Draw(string.Format("You didn't guess the number {0}.", number));
            }
            else
            {
                VideoCard.Draw("You win!");
            }
        }

        public void Process(int data)
        {
            this.Ram.SaveValue(data);
            this.Cpu.SquareNumber();
        }
    }
}

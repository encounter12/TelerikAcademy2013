﻿namespace RAMMemoryNamespace
{
   public class RAMMemory
    {
        private int value;

        public RAMMemory(int amount)
        {
            this.Amount = amount;
        }

        public int Amount { get; set; }

        public void SaveValue(int newValue)
        {
            this.value = newValue;
        }

        public int LoadValue()
        {
            return this.value;
        }
    }
}
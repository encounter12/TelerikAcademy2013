﻿namespace ComputersNamespace.UI.Console
{
    /// <summary>
    /// Contains methods that can load values from the RAM,
    /// save values to the RAM and 
    /// draw on the video card
    /// </summary>
    public interface IMotherboard
    {
        /// <summary>
        /// Loads an integer number that is stored in the RAM
        /// </summary>
        /// <returns>The integer that is stored in the RAM</returns>
        int LoadRamValue();

        /// <summary>
        /// Saves the value of the parameter in the RAM
        /// </summary>
        /// <param name="value">An integer number</param>
        void SaveRamValue(int value);

        /// <summary>
        /// Draws the data on the video card
        /// </summary>
        /// <param name="data">String variable</param>
        void DrawOnVideoCard(string data);
    }
}

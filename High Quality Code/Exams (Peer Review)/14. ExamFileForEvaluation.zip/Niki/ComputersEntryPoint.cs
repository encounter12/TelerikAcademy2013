﻿namespace ComputersNamespace
{
    using System;
    using System.Collections.Generic;
    using BatteryNamespace;
    using ComputersNamespace.UI.Console;
    using CpuNamespace;
    using HardDrivesNamespace;
    using RAMMemoryNamespace;

    public class Computers
    {
        public static void Main()
        {
            string manufacturer = Console.ReadLine();
            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.ManufactureComputers(manufacturer);

            while (true)
            {
                string command = Console.ReadLine();
                if (command.StartsWith("Exit") || command == null)
                {
                   break;
                }

                var commandParser = new CommandParser();
                var commandInfo = commandParser.Parse(command);

                if (commandInfo.CommandName == "Charge")
                {
                    computerFactory.Laptop.ChargeBattery(commandInfo.CommandData);
                }
                else if (commandInfo.CommandName == "Process")
                {
                    computerFactory.Server.Process(commandInfo.CommandData);
                }
                else if (commandInfo.CommandName == "Play")
                {
                    computerFactory.PC.Play(commandInfo.CommandData);
                }  
            }
        }
    }
}

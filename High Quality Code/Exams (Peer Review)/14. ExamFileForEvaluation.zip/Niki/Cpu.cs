﻿namespace CpuNamespace
{
    using System;
    using ComputersNamespace.UI.Console;
    using RAMMemoryNamespace;

    public class Cpu
    {
        private static readonly Random Random = new Random();

        private readonly byte numberOfBits;

        private readonly RAMMemory ram;

        private readonly VideoCard videoCard;

        public Cpu(byte numberOfCores, byte numberOfBits, RAMMemory ram, VideoCard videoCard)
        {
            this.numberOfBits = numberOfBits;
            this.ram = ram;
            this.NumberOfCores = numberOfCores;
            this.videoCard = videoCard;
        }

        public byte NumberOfCores { get; set; }

        public void SquareNumber()
        {
            const double HighestPossibleNumberScalingFactor = 15.625;
            double highestPossibleCpuNumber = this.numberOfBits * HighestPossibleNumberScalingFactor;

            var data = this.ram.LoadValue();
            if (data < 0)
            {
                this.videoCard.Draw("Number too low.");
            }
            else if (data > highestPossibleCpuNumber)
            {
                this.videoCard.Draw("Number too high.");
            }
            else
            {
                int result = data * data;
                this.videoCard.Draw(string.Format("Square of {0} is {1}.", data, result));
            }
        }

        public void GenerateRandomNumber(int a, int b)
        {
            int randomNumber = Random.Next(a, b);
            this.ram.SaveValue(randomNumber);
        }
    }
}

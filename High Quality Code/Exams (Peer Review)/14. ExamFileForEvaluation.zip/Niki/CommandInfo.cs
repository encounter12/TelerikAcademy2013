﻿namespace ComputersNamespace.UI.Console
{
    public class CommandInfo
    {
        public string CommandName { get; set; }

        public int CommandData { get; set; }
    }
}

﻿namespace ComputersNamespace.UI.Console
{
    using System;
    using System.Collections.Generic;
    using BatteryNamespace;
    using CpuNamespace;
    using HardDrivesNamespace;
    using RAMMemoryNamespace;

    public class ComputerFactory
    {
        private Computer pc, server, laptop;

        public Computer PC
        {
            get { return this.pc; }
        }

        public Computer Server
        {
            get { return this.server; }
        }

        public Computer Laptop
        {
            get { return this.laptop; }
        }

        public void ManufactureComputers(string manufacturer)
        {
            if (manufacturer == "HP")
            {
                var pcRam = new RAMMemory(2);
                var pcVideoCard = new VideoCard();
                pcVideoCard.IsMonochrome = false;
                var pcCpu = new Cpu(2, 32, pcRam, pcVideoCard);
                var pcHardDrives = new[] { new HardDrive(500, false, 0) };

                this.pc = new Computer(ComputerType.PC, pcCpu, pcRam, pcHardDrives, pcVideoCard, null);

                var serverRam = new RAMMemory(32);
                var serverVideoCard = new VideoCard();
                var serverCpu = new Cpu(4, 32, serverRam, serverVideoCard);
                var serverHardDrives = new List<HardDrive>
                        {
                            new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(1000, false, 0), new HardDrive(1000, false, 0) })
                        };

                this.server = new Computer(ComputerType.SERVER, serverCpu, serverRam, serverHardDrives, serverVideoCard, null);

                var laptopRam = new RAMMemory(4);
                var laptopVideoCard = new VideoCard();
                laptopVideoCard.IsMonochrome = false;
                var laptopCpu = new Cpu(2, 64, laptopRam, laptopVideoCard);
                var laptopHardDrives = new[]
                            {
                                new HardDrive(500, false, 0)
                            };

                this.laptop = new Computer(ComputerType.LAPTOP, laptopCpu, laptopRam, laptopHardDrives, laptopVideoCard, new Battery());
            }
            else if (manufacturer == "Dell")
            {
                var pcRam = new RAMMemory(8);
                var pcVideoCard = new VideoCard();
                pcVideoCard.IsMonochrome = false;

                var pcCpu = new Cpu(4, 64, pcRam, pcVideoCard);
                var pcHardDrives = new[] { new HardDrive(1000, false, 0) };
                this.pc = new Computer(ComputerType.PC, pcCpu, pcRam, pcHardDrives, pcVideoCard, null);

                var serverRam = new RAMMemory(64);
                var serverVideoCard = new VideoCard();
                var serverCpu = new Cpu(8, 64, serverRam, serverVideoCard);
                var serverHardDrives = new List<HardDrive>
                        {
                            new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(2000, false, 0), new HardDrive(2000, false, 0) })
                        };

                this.server = new Computer(ComputerType.SERVER, serverCpu, serverRam, serverHardDrives, serverVideoCard, null);

                var laptopRam = new RAMMemory(8);
                var laptopVideoCard = new VideoCard();
                laptopVideoCard.IsMonochrome = false;
                var laptopCpu = new Cpu(4, 32, laptopRam, laptopVideoCard);
                var laptopHardDrives = new[] { new HardDrive(1000, false, 0) };

                this.laptop = new Computer(ComputerType.LAPTOP, laptopCpu, laptopRam, laptopHardDrives, laptopVideoCard, new Battery());
            }
            else if (manufacturer == "Lenovo")
            {
                var pcRam = new RAMMemory(4);
                var pcVideoCard = new VideoCard();
                pcVideoCard.IsMonochrome = true;
                var pcCpu = new Cpu(2, 64, pcRam, pcVideoCard);
                var pcHardDrives = new[] { new HardDrive(2000, false, 0) };

                this.pc = new Computer(ComputerType.PC, pcCpu, pcRam, pcHardDrives, pcVideoCard, null);

                var serverRam = new RAMMemory(8);
                var serverVideoCard = new VideoCard();
                var serverCpu = new Cpu(2, 128, serverRam, serverVideoCard);
                var serverHardDrives = new List<HardDrive>
                        {
                            new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(500, false, 0), new HardDrive(500, false, 0) })
                        };

                this.server = new Computer(ComputerType.SERVER, serverCpu, serverRam, serverHardDrives, serverVideoCard, null);

                var laptopRam = new RAMMemory(16);
                var laptopVideoCard = new VideoCard();
                laptopVideoCard.IsMonochrome = false;
                var laptopCpu = new Cpu(4, 64, laptopRam, laptopVideoCard);
                var laptopHardDrives = new[] { new HardDrive(1000, false, 0) };

                this.laptop = new Computer(ComputerType.LAPTOP, laptopCpu, laptopRam, laptopHardDrives, laptopVideoCard, new Battery());
            }
            else
            {
                throw new ArgumentException("Invalid manufacturer!");
            }
        }
    }
}

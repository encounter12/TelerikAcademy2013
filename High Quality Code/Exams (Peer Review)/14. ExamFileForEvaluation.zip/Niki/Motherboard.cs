﻿namespace ComputersNamespace.UI.Console
{
    using RAMMemoryNamespace;

    public class Motherboard : IMotherboard
    {
        private RAMMemory ram;
        private VideoCard videoCard;

        public Motherboard(RAMMemory ram, VideoCard videoCard)
        {
            this.ram = ram;
            this.videoCard = videoCard;
        }

        public int LoadRamValue()
        {
            return this.ram.LoadValue();
        }

        public void SaveRamValue(int value)
        {
            this.ram.SaveValue(value);
        }

        public void DrawOnVideoCard(string data)
        {
            this.videoCard.Draw(data);
        }
    }
}

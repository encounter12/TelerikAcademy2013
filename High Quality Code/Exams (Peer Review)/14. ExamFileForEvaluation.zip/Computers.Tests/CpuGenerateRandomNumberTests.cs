﻿namespace Computers.Tests
{
    using ComputersNamespace.UI.Console;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    
    [TestClass]
    public class CpuGenerateRandomNumberTests
    {
        [TestMethod]
        public void GenerateRandomNumberBetweenOneAndTen()
        {
            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.ManufactureComputers("HP");
            computerFactory.PC.Cpu.GenerateRandomNumber(1, 10);
            var result = computerFactory.PC.Ram.LoadValue();

            Assert.IsTrue(result >= 1 && result <= 10);
        }

        [TestMethod]
        public void GenerateNegativeRandomNumber()
        {
            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.ManufactureComputers("HP");
            computerFactory.PC.Cpu.GenerateRandomNumber(-10, -5);
            var result = computerFactory.PC.Ram.LoadValue();

            Assert.IsTrue(result < 0);
        }

        [TestMethod]
        [ExpectedException(typeof(System.ArgumentOutOfRangeException))]
        public void GenerateRandomNumberWithFirstArgumentOfFunctionGreaterThanSecond()
        {
            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.ManufactureComputers("HP");
            computerFactory.PC.Cpu.GenerateRandomNumber(10, 1);
            var result = computerFactory.PC.Ram.LoadValue();

            Assert.IsTrue(result >= 1 && result <= 10);
        }
    }
}
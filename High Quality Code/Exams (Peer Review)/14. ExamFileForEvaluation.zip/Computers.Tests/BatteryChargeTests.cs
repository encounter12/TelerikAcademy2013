﻿namespace Computers.Tests
{
    using System;
    using ComputersNamespace.UI.Console;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
   
    [TestClass]
    public class BatteryChargeTests
    {
        [TestMethod]
        public void ChargeWithPercentageThatKeepsTheFinalPercentageBetweenTheMinAndMax()
        {
            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.ManufactureComputers("HP");
            computerFactory.Laptop.ChargeBattery(13);
            var result = computerFactory.Laptop.Battery.Percentage;

            Assert.AreEqual(63, result);
        }

        [TestMethod]
        public void ChargeWithPercentageThatMakesTheFinalPercentageBelowTheMinimum()
        {
            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.ManufactureComputers("HP");
            computerFactory.Laptop.ChargeBattery(-73);
            var result = computerFactory.Laptop.Battery.Percentage;

            Assert.AreEqual(0, result);
        }

        [TestMethod]
        public void ChargeWithPercentageThatMakesTheFinalPercentageOverTheMaximum()
        {
            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.ManufactureComputers("HP");
            computerFactory.Laptop.ChargeBattery(300);
            var result = computerFactory.Laptop.Battery.Percentage;

            Assert.AreEqual(100, result);
        }
    }
}

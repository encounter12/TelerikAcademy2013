﻿namespace Computers.Tests
{
    using ComputersNamespace.UI.Console;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CpuSquareNumberTests
    {
        [TestMethod]
        public void GenerateSquareNumberOn32BitCpu()
        {
            ComputerFactory computerFactory = new ComputerFactory();
            computerFactory.ManufactureComputers("HP");
            computerFactory.Server.Cpu.SquareNumber();
            
        }
    }
}
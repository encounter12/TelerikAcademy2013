﻿namespace Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Computers.UI.Console.Components;

    [TestClass]
    public class BatteryTests
    {
        [TestMethod]
        public void NewBateryShouldHasFiftyPercentPower()
        {
            var battery = new Battery();
            var power = battery.Percentage;

            Assert.AreEqual(50, power);
        }

        [TestMethod]
        public void ChargeBateryWith10PercentShouldResultInSixtyPercentPower()
        {
            var battery = new Battery();
            battery.Charge(10);
            var power = battery.Percentage;

            Assert.AreEqual(60, power);
        }

        [TestMethod]
        public void ChargeBateryWith60PercentShouldResultInHundredPercentPower()
        {
            var battery = new Battery();
            battery.Charge(60);
            var power = battery.Percentage;

            Assert.AreEqual(100, power);
        }

        [TestMethod]
        public void ChargeBateryWithMinusSixtyPercentShouldResultInZeroPercentPower()
        {
            var battery = new Battery();
            battery.Charge(-60);
            var power = battery.Percentage;

            Assert.AreEqual(0, power);
        }
    }
}

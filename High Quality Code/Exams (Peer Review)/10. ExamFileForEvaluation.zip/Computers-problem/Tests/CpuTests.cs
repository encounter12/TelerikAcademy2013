﻿namespace Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Computers.UI.Console.Components;

    [TestClass]
    public class CpuTests
    {
        [TestMethod]
        public void CheckRandomValueeBetween1And100()
        {
            Ram ram = new Ram(8);
            VideoCard videoCard = new VideoCard();
            var cpu = new Cpu(2, 32, ram, videoCard);

            // cpu sets the random generated value the its RAM
            cpu.RandomNumberInRange(1, 100);
            var number = ram.LoadValue();


            Assert.IsTrue(number >= 1);
            Assert.IsTrue(number <= 100);
        }

        [TestMethod]
        public void TestSquarNumberFor32Bits()
        {
            Ram ram = new Ram(8);
            VideoCard videoCard = new VideoCard();
            var cpu = new Cpu(2, 32, ram, videoCard);

            //the output should be 64
            cpu.SquareNumber();
        }

        // TODO: test	Cpu.SquareNumber() with JustMock
    }
}

﻿namespace Computers.UI.Console.Interfaces
{
    using System;
    using System.Linq;

    /// <summary>
    /// Interface presenting a computer's motherboard
    /// </summary>
    internal interface IMotherboard
    {
        /// <summary>
        /// Load value from the computer's RAM
        /// </summary>
        /// <returns>integer value loaded from the RAM</returns>
        int LoadRamValue();

        /// <summary>
        /// Save integer value to the computer's RAM
        /// </summary>
        /// <param name="value"></param>
        void SaveRamValue(int value);

        /// <summary>
        /// Draw string data on the video card
        /// </summary>
        /// <param name="data">string value to be drawn</param>
        void DrawOnVideoCard(string data);
    }
}
﻿namespace Computers.UI.Console.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Components;
    using Computers;

    public interface IFactory
    {
        Pc MakePc(int ram, bool isMonochrome, int hddCapacity, byte numberOfCores, byte numberOfBits);

        Server MakeServer(int ram, byte numberOfCores, byte numberOfBits, List<HardDrive> hardDrives);

        Laptop MakeLaptop(int ram, bool isMonochrome, int hddCapacity, byte numberOfCores, byte numberOfBits);
    }
}
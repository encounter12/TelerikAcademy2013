﻿namespace Computers.UI.Console
{
    using System;
    using System.Collections.Generic;
    using Components;
    using Computers;
    using Exeptions;

    internal class MainEntry
    {
        private static Pc pc;
        private static Laptop laptop;
        private static Server server;

        public static void Main()
        {
            while (true)
            {
                string inputLine = Console.ReadLine();
                if (inputLine == null)
                {
                    Console.WriteLine("Invalid command!");
                }

                var splitedInput = inputLine.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                if (splitedInput[0] == "Exit")
                {
                    Environment.Exit(0);
                }
                else if (splitedInput.Length == 1)
                {
                    CreateCoputersByManufactorer(splitedInput[0]);
                }
                else
                {
                    var commandName = splitedInput[0];
                    var commandValue = int.Parse(splitedInput[1]);

                    if (commandName == "Charge")
                    {
                        laptop.ChargeBattery(commandValue);
                    }
                    else if (commandName == "Process")
                    {
                        server.Process(commandValue);
                    }
                    else if (commandName == "Play")
                    {
                        pc.Play(commandValue);
                    }
                    else
                    {
                        Console.WriteLine("Invalid command!");
                    }
                }
            }
        }

        private static void CreateCoputersByManufactorer(string manufacturer)
        {
            SimpleFactory factory = new SimpleFactory();

            if (manufacturer == "HP")
            {
                pc = factory.MakePc(2, false, 500, 2, 32);

                List<HardDrive> hardDrives = new List<HardDrive>
                {
                    new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(1000, false, 0), new HardDrive(1000, false, 0) })
                };

                server = factory.MakeServer(32, 4, 32, hardDrives);
                laptop = factory.MakeLaptop(4, false, 500, 2, 64);
            }
            else if (manufacturer == "Dell")
            {
                pc = factory.MakePc(8, false, 1000, 4, 64);

                List<HardDrive> hardDrives = new List<HardDrive>
                {
                    new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(2000, false, 0), new HardDrive(2000, false, 0) })
                };

                server = factory.MakeServer(64, 8, 64, hardDrives);
                laptop = factory.MakeLaptop(8, false, 1000, 4, 32);
            }
            else if (manufacturer == "Lenovo")
            {
                pc = factory.MakePc(4, true, 2000, 2, 64);

                List<HardDrive> hardDrives = new List<HardDrive> 
                {
                    new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(500, false, 0), new HardDrive(500, false, 0) })
                };

                server = factory.MakeServer(8, 2, 128, hardDrives);
                laptop = factory.MakeLaptop(16, false, 1000, 2, 64);
            }
            else
            {
                throw new InvalidArgumentException("Invalid manufacturer!");
            }
        }
    }
}
﻿namespace Computers.UI.Console.Components
{
    using System;

    public class Cpu
    {
        private static readonly Random Random = new Random();

        private readonly byte numberOfBits;

        private readonly Ram ram;

        private readonly VideoCard videoCard;

        public Cpu(byte numberOfCores, byte numberOfBits, Ram ram, VideoCard videoCard)
        {
            this.numberOfBits = numberOfBits;
            this.ram = ram;
            this.NumberOfCores = numberOfCores;
            this.videoCard = videoCard;
        }

        private byte NumberOfCores { get; set; }

        public void SquareNumber()
        {
            var data = this.ram.LoadValue();

            if (this.numberOfBits == 32)
            {
                this.SquareNumber32(data);
            }

            if (this.numberOfBits == 64)
            {
                this.SquareNumber64(data);
            }

            if (this.numberOfBits == 128)
            {
                this.SquareNumber128(data);
            }
        }

        public void RandomNumberInRange(int a, int b)
        {
            int randomNumber;
            do
            {
                randomNumber = Random.Next(0, 1000);
            }
            while (!(randomNumber >= a && randomNumber <= b));

            this.ram.SaveValue(randomNumber);
        }

        private void SquareNumber32(int data)
        {
            if (this.ValidateDate(data, 0, 500))
            {
                this.CalcValue(data);
            }
        }

        private void SquareNumber64(int data)
        {
            if (this.ValidateDate(data, 0, 1000))
            {
                this.CalcValue(data);
            }
        }

        private void SquareNumber128(int data)
        {
            if (this.ValidateDate(data, 0, 2000))
            {
                this.CalcValue(data);
            }
        }

        private void CalcValue(int data)
        {
            int value = 0;
            for (int i = 0; i < data; i++)
            {
                value += data;
            }

            this.videoCard.Draw(string.Format("Square of {0} is {1}.", data, value));
        }

        private bool ValidateDate(int data, int min, int max)
        {
            if (data < min)
            {
                this.videoCard.Draw("Number too low.");
                return false;
            }
            else if (data > max)
            {
                this.videoCard.Draw("Number too high.");
                return false;
            }

            return true;
        }
    }
}
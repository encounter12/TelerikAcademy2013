﻿namespace Computers.UI.Console.Components
{
    using System;
    using System.Linq;
    using Interfaces;

    public class Motherboard : IMotherboard
    {
        public int LoadRamValue()
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        public void SaveRamValue(int value)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        public void DrawOnVideoCard(string data)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }
    }
}
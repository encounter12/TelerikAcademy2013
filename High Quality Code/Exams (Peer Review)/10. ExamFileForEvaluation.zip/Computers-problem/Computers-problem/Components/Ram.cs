﻿namespace Computers.UI.Console.Components
{
    public class Ram
    {
        private int value;

        public Ram(int value)
        {
            this.value = value;
        }

        public void SaveValue(int newValue)
        {
            this.value = newValue;
        }

        public int LoadValue()
        {
            return this.value;
        }
    }
}
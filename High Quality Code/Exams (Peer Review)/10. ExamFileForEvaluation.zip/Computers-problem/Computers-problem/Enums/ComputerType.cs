﻿namespace Computers.UI.Console.Enums
{
    public enum ComputerType
    {
        PC,
        Laptop,
        Server,
    }
}
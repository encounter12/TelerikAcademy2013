﻿namespace Computers.UI.Console.Computers
{
    using System;
    using System.Collections.Generic;
    using Components;

    public class Pc : Computer
    {
        public Pc(Cpu cpu, Ram ram, IList<HardDrive> hardDrives, VideoCard videoCard)
        {
            this.Cpu = cpu;
            this.Ram = ram;
            this.HardDrives = hardDrives;
            this.VideoCard = videoCard;
        }
    }
}
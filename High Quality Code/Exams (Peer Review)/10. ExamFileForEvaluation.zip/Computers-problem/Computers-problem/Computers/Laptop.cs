namespace Computers.UI.Console.Computers
{
    using System.Collections.Generic;
    using Components;

    public class Laptop : Computer
    {
        private Battery battery;

        public Laptop(Cpu cpu, Ram ram, IList<HardDrive> hardDrives, VideoCard videoCard, Battery battery)
        {
            this.Cpu = cpu;
            this.Ram = ram;
            this.HardDrives = hardDrives;
            this.VideoCard = videoCard;
            this.battery = battery;
        }

        public void ChargeBattery(int percentage)
        {
            this.battery.Charge(percentage);

            this.VideoCard.Draw(string.Format("Battery status: {0}%", this.battery.Percentage));
        }
    }
}
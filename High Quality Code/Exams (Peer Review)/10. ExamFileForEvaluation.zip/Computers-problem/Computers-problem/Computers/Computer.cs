﻿namespace Computers.UI.Console.Computers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Components;

    public abstract class Computer
    {
        public IEnumerable<HardDrive> HardDrives { get; set; }

        public VideoCard VideoCard { get; set; }

        public Cpu Cpu { get; set; }

        public Ram Ram { get; set; }

        public void Play(int guessNumber)
        {
            this.Cpu.RandomNumberInRange(1, 10);
            var number = this.Ram.LoadValue();
            if (number + 1 != guessNumber + 1)
            {
                this.VideoCard.Draw(string.Format("You didn't guess the number {0}.", number));
            }
            else
            {
                this.VideoCard.Draw("You win!");
            }
        }
    }
}
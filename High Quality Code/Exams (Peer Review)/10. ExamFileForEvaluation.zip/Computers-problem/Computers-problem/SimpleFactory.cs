﻿namespace Computers.UI.Console
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Components;
    using Computers;
    using Interfaces;

    public class SimpleFactory : IFactory
    {
        public Pc MakePc(int ram, bool isMonochrome, int hddCapacity, byte numberOfCores, byte numberOfBits)
        {
            var pcRam = new Ram(ram);
            var videoCard = new VideoCard()
            {
                IsMonochrome = isMonochrome
            };
            Pc pc = new Pc(
                new Cpu(numberOfCores, numberOfBits, pcRam, videoCard),
                pcRam,
                new[] { new HardDrive(hddCapacity, false, 0) },
                videoCard);

            return pc;
        }

        public Server MakeServer(int ram, byte numberOfCores, byte numberOfBits, List<HardDrive> hardDrives)
        {
            var serverRam = new Ram(ram);
            var serverVideoCard = new VideoCard();
            Server server = new Server(
                new Cpu(numberOfCores, numberOfBits, serverRam, serverVideoCard),
                serverRam,
                hardDrives,
                serverVideoCard);

            return server;
        }

        public Laptop MakeLaptop(int ram, bool isMonochrome, int hddCapacity, byte numberOfCores, byte numberOfBits)
        {
            var laptopRam = new Ram(ram);
            var laptopVideoCard = new VideoCard() { IsMonochrome = isMonochrome };
            Laptop laptop = new Laptop(
                new Cpu(numberOfCores, numberOfBits, laptopRam, laptopVideoCard),
                laptopRam,
                new[] { new HardDrive(hddCapacity, false, 0) },
                laptopVideoCard,
                new Battery());

            return laptop;
        }
    }
}
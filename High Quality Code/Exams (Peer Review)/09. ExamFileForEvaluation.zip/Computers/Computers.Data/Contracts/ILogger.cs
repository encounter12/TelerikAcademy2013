namespace Computers.Data.Contracts
{
    public interface ILogger
    {
        void Print(string message);
    }
}
﻿namespace ComputersConsoleApp
{
    using System;
    using System.Collections.Generic;

    using ComputerComponents;

    public class ComputersConsoleApp
    {
        private const int Eight = 8;

        public static void Main()
        {
            Computer pc;
            Computer laptop;
            Computer server;

            var manufacturer = Console.ReadLine();
            if (manufacturer == "HP")
            {
                var personalComputerRam = new Ram(Eight / 4);
                var personalComputerVideoCard = new VideoCard(false);
                var personalComputerCpu = new Cpu(Eight / 4, 32, personalComputerRam, personalComputerVideoCard);
                var personalComputerHardDrive = new HardDrive(500, false, 0);
                pc = new Computer(ComputerType.PC, personalComputerCpu, personalComputerRam, new[] { personalComputerHardDrive }, personalComputerVideoCard, null);

                var serverRam = new Ram(Eight * 4);
                var serverVideo = new VideoCard();
                var serverCpu = new Cpu(Eight / 2, 32, serverRam, serverVideo);
                var serverHardDrive = new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(1000, false, 0), new HardDrive(1000, false, 0) });
                server = new Computer(ComputerType.Server, serverCpu, serverRam, new[] { serverHardDrive }, serverVideo, null);

                var laptopRam = new Ram(Eight / 2);
                var laptopVideoCard = new VideoCard(false);
                var laptopCpu = new Cpu(Eight / 4, 64, laptopRam, laptopVideoCard);
                var laptopHardDrive = new HardDrive(500, false, 0);
                laptop = new Computer(ComputerType.Laptop, laptopCpu, laptopRam, new[] { laptopHardDrive }, laptopVideoCard, new ComputerComponents.LaptopBattery());
            }
            else if (manufacturer == "Dell")
            {
                var personalComputerRam = new Ram(Eight);
                var personalComputerVideoCard = new VideoCard(false);
                var personalComputerCpu = new Cpu(Eight / 2, 64, personalComputerRam, personalComputerVideoCard);
                var personalComputerHardDrive = new HardDrive(1000, false, 0);
                pc = new Computer(ComputerType.PC, personalComputerCpu, personalComputerRam, new[] { personalComputerHardDrive }, personalComputerVideoCard, null);

                var serverRam = new Ram(Eight * Eight);
                var serverVideoCard = new VideoCard();
                var serverCpu = new Cpu(Eight, 64, serverRam, serverVideoCard);
                var serverHardDrive = new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(2000, false, 0), new HardDrive(2000, false, 0) });
                server = new Computer(ComputerType.Server, serverCpu, serverRam, new[] { serverHardDrive }, serverVideoCard, null);

                var laptopRam = new Ram(Eight);
                var laptopVideoCard = new VideoCard(false);
                var laptopCpu = new Cpu(Eight / 2, 32, laptopRam, laptopVideoCard);
                var laptopHardDrive = new HardDrive(1000, false, 0);
                laptop = new Computer(ComputerType.Laptop, laptopCpu, laptopRam, new[] { laptopHardDrive }, laptopVideoCard, new ComputerComponents.LaptopBattery());
            }
            else if (manufacturer == "Lenovo")
            {
                var personalComputerRam = new Ram(Eight / 2);
                var personalComputerVideoCard = new VideoCard(true);
                var personalComputerCpu = new Cpu(2, 64, personalComputerRam, personalComputerVideoCard);
                var personalComputerHardDrive = new HardDrive(2000, false, 0);
                pc = new Computer(ComputerType.PC, personalComputerCpu, personalComputerRam, new[] { personalComputerHardDrive }, personalComputerVideoCard, null);

                var serverRam = new Ram(Eight);
                var serverVideoCard = new VideoCard();
                var serverCpu = new Cpu(2, 128, serverRam, serverVideoCard);
                var serverHardDrive = new HardDrive(0, true, 2, new List<HardDrive> { new HardDrive(500, false, 0), new HardDrive(500, false, 0) });
                server = new Computer(ComputerType.Server, serverCpu, serverRam, new[] { serverHardDrive }, serverVideoCard, null);

                var laptopRam = new Ram(Eight * 2);
                var laptopVideoCard = new VideoCard(false);
                var laptopCpu = new Cpu(2, 64, laptopRam, laptopVideoCard);
                HardDrive laptopHardDrive = new HardDrive(1000, false, 0);
                laptop = new Computer(ComputerType.Laptop, laptopCpu, laptopRam, new[] { laptopHardDrive }, laptopVideoCard, new ComputerComponents.LaptopBattery());
            }
            else
            {
                throw new InvalidArgumentException("Invalid manufacturer!");
            }

            // TODO: To extract main functionalities of classes as Interfaces
            while (true)
            {
                var commandLine = Console.ReadLine();
                if (commandLine == null)
                {
                    break;
                }

                if (commandLine.StartsWith("Exit"))
                {
                    break;
                }

                var arguments = commandLine.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (arguments.Length != 2)
                {
                    {
                        throw new ArgumentException("Invalid command!");
                    }
                }

                string commandName = arguments[0];
                int commandArgument = int.Parse(arguments[1]);

                // string printResult = CommandFactory.GetCommand(commandName as CommandType, commandArgument, new Computer[] { laptop, pc, server });
                // Console.WriteLine(printResult);
                if (commandName == "Charge")
                {
                    laptop.ChargeBattery(commandArgument);
                }
                else if (commandName == "Process")
                {
                    server.Process(commandArgument);
                }
                else if (commandName == "Play")
                {
                    pc.Play(commandArgument);
                }
                else
                {
                    Console.WriteLine("Invalid command!");
                }
            }
        }

        public class InvalidArgumentException : ArgumentException
        {
            public InvalidArgumentException(string message)
                : base(message)
            {
            }
        }
    }
}

﻿////namespace ComputersConsoleApp
////{
////    using System;
////    using Commands;
////using ComputerComponents;

////    public static class CommandFactory
////    {
////        public static string GetCommand(CommandType commandType, int argument, Computer[] computers)
////        {
////            Command command;
////            Computer computer;
////            string result = string.Empty;

////            switch (commandType)
////            {
////                case CommandType.Charge:
////                    computer = computers[0];
////                    command = new Command(computer, argument);
////                    result = computer.ChargeBattery(command.Argument);
////                    break;
////                case CommandType.Process:
////                    computer = computers[1];
////                    command = new Command(computer, argument);
////                    result = computer.Process(command.Argument);
////                    break;
////                case CommandType.Play:
////                    computer = computers[2];
////                    command = new Command(computer, argument);
////                    result = computer.Play(command.Argument);
////                    break;
////                default:
////                    Console.WriteLine("Invalid command!");
////                    break;
////            }

////            return result;
////        }
////    }
////}

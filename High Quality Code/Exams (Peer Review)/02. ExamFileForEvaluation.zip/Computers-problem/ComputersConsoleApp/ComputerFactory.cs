﻿namespace ComputersConsoleApp
{
    using ComputerComponents;

    public abstract class ComputerFactory
    {
        public abstract Computer ReleaseReadyComputer();

        protected abstract ComputerType SetComputerType();
        
        protected abstract ICpu SetComputerCpu();
        
        protected abstract IRam SetComputerRam();
        
        protected abstract IHardDrive SetComputerHardDrive();
        
        protected abstract IGraphicsRenderer SetComputerGraphicalRenderer();
        
        protected abstract IBattery SetComputerBattery();
    }
}

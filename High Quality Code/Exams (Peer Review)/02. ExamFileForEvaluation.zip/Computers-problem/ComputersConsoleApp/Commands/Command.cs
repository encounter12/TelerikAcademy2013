﻿namespace ComputersConsoleApp.Commands
{
    using ComputerComponents;

    public class Command
    {
        public Command(Computer computer, int argument)
        {
            this.Computer = computer;
            this.Argument = argument;
        }

        public Computer Computer { get; set; }

        public int Argument { get; set; }
    }
}

﻿namespace ComputersConsoleApp.Commands
{
    public enum CommandType
    {
        Charge,
        Process,
        Play
    }
}

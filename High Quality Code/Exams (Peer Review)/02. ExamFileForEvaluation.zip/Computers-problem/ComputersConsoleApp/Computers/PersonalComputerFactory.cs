﻿//namespace ComputersConsoleApp.Computers
//{
//    using System;

//    public class PersonalComputerFactory : ComputerFactory
//    {
//        ////public override ComputerComponents.ComputerType SetComputerType()
//        ////{
//        ////    throw new NotImplementedException();
//        ////}

//        ////public override ComputerComponents.ICpu SetComputerCpu()
//        ////{
//        ////    throw new NotImplementedException();
//        ////}

//        ////public override ComputerComponents.IRam SetComputerRam()
//        ////{
//        ////    throw new NotImplementedException();
//        ////}

//        ////public override ComputerComponents.IHardDrive SetComputerHardDrive()
//        ////{
//        ////    throw new NotImplementedException();
//        ////}

//        ////public override ComputerComponents.IGraphicsRenderer SetComputerGraphicalRenderer()
//        ////{
//        ////    throw new NotImplementedException();
//        ////}

//        ////public override ComputerComponents.IBattery SetComputerBattery()
//        ////{
//        ////    throw new NotImplementedException();
//        ////}

//        ////public override ComputerComponents.Computer ReleaseReadyComputer()
//        ////{
//        ////    throw new NotImplementedException();
//        ////}
//    }
//}

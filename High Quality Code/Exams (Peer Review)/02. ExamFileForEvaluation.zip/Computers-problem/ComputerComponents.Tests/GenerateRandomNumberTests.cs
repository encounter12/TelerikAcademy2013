﻿namespace ComputerComponents.Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class GenerateRandomNumberTests
    {
        [TestMethod]
        public void GenerateRandomNumberBetween1And10ShouldBeCorrect()
        {
            var ram = new Ram(100);
            var personalComputerVideoCard = new VideoCard(false);
            var cpu = new Cpu(8 / 4, 32, ram, personalComputerVideoCard);
            cpu.GenerateRandomNumber(1, 10);

            int actual = ram.LoadValue();
            Assert.IsTrue(0 < actual && actual < 10);
        }

        [TestMethod]
        public void GenerateRandomNumberBetween1And1ShouldSaveInRam1()
        {
            var ram = new Ram(10);
            var personalComputerVideoCard = new VideoCard(false);
            var cpu = new Cpu(8 / 4, 32, ram, personalComputerVideoCard);
            cpu.GenerateRandomNumber(1, 1);

            int actual = ram.LoadValue();
            Assert.IsTrue(actual == 1);
        }

        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        [TestMethod]
        public void GenerateRandomNumberBetween1AndMinus10ShouldThrowException()
        {
            var ram = new Ram(10);
            var personalComputerVideoCard = new VideoCard(false);
            var cpu = new Cpu(8 / 4, 32, ram, personalComputerVideoCard);
            cpu.GenerateRandomNumber(1, -10);
        }

        [TestMethod]
        public void GenerateRandomNumberBetween1000And10000000ShouldSaveInRam()
        {
            var ram = new Ram(1);
            var personalComputerVideoCard = new VideoCard(false);
            var cpu = new Cpu(8 / 4, 32, ram, personalComputerVideoCard);
            cpu.GenerateRandomNumber(1000, 10000000);

            int actual = ram.LoadValue();
            Assert.IsTrue(1000 <= actual && actual < 10000000);
        }
    }
}

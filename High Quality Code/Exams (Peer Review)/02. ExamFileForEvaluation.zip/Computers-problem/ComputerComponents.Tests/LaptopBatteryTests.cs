﻿namespace ComputerComponents.Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    
    [TestClass]
    public class LaptopBatteryTests
    {
        private LaptopBattery battery;

        [TestInitialize]
        public void IntializeBattery()
        {
            this.battery = new LaptopBattery();
        }

        [TestMethod]
        public void LaptopBatteryShouldHave50PercentLevelWhenInitialized()
        {
            int actual = this.battery.Percentage;
            int expected = 50;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void LaptopBatteryShouldHave10PercentLevelWhenDischargedWith40()
        {
            this.battery.Charge(-40);
            int actual = this.battery.Percentage;
            int expected = 10;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void LaptopBatteryShouldHave0PercentLevelWhenOverDischarged()
        {
            this.battery.Charge(-140);
            int actual = this.battery.Percentage;
            int expected = 0;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void LaptopBatteryShouldHave100PercentLevelWhenOverCharged()
        {
            this.battery.Charge(230);
            int actual = this.battery.Percentage;
            int expected = 100;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void LaptopBatteryShouldHave70PercentLevelWhenDischargingAndCharging()
        {
            this.battery.Charge(-20);
            this.battery.Charge(40);
            int actual = this.battery.Percentage;
            int expected = 70;
            Assert.AreEqual(expected, actual);
        }
    }
}

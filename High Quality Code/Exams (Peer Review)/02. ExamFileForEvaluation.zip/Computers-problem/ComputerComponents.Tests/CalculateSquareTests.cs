﻿namespace ComputerComponents.Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Telerik.JustMock;

    [TestClass]
    public class CalculateSquareTests
    {
        [TestMethod]
        public void CalculateSquareShould()
        {
            //// I tried with Mock, but cannot run it.

            ////var cpu = new PrivateAccessor(new Cpu(mo));
            ////cpu.SetProperty("ram", 10);

            ////// Arrange
            ////var cpu = Mock.Create<Cpu>();

            ////Mock.NonPublic.Arrange<int>(cpu, "ram").Returns(5);

            ////// Act
            ////var inst = new PrivateAccessor(cpu);
            ////var actual = inst.GetProperty("Prop");

            ////// Assert
            ////Assert.AreEqual(5, actual);
        }
    }
}

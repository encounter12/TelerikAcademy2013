﻿namespace ComputerComponents
{
    using System;

    public class VideoCard : IGraphicsRenderer
    {
        public VideoCard()
            : this(true)
        {
        }

        public VideoCard(bool isMonochrome = false)
        {
            this.IsMonochrome = isMonochrome;
        }

        public bool IsMonochrome { get; private set; }

        public void Draw(string text)
        {
            if (this.IsMonochrome)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
            }

            Console.WriteLine(text);
            Console.ResetColor();
        }
    }
}

﻿namespace ComputerComponents
{
    public interface ICpu
    {
        byte NumberOfCores { get; }

        void GenerateRandomNumber(int min, int max);

        void CalculateSquare();
    }
}

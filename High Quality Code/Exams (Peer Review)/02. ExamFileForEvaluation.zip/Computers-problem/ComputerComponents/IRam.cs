﻿namespace ComputerComponents
{
    public interface IRam
    {
        int MemoryAmount { get; }

        void SaveValue(int newValue);

        int LoadValue();
    }
}

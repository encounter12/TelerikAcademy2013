﻿namespace ComputerComponents
{
    /// <summary>
    /// Interface that uses RAM and VideoCard to save, load values and Draw on video card.
    /// </summary>
    public interface IMotherboard
    {
        /// <summary>
        /// Reads the value that is saved into the RAM.
        /// </summary>
        /// <returns>32-bit unsigned integer - the value of RAM.</returns>
        int LoadRamValue();

        /// <summary>
        /// Saves new into the RAM and overrides the previous one.
        /// </summary>
        /// <param name="value">Takes the 32-bit signed integer value and overrides the old RAM value</param>
        void SaveRamValue(int value);

        /// <summary>
        /// Gets a text as string and tells the VideoCard to draw it.
        /// </summary>
        /// <param name="data">The string that will be drawn.</param>
        void DrawOnVideoCard(string data);
    }
}

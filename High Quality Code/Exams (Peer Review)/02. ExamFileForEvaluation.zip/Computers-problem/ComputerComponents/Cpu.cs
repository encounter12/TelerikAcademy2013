﻿namespace ComputerComponents
{
    using System;

    public class Cpu : ICpu
    {
        private const int OperationSystem32Bit = 32;
        private const int OperationSystem64Bit = 64;
        private const int OperationSystem128Bit = 128;
        private const int Max32BitNumberToPower = 500;
        private const int Max64BitNumberToPower = 1000;
        private const int Max128BitNumberToPower = 2000;

        private byte numberOfBits;

        // TODO: Extract ram and video in motherboard class
        private Ram ram;

        private VideoCard videoCard;

        private Random random;

        public Cpu(byte numberOfCores, byte numberOfBits, Ram ram, VideoCard videoCard)
        {
            this.NumberOfBits = numberOfBits;
            this.ram = ram;
            this.NumberOfCores = numberOfCores;
            this.videoCard = videoCard;
            this.random = new Random();
        }

        public byte NumberOfCores { get; private set; }

        public byte NumberOfBits
        {
            get
            {
                return this.numberOfBits;
            }

            private set
            {
                if (value != OperationSystem32Bit && value != OperationSystem64Bit && value != OperationSystem128Bit)
                {
                    throw new ArgumentException(
                        string.Format("Invalid processor type. Allowed are {0}bit, {1}bit and {2}bit", OperationSystem32Bit, OperationSystem64Bit, OperationSystem128Bit));
                }

                this.numberOfBits = value;
            }
        }

        public void CalculateSquare()
        {
            var data = this.ram.LoadValue();
            if (data < 0)
            {
                this.videoCard.Draw("Number too low.");
            }
            else if (this.numberOfBits == OperationSystem32Bit && data > Max32BitNumberToPower) 
            {
                this.videoCard.Draw("Number too high.");
            }
            else if (this.numberOfBits == OperationSystem64Bit && data > Max64BitNumberToPower)
            {
                this.videoCard.Draw("Number too high.");
            }
            else if (this.numberOfBits == OperationSystem128Bit && data > Max128BitNumberToPower)
            {
                this.videoCard.Draw("Number too high.");
            }
            else
            {
                int value = 0;
                for (int i = 0; i < data; i++)
                {
                    value += data;
                }

                this.videoCard.Draw(string.Format("Square of {0} is {1}.", data, value));
            }
        }

        public void GenerateRandomNumber(int min, int max)
        {
            int randomNumber = this.random.Next(min, max);
            this.ram.SaveValue(randomNumber);
        }
    }
}

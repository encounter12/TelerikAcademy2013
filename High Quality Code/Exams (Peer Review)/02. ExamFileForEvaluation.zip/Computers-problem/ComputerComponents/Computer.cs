﻿namespace ComputerComponents
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Computer
    {
        private VideoCard videoCard;
        private LaptopBattery battery;

        public Computer(ComputerType computerType, Cpu cpu, Ram ram, IEnumerable<HardDrive> hardDrives, VideoCard videoCard, LaptopBattery battery)
        {
            this.Cpu = cpu;
            this.Ram = ram;
            this.HardDrives = hardDrives;
            this.VideoCard = videoCard;
            this.InitializeServerVideoCard(computerType);
            this.battery = battery;
            this.InitializeLaptopBattery(computerType);
        }

        public Cpu Cpu { get; private set; }

        public Ram Ram { get; private set; }

        public IEnumerable<HardDrive> HardDrives { get; private set; }

        public VideoCard VideoCard
        {
            get
            {
                return this.videoCard;
            }

            private set
            {
                this.videoCard = value;
            }
        }

        public void ChargeBattery(int percentage)
        {
            this.battery.Charge(percentage);

            this.VideoCard.Draw(string.Format("Battery status: {0}%", this.battery.Percentage));
        }

        public void Play(int guessNumber)
        {
            this.Cpu.GenerateRandomNumber(1, 10);
            var number = this.Ram.LoadValue();
            if (number + 1 != guessNumber + 1)
            {
                this.VideoCard.Draw(string.Format("You didn't guess the number {0}.", number));
            }
            else
            {
                this.VideoCard.Draw("You win!");
            }
        }

        public void Process(int data)
        {
            this.Ram.SaveValue(data);
            this.Cpu.CalculateSquare();
        }

        private void InitializeServerVideoCard(ComputerType type)
        {
            if (type == ComputerType.Server)
            {
                bool isMonochrome = true;
                this.VideoCard = new VideoCard(isMonochrome);
            }
        }

        private void InitializeLaptopBattery(ComputerType computerType)
        {
            if (computerType == ComputerType.Laptop)
            {
                this.battery = new LaptopBattery();
            }
        }
    }
}

﻿namespace ComputerComponents
{
    public interface IGraphicsRenderer
    {
        void Draw(string text);
    }
}

﻿namespace ComputerComponents
{
    public enum ComputerType
    {
        PC,
        Laptop,
        Server
    }
}

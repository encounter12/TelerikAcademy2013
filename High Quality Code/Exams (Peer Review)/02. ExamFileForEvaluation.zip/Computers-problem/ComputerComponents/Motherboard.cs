﻿namespace ComputerComponents
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Motherboard : IMotherboard
    {
        private IRam ram;
        private IGraphicsRenderer renderer;

        public Motherboard(IRam ram, IGraphicsRenderer renderer) 
        {
            this.ram = ram;
            this.renderer = renderer;
        }

        public int LoadRamValue()
        {
            throw new NotImplementedException();
        }

        public void SaveRamValue(int value)
        {
            throw new NotImplementedException();
        }

        public void DrawOnVideoCard(string data)
        {
            throw new NotImplementedException();
        }
    }
}

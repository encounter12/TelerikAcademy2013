﻿namespace ComputerComponents
{
    public class LaptopBattery : IBattery
    {
        private const int InitialBatteryPercentage = 50;
        
        public LaptopBattery()
        {
            this.Percentage = InitialBatteryPercentage;
        }

        public int Percentage { get; private set; }

        public void Charge(int percents)
        {
            this.Percentage += percents;
            if (this.Percentage > 100)
            {
                this.Percentage = 100;
            }

            if (this.Percentage < 0)
            {
                this.Percentage = 0;
            }
        }
    }
}

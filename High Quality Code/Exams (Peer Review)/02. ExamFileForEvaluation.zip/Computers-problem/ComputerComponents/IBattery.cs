﻿namespace ComputerComponents
{
    public interface IBattery
    {
        void Charge(int percents);
    }
}

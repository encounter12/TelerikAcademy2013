﻿namespace ComputerComponents
{
    public class Ram : IRam
    {
        private int value;
        
        public Ram(int memoryAmount)
        {
            this.MemoryAmount = memoryAmount;
        }

        public int MemoryAmount { get; private set; }

        public void SaveValue(int newValue)
        {
            this.value = newValue;
        }
        
        public int LoadValue()
        {
            return this.value;
        }
    }
}
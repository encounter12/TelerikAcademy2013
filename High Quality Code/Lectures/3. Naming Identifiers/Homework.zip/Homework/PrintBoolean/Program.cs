﻿namespace PrintBoolean
{
    public class Program
    {
        public static void Main(string[] args)
        {
            BooleanPrinter booleanPrinter = new BooleanPrinter();

            booleanPrinter.Print(true);
        }
    }
}

﻿namespace SimpleFactory
{
    public class FigureL : Figure
    {
        public FigureL() : base(new int[,] { { 0, 0, 1 }, { 1, 1, 1 } })
        {
        }
    }
}

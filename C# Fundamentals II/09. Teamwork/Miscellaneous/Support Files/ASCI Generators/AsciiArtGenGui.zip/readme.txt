Executable directory requires ASCII.xsl and ASCII.xml files in it to work.

Executable directory needs to be writeable for outputing ASCII art as a text or html file.
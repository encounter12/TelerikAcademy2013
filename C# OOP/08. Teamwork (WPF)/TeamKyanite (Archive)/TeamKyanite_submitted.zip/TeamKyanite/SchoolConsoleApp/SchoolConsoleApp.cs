﻿namespace School
{
    using System;
    using System.Linq;
    using System.Data.Linq;
    using System.Data.Objects;
    using System.Globalization;
    using System.Data.EntityClient;
    using System.Data.SqlClient;
    using System.Data.Common;
    using System.Collections.Generic;
    using TeamKyanite.SchoolObjects;

    public class SchoolConsoleApp
    {
        public static void Main()
        {
            //using (SchoolDatabaseContext context = new SchoolDatabaseContext())
            //{
            //    context.Database.Delete();
            //    School school = SchoolTest.CreateSchool();
            //    context.Schools.Add(school);
            //    context.SaveChanges();
            //}

             using (SchoolDatabaseContext context = new SchoolDatabaseContext())
             {
                 List<School> schools = context.Schools.ToList();

                 foreach (var school in schools)
                 {
                     Console.WriteLine(school);
                 }
             }   
          
        }
    }
}

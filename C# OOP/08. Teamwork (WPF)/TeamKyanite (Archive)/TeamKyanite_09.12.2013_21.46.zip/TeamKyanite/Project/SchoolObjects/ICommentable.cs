﻿namespace TeamKyanite.SchoolObjects
{
    using System;

    public interface ICommentable
    {
        string Comment
        {
            get;
            set;
        }       
    }
}

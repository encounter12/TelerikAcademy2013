namespace TeamKyanite.SchoolObjects
{
    public enum ClassRooms
    {
        Default,
        Gym,
        PhysicsLab,
        MathsLab,
        BiologyLab,
        ComputerLab,
        ChemistryLab,
        LinguisticsLab,
        Outdoor
    }
}
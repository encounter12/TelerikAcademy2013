﻿using System;
using System.Linq;

namespace AcademyRPG
{
    public interface ICollectable
    {
    }
}
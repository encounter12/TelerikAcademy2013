﻿using System;
using System.Linq;

namespace AcademyRPG
{
    public enum ResourceType
    {
        Lumber,
        Stone,
        Gold,
    }
}
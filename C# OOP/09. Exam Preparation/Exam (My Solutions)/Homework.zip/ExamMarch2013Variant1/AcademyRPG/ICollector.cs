﻿using System;
using System.Linq;

namespace AcademyRPG
{
    public interface ICollector
    {
        void Method();
    }
}
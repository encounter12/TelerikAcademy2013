﻿using System;
using System.Linq;

namespace AcademyRPG
{
}
﻿namespace JustBelot.Common
{
    public struct DealInfo
    {
        public PlayerPosition FirstPlayerPosition { get; set; }
    }
}

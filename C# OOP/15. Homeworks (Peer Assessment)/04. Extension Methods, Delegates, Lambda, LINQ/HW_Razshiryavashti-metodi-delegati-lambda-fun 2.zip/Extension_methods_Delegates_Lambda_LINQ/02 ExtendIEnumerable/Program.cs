﻿using System;

class Program
{
    static void Main()
    {

        int[] ll = new int[]{ 1, 2, 3, 4, 90, 15, -9 };
        Console.WriteLine(ll.Sum<int>());
        Console.WriteLine(ll.Min<int>());
        Console.WriteLine(ll.Max<int>());
        Console.WriteLine(ll.Average<int>());
    }
}
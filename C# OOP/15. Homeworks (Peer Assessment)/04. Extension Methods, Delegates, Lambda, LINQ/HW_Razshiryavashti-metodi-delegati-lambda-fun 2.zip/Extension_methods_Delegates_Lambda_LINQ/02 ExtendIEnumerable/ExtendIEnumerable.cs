﻿using System;
using System.Collections.Generic;

public static class ExtendIEnumerable
{
    public static T Sum<T>(this IEnumerable<T> input)
    {
        T result = (dynamic)0;
        foreach (var item in input)
        {
            result += (dynamic)item;
        }
        return result;
    }

    public static T Product<T>(this IEnumerable<T> input)
    {
        T result = (dynamic)1;
        foreach (var item in input)
        {
            result *= (dynamic)item;
        }
        return result;
    }

    public static T Min<T>(this IEnumerable<T> input)
    {
        var i = input.GetEnumerator();
        i.MoveNext();
        T result = i.Current;
        while (i.MoveNext())
        {
            if (result > (dynamic)i.Current)
            {
                result = i.Current;
            }
        }
        return result;
    }

    public static T Max<T>(this IEnumerable<T> input)
    {
        var i = input.GetEnumerator();
        i.MoveNext();
        T result = i.Current;
        while (i.MoveNext())
        {
            if (result < (dynamic)i.Current)
            {
                result = i.Current;
            }
        }
        return result;
    }

    public static double Average<T>(this IEnumerable<T> input)
    {
        uint count = 0;
        T result = (dynamic)0;
        foreach (var item in input)
        {
            result += (dynamic)item;
            count++;
        }
        return (dynamic)result/count;
    }
}
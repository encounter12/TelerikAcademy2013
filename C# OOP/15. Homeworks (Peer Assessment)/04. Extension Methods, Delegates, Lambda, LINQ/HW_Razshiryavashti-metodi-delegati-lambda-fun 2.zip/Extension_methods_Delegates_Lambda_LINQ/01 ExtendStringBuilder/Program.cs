﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        StringBuilder test = new StringBuilder("In the rest of your source code, you can invoke these extension methods in the same way as instance methods.");
        Console.WriteLine(test.Substring(6));
    }
}
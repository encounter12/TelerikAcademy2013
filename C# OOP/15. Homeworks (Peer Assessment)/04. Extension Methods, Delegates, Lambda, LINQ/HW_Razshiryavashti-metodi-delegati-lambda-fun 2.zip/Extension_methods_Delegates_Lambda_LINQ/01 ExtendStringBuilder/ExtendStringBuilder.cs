﻿using System;
using System.Text;

public static class ExtendStringBuilder
{
    public static StringBuilder Substring(this StringBuilder input, int index, int length)
    {
        if (index < 0)
        {
            throw new IndexOutOfRangeException();
        }
        else if (length < 0 || index + length > input.Length)
        {
            throw new ArgumentOutOfRangeException();
        }

        return new StringBuilder(input.ToString(), index, length, input.Length);
    }

    public static StringBuilder Substring(this StringBuilder input, int index)
    { return input.Substring(index, input.Length - index); }

}
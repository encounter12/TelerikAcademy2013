﻿using System;
using System.Linq;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int[] arr = new int[] { 0, 2, 3, 4, 5, 6, 7, 21, 17, 23, 42, 10 };

        /* extension methods */
        var div01 = arr.Where(x => x % 21 == 0);

        /* LINQ */
        var div02 =
            from num in arr
            where num % 21 == 0
            select num;

        /* alternate between div01 & div02 */
        foreach (var item in div02) 
        {
            Console.WriteLine(item);
        }
    }
}
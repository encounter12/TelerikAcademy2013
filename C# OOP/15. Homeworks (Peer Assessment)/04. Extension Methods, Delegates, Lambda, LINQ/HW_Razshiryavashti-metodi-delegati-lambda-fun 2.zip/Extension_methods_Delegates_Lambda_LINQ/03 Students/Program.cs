﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        var students = new[] 
        {
            new {FirstName = "Goiko", LastName = "Stoyanov", Age = 19 },
            new {FirstName = "Stefan", LastName = "Uzunski", Age = 23 },
            new {FirstName = "Petar", LastName = "Miloshev", Age = 20 },
            new {FirstName = "Goiko", LastName = "Sakyzov", Age = 27 },
            new {FirstName = "Nikodim", LastName = "Peleshtarski", Age =25 },
            new {FirstName = "Martin", LastName = "Efremov", Age =24 }
        };

        /* Excercise 3 */
        var lastFirst =
            from s in students
            where s.FirstName.CompareTo(s.LastName) < 0
            select s;
        Console.WriteLine("\tStudents with first name alphabeticaly before last name");
        foreach (var item in lastFirst)
        {
            Console.WriteLine(item);
        }

        /* Excercise 4 */
        var byAge =
            from s in students
            where s.Age >= 18 && s.Age <= 24
            select s;
        Console.WriteLine("\tStudents with age between 18 & 24");
        foreach (var item in byAge)
        {
            Console.WriteLine(item);
        }

        /* Excercise 5 */
        var order01 = students.OrderByDescending(s => s.FirstName).ThenByDescending(s => s.LastName);
        var order02 =
            from s in students
            orderby s.FirstName descending, s.LastName descending
            select s;

        Console.WriteLine("\tStudents ordered by name");
        foreach (var item in order02) // switch between order01 & order02
        {
            Console.WriteLine(item);
        }
    }
}
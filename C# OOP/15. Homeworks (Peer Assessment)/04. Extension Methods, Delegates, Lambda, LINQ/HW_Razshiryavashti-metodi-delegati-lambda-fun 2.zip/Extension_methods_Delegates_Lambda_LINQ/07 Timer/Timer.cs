﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

public static class Timer
{
    public static void ExecEvery(this Action func, int t_seconds)
    {
        while (true)
        {
            Thread.Sleep(t_seconds * 1000);
            func();
        }
    }
}
﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Action tellTheTime = () => Console.WriteLine(DateTime.Now);
        tellTheTime.ExecEvery(5);
    }
}
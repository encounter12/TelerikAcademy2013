﻿using System;

/* Event Publisher */
public class Timer
{
    /* delegate that subscribers must implement */
    public delegate void EventHandler<DateTime>(Timer timer, DateTime e);

    /* the event 'Timer' publishes */
    public event EventHandler<DateTime> Tick;

    /* method which trigger the event */
    protected void OnTimeChange(Timer timer, DateTime time)
    {
        /* if there are subscribers */
        if (Tick != null)
        {
            /* trigger Event */
            Tick(this, DateTime.Now);
        }
    }

    /* start the timer and trigger event every t_sec */
    public void Start(int t_sec)
    {
        while (true)
        {
            System.Threading.Thread.Sleep(t_sec * 1000);
            OnTimeChange(this, DateTime.Now);
        }
    }
}
﻿using System;

/* Event Subscriber */
public class Listener
{
    /* subscribe to Tick event */
    public void Subscribe(Timer timer)
    {
        timer.Tick += new Timer.EventHandler<DateTime>(Echo);
    }

    /* method implementing the delegate of Publisher */
    private void Echo(Timer t, DateTime e)
    {
        Console.WriteLine(e);
    }
}
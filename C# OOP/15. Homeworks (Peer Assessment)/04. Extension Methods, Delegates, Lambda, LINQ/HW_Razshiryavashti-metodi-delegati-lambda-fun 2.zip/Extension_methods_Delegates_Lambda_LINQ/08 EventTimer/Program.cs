﻿using System;

class Program
{
    static void Main()
    {
        Timer t = new Timer();
        Listener l = new Listener();
        l.Subscribe(t);
        t.Start(3);     // trigger event every 3 sec
    }
}
﻿using System;

namespace CalculateShapeSurface
{    
    public class Rectangle: Shape
    {
        public Rectangle(double height, double width)
        {
            if (width <= 0 || height <= 0)
            {
                throw new ArgumentOutOfRangeException("Width and heigth should be bigger than zero!");
            }
            else
            {
                this.Width = width;
                this.Height = height;
            } 
        }

        public override double CalculateSuraface()
        {
            return this.Height * this.Width;
        }
    }
}

﻿using System;

namespace CalculateShapeSurface
{
    public class Circle : Shape
    {
        public double Radius
        {
            get { return this.Height; }
            set
            {
                this.Height = value;
                this.Width = value;
            }          
        }

        public Circle(double radius)
        {
            if (radius <= 0)
            {
                throw new ArgumentOutOfRangeException("Radius should be positive number!");
            }
            else
            {
                this.Height = radius;
                this.Width = radius;
            }
        }

        public override double CalculateSuraface()
        {
            return Math.PI * this.Height * this.Width;
        }
    }
}

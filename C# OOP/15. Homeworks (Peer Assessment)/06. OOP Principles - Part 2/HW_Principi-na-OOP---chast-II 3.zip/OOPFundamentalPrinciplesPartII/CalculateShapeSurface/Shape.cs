﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateShapeSurface
{
    public abstract class Shape
    {
        protected double Width { get; set; }
        protected double Height { get; set; }

        public abstract double CalculateSuraface();
    }
}

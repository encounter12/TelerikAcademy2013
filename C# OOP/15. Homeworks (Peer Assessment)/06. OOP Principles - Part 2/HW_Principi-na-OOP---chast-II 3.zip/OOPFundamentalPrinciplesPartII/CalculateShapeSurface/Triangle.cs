﻿using System;

namespace CalculateShapeSurface
{
    public class Triangle: Shape
    {
        public Triangle(double height, double side)
        {
            if (side <= 0 || height <= 0)
            {
                throw new ArgumentOutOfRangeException("The side and heigth of the triangle should be bigger than zero!");
            }
            else
            {
                this.Height = height;
                this.Width = side;
            }     
        }

        public override double CalculateSuraface()
        {
            return ( this.Height * this.Width ) / 2;
        }
    }
}

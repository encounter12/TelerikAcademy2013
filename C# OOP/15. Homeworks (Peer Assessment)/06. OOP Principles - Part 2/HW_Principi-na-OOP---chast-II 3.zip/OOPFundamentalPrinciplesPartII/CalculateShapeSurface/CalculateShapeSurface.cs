﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CalculateShapeSurface
{
    class CalculateShapeSurface
    {
        static void Main()
        {
            Shape[] shapes = { new Rectangle(5, 6), new Circle(3.4), new Triangle(2, 3), new Circle(3) };
            foreach (var shape in shapes)
            {
                Console.WriteLine("The surface of {0} is {1:F2}.", shape.GetType().Name, shape.CalculateSuraface());
            }

            Console.WriteLine();
            Circle cir = new Circle(9);
            cir.Radius = 5;
            Console.WriteLine(cir.Radius);

        }
    }
}

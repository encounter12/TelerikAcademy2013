﻿using System;

namespace BankSystem
{
    public class LoanAccount : Account, IDepositable, IInterestable
    {
        public LoanAccount(Customer customer, decimal balance, decimal interest) : base(customer, balance, interest) { }

        public decimal CalculateInterest(int months)
        {
            if (months > 0 && months < 3)
                return 0;
            if (months == 3 && this.AccountCustomer == Customer.individual)
                return 0;
            else
            {
                if (this.AccountCustomer == Customer.individual)
                    return this.InterestRate * (months - 3);
                else 
                    return this.InterestRate * (months - 2);
            }
        }

        public void depositMoney(decimal money)
        {
           this.Balance += money;
        }
    }
}

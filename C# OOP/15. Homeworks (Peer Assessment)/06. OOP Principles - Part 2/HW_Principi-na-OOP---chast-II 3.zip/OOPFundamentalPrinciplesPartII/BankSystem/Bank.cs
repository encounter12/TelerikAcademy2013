﻿using System;

namespace BankSystem
{
    class Bank
    {
        static void Main()
        {
            DepositAccount deposit = new DepositAccount(Customer.company, 567.46m, 0.8m);
            LoanAccount loan = new LoanAccount(Customer.individual, 5876.9m, 1m);
            Console.WriteLine(loan.CalculateInterest(5));
        }
    }
}

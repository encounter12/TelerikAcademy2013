﻿using System;

namespace BankSystem
{
    public class MortgageAccount: Account, IDepositable, IInterestable
    {
        public MortgageAccount(Customer customer, decimal balance, decimal interest) : base(customer, balance, interest) { }

        public decimal CalculateInterest(int months)
        {
            if(this.AccountCustomer == Customer.individual)
            {
                if (months >= 6)
                    return 0;
                else
                    return this.InterestRate * (months - 6);
            }
            else
            {
                if (months >= 12)
                    return 0;
                else
                    return this.InterestRate * (months - 12);
            }
        }

        public void depositMoney(decimal money)
        {
           this.Balance += money;
        }
    }
}

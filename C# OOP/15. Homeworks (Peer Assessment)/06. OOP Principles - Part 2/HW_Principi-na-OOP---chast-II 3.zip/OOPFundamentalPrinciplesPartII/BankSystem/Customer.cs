﻿using System;

namespace BankSystem
{
    public enum Customer { individual, company }
}

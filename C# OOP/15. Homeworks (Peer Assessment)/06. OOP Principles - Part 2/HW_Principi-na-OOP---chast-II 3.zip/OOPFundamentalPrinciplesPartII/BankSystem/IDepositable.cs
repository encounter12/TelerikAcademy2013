﻿using System;

namespace BankSystem
{
    interface IDepositable
    {
        void depositMoney(decimal money);
    }
}

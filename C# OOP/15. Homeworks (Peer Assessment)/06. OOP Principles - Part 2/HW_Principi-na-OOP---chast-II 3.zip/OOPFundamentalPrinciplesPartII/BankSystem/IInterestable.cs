﻿using System;
using System.Collections.Generic;

namespace BankSystem
{
    interface IInterestable
    {
        decimal CalculateInterest(int months);
    }
}

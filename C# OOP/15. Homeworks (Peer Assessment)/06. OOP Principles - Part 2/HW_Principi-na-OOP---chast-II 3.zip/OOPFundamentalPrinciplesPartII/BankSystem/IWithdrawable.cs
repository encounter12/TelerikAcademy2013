﻿using System;

namespace BankSystem
{
    interface IWithdrawable
    {
        void withdrawMoney(decimal money);
    }
}

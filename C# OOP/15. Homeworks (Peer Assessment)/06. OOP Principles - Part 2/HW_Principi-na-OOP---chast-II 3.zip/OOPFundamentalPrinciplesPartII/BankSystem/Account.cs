﻿using System;

namespace BankSystem
{
    public abstract class Account
    {
        protected Customer AccountCustomer { get; set; }
        protected decimal Balance { get; set; }
        protected decimal InterestRate { get; set; }

        protected Account(Customer customer, decimal balance = 0, decimal interest = 0)
        {
            this.AccountCustomer = customer;
            this.Balance = balance;
            this.InterestRate = interest;
        }
    }
}

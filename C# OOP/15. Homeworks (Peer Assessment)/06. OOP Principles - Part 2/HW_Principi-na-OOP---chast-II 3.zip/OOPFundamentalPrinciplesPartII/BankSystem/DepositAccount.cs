﻿using System;

namespace BankSystem
{
    public class DepositAccount: Account, IWithdrawable, IDepositable, IInterestable
    {
        public DepositAccount(Customer customer, decimal balance, decimal interest) : base(customer, balance, interest) { }

        public decimal CalculateInterest(int months)
        {
            if (this.Balance > 0 && this.Balance < 1000)
                return 0;
            else
            {
                return this.InterestRate * months;
            }
        }

        public void depositMoney(decimal money)
        {
            this.Balance += money;
        }

        public void withdrawMoney(decimal money)
        {
            this.Balance -= money;
        }
    }
}

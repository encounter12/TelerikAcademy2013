﻿using System;
using System.Linq;

  public interface IDepositable
    {
      void DepositMoney(decimal money);
    }


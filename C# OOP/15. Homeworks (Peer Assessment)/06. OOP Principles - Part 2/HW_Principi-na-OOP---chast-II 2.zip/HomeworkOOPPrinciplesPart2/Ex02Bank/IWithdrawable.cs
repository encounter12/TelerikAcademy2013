﻿using System;
using System.Linq;


   public interface IWithdrawable
    {
       void WithDraw(decimal money);
    }


﻿using System;
using System.Linq;

    public enum Customer{ Company,Individual }


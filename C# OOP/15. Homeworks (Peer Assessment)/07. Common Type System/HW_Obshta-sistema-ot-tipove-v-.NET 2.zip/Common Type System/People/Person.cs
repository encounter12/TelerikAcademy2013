﻿using System;

/*
 * Create a class Person with two fields – name and age.
 * Age can be left unspecified (may contain null value.
 * Override ToString() to display the information of a person and if age
 * is not specified – to say so. Write a program to test this functionality.
 */

namespace Telerik.Homework.Oop.Cts
{
    public class Person
    {
        // Fields and Properties
        private readonly string name;
        private readonly byte? age;

        public string Name { get { return this.name; } }
        public byte? Age { get { return this.age; } }

        // Constructors
        public Person(string name, byte? age)
        {
            this.name = name;
            this.age = age;
        }

        public Person(string name) : this(name, null) { }

        // Methods
        public override string ToString()
        {
            string personInfo = this.name;

            if (this.age == null)
            {
                personInfo += " - unknown age";
            }
            else
            {
                personInfo += " - " + this.age + " years old";
            }

            return personInfo ;
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace Telerik.Homework.Oop.Cts
{
    class Example
    {
        static void Main(string[] args)
        {
            // Create instances of Person and print them out
            List<Person> people = new List<Person>();
            people.Add(new Person("Ivan Ivanov"));
            people.Add(new Person("Stoyan Kirov", 23));
            people.Add(new Person("Kaloyan Hlebarov", 27));

            foreach (var person in people)
            {
                Console.WriteLine(person);
            }
        }
    }
}

﻿using System;

namespace Telerik.Homework.Oop.Cts
{
    class Example
    {
        static void Main()
        {
            // Create three BitArrays64 
            BitArray64 first = new BitArray64(21);
            BitArray64 second = new BitArray64(123456789);
            BitArray64 third = new BitArray64();

            // Use indexer to set value of third to ....0101010 (21), same value as first
            third[1] = 1;
            third[3] = 1;
            third[5] = 1;

            // Print out first and second as binary
            foreach (var bit in first)
            {
                Console.Write(bit);
            }
            Console.WriteLine();

            foreach (var bit in second)
            {
                Console.Write(bit);
            }
            Console.WriteLine("\n");

            // Check if == and != operators work and print their hash codes
            if (first != second)
            {
                Console.WriteLine("First diff from second.");
                Console.WriteLine("First hash code : " + first.GetHashCode());
                Console.WriteLine("Second hash code : " + second.GetHashCode() + Environment.NewLine);
            }
            if (first == third)
            {
                Console.WriteLine("First same as third.");
                Console.WriteLine("First hash code : " + first.GetHashCode());
                Console.WriteLine("Third hash code : " + third.GetHashCode());
            }
        }
    }
}

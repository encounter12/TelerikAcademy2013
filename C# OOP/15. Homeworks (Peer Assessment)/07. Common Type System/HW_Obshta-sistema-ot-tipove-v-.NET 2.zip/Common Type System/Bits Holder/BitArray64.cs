﻿using System;
using System.Collections;
using System.Collections.Generic;

/*
 * Define a class BitArray64 to hold 64 bit values inside an ulong value.
 * Implement IEnumerable<int> and Equals(…), GetHashCode(), [], == and !=.
 */

namespace Telerik.Homework.Oop.Cts
{
    public class BitArray64 : IEnumerable<int>
    {
        // Fields and Properties
        private ulong storageNum;

        // Constructors
        public BitArray64()
        {
            this.storageNum = 0;
        }

        public BitArray64(ulong number)
        {
            this.storageNum = number;
        }

        // Methods
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public IEnumerator<int> GetEnumerator()
        {
            for (int i = 63; i > -1; i--)
            {
                yield return this[i];
            }
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            BitArray64 other = obj as BitArray64;
            if ((Object)other == null)
            {
                return false;
            }

            if ((ulong)this.storageNum != (ulong)other.storageNum)
            {
                return false;
            }

            return true;
        }

        public override int GetHashCode()
        {
            // I am not sure if this is a correct implementation,
            // since it just returns the value of storageNum if it can fit in an int.
            return this.storageNum.GetHashCode();
        }

        // Indexer
        public int this[int index]
        {
            get
            {
                ulong mask = 1;
                int bit = (int)(this.storageNum & (mask << index - 1));

                if (bit > 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }

            set
            {
                ulong mask = 1;

                if (value != 1 && value != 0)
                {
                    throw new ArgumentOutOfRangeException("BitArray64 can only store 1 or 0 as value.");
                }
                else if (value == 1)
                {
                    this.storageNum = this.storageNum | (mask << index - 1);
                }
                else
                {
                    mask = ~(mask << index - 1);
                    this.storageNum = this.storageNum & mask;
                }
            }
        }

        // Operators
        public static bool operator ==(BitArray64 first, BitArray64 second)
        {
            return BitArray64.Equals(first, second);
        }

        public static bool operator !=(BitArray64 first, BitArray64 second)
        {
            return !BitArray64.Equals(first, second);
        }

    }

}

﻿using System;

namespace Telerik.Homework.Oop.Cts
{
    public enum Specialities { OOP, FunctionalProgramming, WebDesign, Security, Networking }
    public enum Universities { SofiaUniversity, TechnicalUniversity, UNWE, NewBulgarian }
    public enum Faculties { Electronics, ComputerSystems, Mathematics, ForeignLanguages }
}

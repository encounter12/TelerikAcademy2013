﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

/*
 * Define a class Student, which contains data about a student – first, middle and last name,
 * SSN, permanent address, mobile phone e-mail, course, specialty, university, faculty.
 * Use an enumeration for the specialties, universities and faculties.
 * Override the standard methods, inherited by  System.Object: Equals(),
 * ToString(), GetHashCode() and operators == and !=.
 * 
 * Add implementations of the ICloneable interface.
 * The Clone() method should deeply copy all object's fields into a new object of type Student.
 * 
 * Implement the  IComparable<Student> interface to compare students by names
 * (as first criteria, in lexicographic order) and by social security number
 * (as second criteria, in increasing order).
 */

namespace Telerik.Homework.Oop.Cts
{
    [Serializable]
    public class Student : ICloneable, IComparable<Student>
    {
        // Fields and Properties
        public string FirstName { get; private set; }
        public string MiddleName { get; private set; }
        public string LastName { get; private set; }
        public long Ssn { get; private set; }

        public string Address { get; set; }
        public int Phone { get; set; }
        public string Email { get; set; }
        public string Course { get; set; }
        public Specialities Speciality { get; set; }
        public Universities University { get; set; }
        public Faculties Faculty { get; set; }

        // Constructors
        public Student(string firstName, string middleName, string lastName, long ssn)
        {
            this.FirstName = firstName;
            this.MiddleName = middleName;
            this.LastName = lastName;
            this.Ssn = ssn;
        }

        // Methods
        // Override
        public override string ToString()
        {
            string studentInfo = string.Format("Student Name : {0} {1} {2} \n",
                this.FirstName, this.MiddleName, this.LastName);
            studentInfo += string.Format("Student in {0}, {1}, {2}",
                this.University, this.Faculty, this.Speciality);
            return studentInfo;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            Student compareStudent = obj as Student;
            if ((object)compareStudent == null) // Cast to object to avoid recursion and use object.equals
            {
                return false;
            }

            // Assuming that SSN/EGN are unique we don't have to check the rest
            return (this.Ssn == compareStudent.Ssn);
        }

        public override int GetHashCode()
        {
             return this.FirstName.GetHashCode() ^ this.Ssn.GetHashCode();
        }

        // Clone
        // Creates a deep copy by copying the memory where the copied object is stored
        // as seen on StackExchange 
        // (http://stackoverflow.com/questions/129389/how-do-you-do-a-deep-copy-an-object-in-net-c-specifically)

        public Object Clone()
        {
            using (var ms = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(ms, this);
                ms.Position = 0;

                return (object)formatter.Deserialize(ms);
            }
        }

        // CompareTo
        public int CompareTo(Student otherStudent)
        {
            // Compare by last name, then first name, then middle name
            // Use string.CompareTo method
            if (this.LastName.CompareTo(otherStudent.LastName) != 0)
            {
                return this.LastName.CompareTo(otherStudent.LastName);
            }

            if (this.FirstName.CompareTo(otherStudent.FirstName) != 0)
            {
                return this.FirstName.CompareTo(otherStudent.FirstName);
            }

            if (this.MiddleName.CompareTo(otherStudent.MiddleName) != 0)
            {
                return this.MiddleName.CompareTo(otherStudent.MiddleName);
            }

            // If all names are the same, compare by SSN
            if (this.Ssn < otherStudent.Ssn)
            {
                return -1;
            }
            else if (this.Ssn > otherStudent.Ssn)
            {
                return 1;
            }
            else
            {
                // SSN should be unique for every student object
                throw new Exception("SSN duplicate found.");
            }
        }

        // Operators
        public static bool operator ==(Student first, Student second)
        {
            return Student.Equals(first, second);      
        }

        public static bool operator !=(Student first, Student second)
        {
            return !(Student.Equals(first, second));
        }
    }
}

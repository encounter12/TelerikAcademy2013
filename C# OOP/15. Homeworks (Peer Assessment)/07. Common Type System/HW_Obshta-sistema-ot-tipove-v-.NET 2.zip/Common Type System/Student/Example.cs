﻿using System;
using System.Collections.Generic;

namespace Telerik.Homework.Oop.Cts
{
    class Example
    {
        static void Main()
        {
            // Create instances of the class Student
            Student firstStudent = new Student("Ivan", "Ivanov", "Stoyanov", 9003123212);          
            firstStudent.University = Universities.TechnicalUniversity;
            firstStudent.Faculty = Faculties.Mathematics;
            firstStudent.Speciality = Specialities.OOP;

            Student secondStudent = new Student("Petar", "Petrov", "Trifonov", 9110221332);
            secondStudent.University = Universities.SofiaUniversity;
            secondStudent.Faculty = Faculties.ComputerSystems;
            secondStudent.Speciality = Specialities.Networking;


            // Create new student with the same fields as another student
            Student duplicateStudent = new Student("Ivan", "Ivanov", "Stoyanov", 9003123212); 


            // Show Students info
            Console.WriteLine(firstStudent);
            Console.WriteLine(secondStudent + Environment.NewLine);


            // Compare instances by value and by reference
            if (firstStudent == duplicateStudent)
            {
                Console.WriteLine("Compare students by reference: " + ((object)firstStudent == (object)duplicateStudent));
                Console.WriteLine("Compare students by SSN value: " + (firstStudent == duplicateStudent));
            }

            if (firstStudent != null)
            {
                Console.WriteLine(firstStudent.FirstName + " != null" );
            }
            

            if (firstStudent != secondStudent)
            {
                Console.WriteLine(firstStudent.FirstName + " != " + secondStudent.FirstName + Environment.NewLine);
            }


            // Create a deep copy of a student and demonstrate result
            Student aDeepCopy = (Student)firstStudent.Clone();

            Console.WriteLine("***ORIGINAL:");
            Console.WriteLine(firstStudent);
            Console.WriteLine("***DEEP COPY:");
            Console.WriteLine(aDeepCopy + Environment.NewLine);

            firstStudent.University = Universities.UNWE;
            firstStudent.Faculty = Faculties.Electronics;

            Console.WriteLine("We change some properties of the original student and...\n");
            Console.WriteLine("***ORIGINAL:");
            Console.WriteLine(firstStudent);
            Console.WriteLine("***DEEP COPY:");
            Console.WriteLine(aDeepCopy + Environment.NewLine);
            

            // Create list of students and sort it
            List<Student> allStudents = new List<Student>();
            allStudents.Add(firstStudent);
            allStudents.Add(secondStudent);
            allStudents.Add(new Student("Ivan", "Asenov", "Stoyanov", 9000000000));
            allStudents.Add(new Student("Ivan", "Asenov", "Stoyanov", 9000000001));

            // Adding duplicate should throw exception when sorting because of duplicate SSNs
            // allStudents.Add(duplicateStudent);
            allStudents.Sort();

            Console.WriteLine("***SORTED LIST***");
            foreach (var student in allStudents)
            {
                Console.WriteLine(student + "\n SSN - " + student.Ssn);
            }           
        }
    }
}

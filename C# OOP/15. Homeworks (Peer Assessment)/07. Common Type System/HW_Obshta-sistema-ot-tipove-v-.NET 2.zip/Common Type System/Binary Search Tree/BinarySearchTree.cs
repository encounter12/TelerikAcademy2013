﻿using System;
using System.Collections;
using System.Collections.Generic;

/*
 * Define the data structure binary search tree with operations for "adding new element",
 * "searching element" and "deleting elements". It is not necessary to keep the tree balanced.
 * 
 * Implement the standard methods from System.Object – ToString(), Equals(…), GetHashCode()
 * and the operators for comparison  == and !=. Add and implement the ICloneable interface
 * for deep copy of the tree. Remark: Use two types – structure BinarySearchTree (for the tree)
 * and class TreeNode (for the tree elements). Implement IEnumerable<T> to traverse the tree.
 */

namespace Telerik.Homework.Oop.Cts
{
    public class TreeNode
    {
        public int data;
        public TreeNode left, right;

        public TreeNode(int data)
        {
            this.data = data;
            left = null;
            right = null;
        }
    }

    public class BinarySearchTree : IEnumerable, ICloneable
    {
        // Fields-----------------------------------------------

        public TreeNode root;

        // Constructors-----------------------------------------

        public BinarySearchTree()
        {
            root = null;
        }

        public BinarySearchTree(int data)
        {
            root = new TreeNode(data);
        }

        public BinarySearchTree(TreeNode node)
            : this(node.data) { }

        // Methods----------------------------------------------

        // Overriden---------------------

        public override string ToString()
        {
            return DrawNode(this.root);
        }

        public override bool Equals(object obj) // Compares by value not by reference
        {
            if (obj == null)
                return false;

            BinarySearchTree otherTree = obj as BinarySearchTree;
            if ((Object)otherTree == null)
                return false;

            TreeNode current = this.root;
            TreeNode otherCurrent = otherTree.root;
            Stack<TreeNode> thisStack = new Stack<TreeNode>();
            Stack<TreeNode> thatStack = new Stack<TreeNode>();

            // Iterrator is explained in detail in the GetEnumerator mehod
            while (thisStack.Count != 0 || current != null)
            {
                if (current != null)
                {
                    if (current.data != otherCurrent.data)
                        return false;

                    if (current.right != null && otherCurrent.right != null)
                    {
                        thisStack.Push(current.right);
                        thatStack.Push(otherCurrent.right);
                    }
                    else if (current.right != null && otherCurrent.right == null)
                        return false;
                    else if (current.right == null && otherCurrent.right != null)
                        return false;

                    current = current.left;
                    otherCurrent = otherCurrent.left;
                }
                else
                {
                    current = thisStack.Pop();
                    otherCurrent = thatStack.Pop();
                }
            }

            return true;
        }

        public override int GetHashCode()
        {
            int result = this.root.data;

            // Not sure if this will return same value for equal objects (by value)
            foreach (var node in this)
            {
                result = result ^ node.data;
            }

            return result;
        }
     
        // Inherited/Required------------

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public IEnumerator<TreeNode> GetEnumerator()
        {
            /*
             * PSEUDO CODE
             * 
             * iterativePreorder(node)
             *   parentStack = empty stack
             *   while not parentStack.isEmpty() or node ≠ null
             *     if node ≠ null then
             *       visit(node)
             *       if node.right ≠ null then
             *         parentStack.push(node.right)
             *       node = node.left
             *     else
             *       node = parentStack.pop()
             *       
             * Basically, this itterates throught the leftmost branch and
             * keeps a stack of parent nodes that can branch to the right.
             * So when we reach the end of the leftmost branch we pop the last
             * parent upstream that holds right path, we turn right and continue left from there.
             */

            TreeNode current = this.root;
            Stack<TreeNode> nodeStack = new Stack<TreeNode>(); // Stack will grow proportional to the height of the tree

            while (nodeStack.Count != 0 || current != null)
            {
                if (current != null)
                {
                    yield return current;

                    if (current.right != null) // If node can branch right, keep it in the stack for later use
                    {
                        nodeStack.Push(current.right);
                    }
                    current = current.left;    // Go left
                }
                else
                {
                    current = nodeStack.Pop(); // No more nodes to the left, turn right at closest possible node
                }               
            }
        }

        public Object Clone()
        {
            BinarySearchTree theClone = new BinarySearchTree();

            TreeNode current = this.root;
            Stack<TreeNode> nodeStack = new Stack<TreeNode>(); 

            // Same iteration as in GetEnumerator but with different action
            while (nodeStack.Count != 0 || current != null)
            {
                if (current != null)
                {
                    TreeNode nodeClone = new TreeNode(current.data);
                    theClone.AddNode(nodeClone);

                    if (current.right != null)
                    {
                        nodeStack.Push(current.right);
                    }
                    current = current.left;
                }
                else
                {
                    current = nodeStack.Pop();
                }
            }

            return theClone;
        }


        // Unique Methods----------------

        public TreeNode Search(TreeNode byNode)
        {
            return this.Search(byNode.data);
        }


        public TreeNode Search(int byKey)
        {
            TreeNode tempNode = this.root;

            if (tempNode == null)
            {
                Console.WriteLine("Binary Searh Tree is empty");
            }

            while (tempNode != null)
            {
                if (tempNode.data < byKey)
                {
                    tempNode = tempNode.right;
                }
                else if (tempNode.data > byKey)
                {
                    tempNode = tempNode.left;
                }
                else if (tempNode.data == byKey)
                {
                    return tempNode;
                }
            }

            return null;
        }

        public TreeNode SearchParent(int byKey) // I know this is repetative but didn't have time to think of something better
        {
            TreeNode parent = null;
            TreeNode tempNode = this.root;

            if (tempNode == null)
            {
                Console.WriteLine("Binary Searh Tree is empty");
            }

            while (tempNode != null)
            {
                if (tempNode.data < byKey)
                {
                    parent = tempNode;
                    tempNode = tempNode.right;
                }
                else if (tempNode.data > byKey)
                {
                    parent = tempNode;
                    tempNode = tempNode.left;
                }
                else if (tempNode.data == byKey)
                {
                    return parent;
                }
            }

            return null;
        }


        public void AddNode(TreeNode node)
        {
            TreeNode tempNode = this.root;

            if (tempNode == null)
            {
                this.root = node;
                return;
            }

            while (tempNode != null)
            {
                if (tempNode.data < node.data)
                {
                    if (tempNode.right != null)
                    {
                        tempNode = tempNode.right;
                    }
                    else
                    {
                        tempNode.right = node;
                        break;
                    }
                }
                else if (tempNode.data > node.data)
                {
                    if (tempNode.left != null)
                    {
                        tempNode = tempNode.left;
                    }
                    else
                    {
                        tempNode.left = node;
                        break;
                    }
                }
                else if (tempNode.data == node.data)
                {
                    Console.WriteLine("Node with same data already exists.");
                    break;
                }
            }
        }

        public void DeleteNode(TreeNode node)
        {
            TreeNode found = Search(node);
            TreeNode parent = SearchParent(node.data);

            if (found.left == null && found.right == null)
            {
                DeleteNoSuccessorNode(node, parent);
            }
            else if (found.left != null && found.right != null)
            {
                DeleteTwoSuccessorsNode(found, parent);
            }
            else
            {
                DeleteSingleSuccessorNode(found, parent);
            }
        }

        private static void DeleteSingleSuccessorNode(TreeNode found, TreeNode parent)
        {
            if (parent.left == found)
            {
                parent.left = found.left ?? found.right;
            }
            else
            {
                parent.right = found.left ?? found.right;
            }
        }

        private void DeleteTwoSuccessorsNode(TreeNode found, TreeNode parent)
        {
            // If Node we want to delete has two successors we cannot simply remove it,
            // we need to replace it with a new node that has only one successor.
            // Arbitarily choose right successor to replace deleted node.
            TreeNode replacement = new TreeNode(found.left.data);
            replacement.right = found.right;

            if (parent.left == found)
            {
                parent.left = replacement;
            }
            else
            {
                parent.right = replacement;
            }
        }

        private void DeleteNoSuccessorNode(TreeNode node, TreeNode parent)
        {
            if (parent.left == node)
            {
                parent.left = null;
            }
            else
            {
                parent.right = null;
            }
        }

        // Draws all nodes, starting from given, with recursion
        private string DrawNode(TreeNode node)
        {
            if (node == null)
                return "empty";

            if ((node.left == null) && (node.right == null))
                return node.data.ToString();
            if ((node.left != null) && (node.right == null))
                return node.data + "(" + DrawNode(node.left) + ", _)";

            if ((node.right != null) && (node.left == null))
                return node.data + "(_, " + DrawNode(node.right) + ")";

            return node.data + "(" + DrawNode(node.left) + ", " + DrawNode(node.right) + ")";
        }

        // Overload Operators---------------------------------------

        public static bool operator ==(BinarySearchTree first, BinarySearchTree second)
        {
            // If both are null, or both are same instance, return true.
            if (System.Object.ReferenceEquals(first, second))
                return true;

            // If one is null, but not both, return false. Cast to object first to prevent infinite recursion.
            if (((object)first == null) || ((object)second == null))
                return false;

            // Return true if the fields match:
            return first.Equals(second);
        }

        public static bool operator !=(BinarySearchTree first, BinarySearchTree second)
        {
            return !(first == second);
        }
    }
}

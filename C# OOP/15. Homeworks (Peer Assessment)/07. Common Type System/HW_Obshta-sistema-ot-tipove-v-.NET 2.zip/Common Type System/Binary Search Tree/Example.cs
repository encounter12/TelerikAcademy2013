﻿using System;

namespace Telerik.Homework.Oop.Cts
{
    class Example
    {
        static void Main()
        {
            // Sorry for the poor examples, had to upload homework

            BinarySearchTree myTree = new BinarySearchTree(10);
            myTree.root.left = new TreeNode(5);
            myTree.root.right = new TreeNode(120);

            TreeNode testNode = new TreeNode(10);
            TreeNode result = myTree.Search(testNode);
            result = myTree.Search(100);           

            myTree.AddNode(new TreeNode(7));
            myTree.AddNode(new TreeNode(3));
            myTree.AddNode(new TreeNode(100));
            myTree.DeleteNode(new TreeNode(120));
            Console.WriteLine(myTree);


            foreach (var node in myTree)
            {
                Console.WriteLine(node.data);
            }

            BinarySearchTree deepCopy = (BinarySearchTree)myTree.Clone();
            Console.WriteLine(myTree.Equals(deepCopy));
            Console.WriteLine(myTree == deepCopy);

            myTree.DeleteNode(new TreeNode(7));
            myTree.DeleteNode(new TreeNode(3));
            myTree.DeleteNode(new TreeNode(100));

            Console.WriteLine("Deep copy - " + deepCopy);
            Console.WriteLine("Changed original - " + myTree);
            Console.WriteLine(myTree.Equals(deepCopy));
            Console.WriteLine(myTree == deepCopy);
        }
    }
}

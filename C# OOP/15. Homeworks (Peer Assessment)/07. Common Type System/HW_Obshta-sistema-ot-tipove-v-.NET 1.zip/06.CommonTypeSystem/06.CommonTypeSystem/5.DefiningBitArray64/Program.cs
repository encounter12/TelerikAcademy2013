﻿using System;
using System.Linq;

namespace _5.DefiningBitArray64
{
    class Program
    {
        static void Main(string[] args)
        {
            BitArray64 firstNumber = new BitArray64(98566323);
            BitArray64 secondNumber = new BitArray64(5563998);
            Console.WriteLine(secondNumber);

            foreach (var bit in firstNumber)
            {
                Console.Write(bit);
            }
            Console.WriteLine();

            Console.WriteLine(firstNumber.Equals(secondNumber));
            Console.WriteLine(firstNumber != secondNumber);

            Console.WriteLine(firstNumber.GetHashCode());
            Console.WriteLine(secondNumber.GetHashCode());
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5.DefiningBitArray64
{
    public class BitArray64 : IEnumerable<int>
    {
        private ulong uNumber;

        public BitArray64(object number)
        {
            ulong result;
            if (ulong.TryParse(number.ToString(), out result))
            {
                this.uNumber = result;
            }
            else
            {
                throw new ArgumentException("The number is not ulong");
            }
        }

        public ulong UNumber
        {
            get
            {
                return this.uNumber;
            }
            set
            {
                this.uNumber = value;
            }
        }

        public IEnumerator<int> GetEnumerator()
        {
            for (int i = 63; i >= 0; i--)
            {
                yield return this[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public override bool Equals(object obj)
        {
            BitArray64 bitArray = obj as BitArray64;
            if (bitArray == null)
            {
                return false;
            }
            if (!Object.Equals(this.UNumber, bitArray.UNumber))
            {
                return false;
            }
            return true;
        }

        public override int GetHashCode()
        {
            return this.UNumber.GetHashCode();
        }

        public int this[int index]
        {
            get
            {
                if (index < 0 || index > 63)
                {
                    throw new ArgumentException();
                }
                return Convert.ToInt32((((ulong)1 << index) & this.UNumber) >> index);
            }
        }

        public static bool operator ==(BitArray64 firstNumber, BitArray64 secondNumebr)
        {
            return Object.Equals(firstNumber, secondNumebr);
        }

        public static bool operator !=(BitArray64 firstNumber, BitArray64 secondNumber)
        {
            return Object.Equals(firstNumber, secondNumber);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 63; i >= 0 ; i--)
            {
                sb.Append(this[i]);
            }
            return sb.ToString();
        }
    }
}

﻿using System;
using System.Linq;
using System.Text;

namespace StydentStystem
{
    class Student : ICloneable, IComparable<Student>
    {
        // fields
        private string firstName;
        private string middleName;
        private string lastName;
        private int ssn;
        private string address = null;
        private string phone;
        private string email;
        private byte course;
        private University universityName;
        private Faculty facultyName;
        private Specialty specialtyName;

        //constructors

        public Student(string firstName, string middleName, string lastName, int ssn, byte course) :
            this(firstName, middleName, lastName, ssn, null, null, null, course, University.SU, Faculty.Telecommunications, Specialty.Mechatronics)
        {
        }

        public Student(string firstName, string middleName, string lastName, int ssn, string address, string phone,
            string email, byte course, University universityName, Faculty facultyName, Specialty specialtyName)
        {
            this.firstName = firstName;
            this.middleName = middleName;
            this.lastName = lastName;
            this.ssn = ssn;
            this.address = address;
            this.phone = phone;
            this.email = email;
            this.course = course;
            this.universityName = universityName;
            this.facultyName = facultyName;
            this.specialtyName = specialtyName;
        }

        //Properties
        public string FirstName
        {
            get
            {
                return this.firstName;
            }
            set
            {
                this.firstName = value;
            }
        }

        public string MiddleName
        {
            get
            {
                return this.middleName;
            }
            set
            {
                this.middleName = value;
            }
        }

        public string LastName
        {
            get
            {
                return this.lastName;
            }
            set
            {
                this.lastName = value;
            }
        }

        public int Ssn
        {
            get
            {
                return this.ssn;
            }
            set
            {
                this.ssn = value;
            }
        }

        public string Address
        {
            get
            {
                return this.address;
            }
            set
            {
                this.address = value;
            }
        }

        public string Phone
        {
            get
            {
                return this.phone;
            }
            set
            {
                this.phone = value;
            }
        }

        public string Email
        {
            get
            {
                return this.email;
            }
            set
            {
                this.email = value;
            }
        }

        public byte Course
        {
            get
            {
                return this.course;
            }
            set
            {
                this.course = value;
            }
        }

        public University UniversityName
        {
            get
            {
                return this.universityName;
            }
            set
            {
                this.universityName = value;
            }
        }

        public Faculty FacultyName
        {
            get
            {
                return this.facultyName;
            }
            set
            {
                this.facultyName = value;
            }
        }

        public Specialty SpecialtyName
        {
            get
            {
                return this.specialtyName;
            }
            set
            {
                this.specialtyName = value;
            }
        }

        // Methods
        public override bool Equals(object obj)
        {
            Student student = obj as Student;

            if (student == null)
            {
                return false;
            }

            if (!Object.Equals(this.firstName, student.firstName) || !Object.Equals(this.middleName, student.middleName)
                || !Object.Equals(this.lastName, student.lastName))
            {
                return false;
            }

            if (!Object.Equals(this.ssn, student.ssn) || !Object.Equals(this.course, student.course))
            {
                return false;
            }

            return true;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Student with Names : {0}, {1}, {2}  SSN : {3} and Course : {4}",
                this.FirstName, this.MiddleName, this.LastName, this.Ssn, this.Course);

            return sb.ToString();
        }

        public override int GetHashCode()
        {
            return FirstName.GetHashCode() ^ MiddleName.GetHashCode() ^ LastName.GetHashCode() ^ Ssn.GetHashCode() ^ Course.GetHashCode();
        }

        public static bool operator ==(Student firstStudent, Student secondStudent)
        {
            return Student.Equals(firstStudent, secondStudent);
        }

        public static bool operator !=(Student firstStudent, Student secondStudent)
        {
            return !(Student.Equals(firstStudent, secondStudent));
        }

        public Student Clone()
        {
            return new Student(this.FirstName, this.MiddleName, this.LastName, this.Ssn, this.Address, this.Phone, this.Email,
                this.Course, this.UniversityName, this.FacultyName, this.SpecialtyName);
        }

        Object ICloneable.Clone()
        {
            return this.Clone();
        }

        public int CompareTo(Student student)
        {
            if (this.FirstName != student.FirstName)
            {
                return (this.FirstName.CompareTo(student.FirstName));
            }

            if (this.MiddleName != student.MiddleName)
            {
                return (this.MiddleName.CompareTo(student.MiddleName));
            }

            if (this.LastName != student.LastName)
            {
                return (this.LastName.CompareTo(student.LastName));
            }

            if (this.Ssn != student.Ssn)
            {
                return (this.Ssn.CompareTo(student.Ssn));
            }

            return 0;
        }
    }
}

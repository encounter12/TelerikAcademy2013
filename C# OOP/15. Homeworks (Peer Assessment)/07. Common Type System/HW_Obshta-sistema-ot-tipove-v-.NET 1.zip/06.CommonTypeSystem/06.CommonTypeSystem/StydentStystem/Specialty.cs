﻿using System;
using System.Linq;

namespace StydentStystem
{
    enum Specialty
    {
       Tourism, Mechatronics, IndustrialManagement,Physics
    }
}

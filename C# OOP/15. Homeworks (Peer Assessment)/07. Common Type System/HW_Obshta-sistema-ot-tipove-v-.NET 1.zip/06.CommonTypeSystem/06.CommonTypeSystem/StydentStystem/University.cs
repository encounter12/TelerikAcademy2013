﻿using System;
using System.Linq;

namespace StydentStystem
{
    enum University
    {
        Telerik,SU,TU,Unwe
    }
}

﻿using System;
using System.Linq;

namespace StydentStystem
{
    enum Faculty
    {
        Economics, Transport, Telecommunications, Automation
    }
}

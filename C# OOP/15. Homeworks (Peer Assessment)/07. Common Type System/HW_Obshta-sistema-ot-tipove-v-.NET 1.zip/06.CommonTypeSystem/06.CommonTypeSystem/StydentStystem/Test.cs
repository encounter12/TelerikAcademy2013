﻿using System;
using System.Linq;

namespace StydentStystem
{
    class Test
    {
        static void Main()
        {
            Student firstStudent = new Student("Ivancho", "Ivanchov", "Ivanov", 0232565, 4);
            Student secondStudent = new Student("Georgi", "Gogov", "Georgiev", 25689, "bull: Balgaria, number: 3", "+2598798665",
                "joro@joro.bg", 2, University.Telerik, Faculty.Telecommunications, Specialty.IndustrialManagement);
            Student thirdStudent = new Student("Petar", "Petrov", "Popov", 236586, 1);
            Student fourthStudent = new Student("Petar", "Petrov", "Popov", 21652, 1);
            Student cloneStudent = thirdStudent.Clone();

            Console.WriteLine(thirdStudent.Equals(cloneStudent));
            Console.WriteLine(thirdStudent.Equals(fourthStudent));

            Console.WriteLine(thirdStudent == cloneStudent);
            Console.WriteLine(thirdStudent == fourthStudent);
            Console.WriteLine(secondStudent != firstStudent);

            Console.WriteLine(thirdStudent.CompareTo(cloneStudent));
            Console.WriteLine(thirdStudent.CompareTo(fourthStudent));
            Console.WriteLine(firstStudent.CompareTo(cloneStudent));
        }
    }
}

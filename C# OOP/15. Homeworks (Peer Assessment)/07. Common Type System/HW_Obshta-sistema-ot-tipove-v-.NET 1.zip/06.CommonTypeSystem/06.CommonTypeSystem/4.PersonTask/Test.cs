﻿using System;
using System.Linq;

namespace _4.PersonTask
{
    class Test
    {
        static void Main()
        {
            Person firstPerson = new Person("Ivancho", 22);
            Person secondPerson = new Person("Ivanka");
            Person newPerson = new Person("Ivka", 0);
            // Person thirdPerson = new Person("", 22); throws Exceotion
            
            Console.WriteLine(firstPerson);
            Console.WriteLine(secondPerson);
            Console.WriteLine(newPerson);
            // Console.WriteLine(thirdPerson);
        }
    }
}

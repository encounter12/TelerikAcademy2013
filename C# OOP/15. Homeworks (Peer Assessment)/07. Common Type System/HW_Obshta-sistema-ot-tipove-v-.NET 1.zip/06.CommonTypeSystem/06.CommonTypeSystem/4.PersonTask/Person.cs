﻿using System;
using System.Linq;
using System.Text;

namespace _4.PersonTask
{
    class Person
    {
        private string name;
        private int? age;

        public Person(string name)
            : this(name, null)
        {
        }

        public Person(string name, int? age) 
        {
            if (name == null || name ==string.Empty)
            {
                throw new ArgumentNullException("You have to input a Name");
            }
            this.name = name;
            this.age = age;
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public int? Age
        {
            get
            {
                return this.age;
            }
            set
            {
                this.age = value;
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Person's name is : {0}", this.Name);
            sb.AppendLine();

            if (this.Age == null)
            {
                sb.AppendFormat("Person have not specified his/her age");
            }
            else
            {
                sb.AppendFormat("Person's age is : {0}", this.Age);
            }

            return sb.ToString();
        }
    }
}

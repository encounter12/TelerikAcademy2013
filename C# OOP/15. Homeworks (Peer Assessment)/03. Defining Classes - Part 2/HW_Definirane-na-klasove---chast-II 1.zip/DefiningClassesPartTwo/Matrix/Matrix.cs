﻿//Task 8 - Define a class Matrix<T> to hold a matrix of numbers (e.g. integers, floats, decimals). 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matrix
{
    public class Matrix<T>
    {
        private T[,] matrix;
        public Matrix(int rows, int cols)
        {
            this.matrix = new T[rows, cols];
        }

        //Task 9- Implement an indexer this[row, col] to access the inner matrix cells.

        public T this[int row, int col]
        {
            get
            {
                return this.matrix[row, col];
            }
            set
            {
                this.matrix[row, col] = value;
            }
        }
        public int GetRows()
        {
            return this.matrix.GetLength(0);
        }

        public int GetCols()
        {
            return this.matrix.GetLength(1);
        }
//Task 10- Implement the operators + and - (addition and subtraction of matrices 
//of the same size) and * for matrix multiplication. Throw an exception when the operation 
//cannot be performed. Implement the true operator (check for non-zero elements).
        public static Matrix<T> operator +(Matrix<T> matrixOne, Matrix<T> matrixTwo)
        {
            Matrix<T> result = new Matrix<T>(matrixOne.GetRows(), matrixOne.GetCols());
            if (matrixOne.GetRows() == matrixTwo.GetRows() && matrixOne.GetCols() == matrixTwo.GetCols())
            {
                for (int row = 0; row < matrixOne.GetRows(); row++)
                {
                    for (int col = 0; col < matrixOne.GetCols(); col++)
                    {
                        result[row, col] = (dynamic)matrixOne[row, col] + (dynamic)matrixTwo[row, col];
                    }
                }
            }
            else
            {
                throw new ArgumentOutOfRangeException("Matrixes should have equal dimensions.");
            }
            return result;
        }
        public static Matrix<T> operator -(Matrix<T> matrixOne, Matrix<T> matrixTwo)
        {
            Matrix<T> result = new Matrix<T>(matrixOne.GetRows(), matrixOne.GetCols());
            if (matrixOne.GetRows() == matrixTwo.GetRows() && matrixOne.GetCols() == matrixTwo.GetCols())
            {
                for (int row = 0; row < matrixOne.GetRows(); row++)
                {
                    for (int col = 0; col < matrixOne.GetCols(); col++)
                    {
                        result[row, col] = (dynamic)matrixOne[row, col] - (dynamic)matrixTwo[row, col];
                    }
                }
            }
            else
            {
                throw new ArgumentOutOfRangeException("Matrixes should have equal dimensions.");
            }
            return result;
        }
        public static Matrix<T> operator *(Matrix<T> first, Matrix<T> second)
        {
            Matrix<T> result = new Matrix<T>(first.GetRows(), second.GetCols());
            if (first.GetCols() == second.GetRows())
            {
                for (int row = 0; row < result.GetRows(); row++)
                {
                    for (int col = 0; col < result.GetCols(); col++)
                    {
                        for (int i = 0; i < first.GetCols(); i++)
                        {
                            result[row, col] += (dynamic)first[row, i] * (dynamic)second[i, col];
                        }
                    }
                }
            }
            else
            {
                throw new ArgumentOutOfRangeException("First matrix's col should be equal to second matrix's rows.");
            }
            return result;
        }
    }
}

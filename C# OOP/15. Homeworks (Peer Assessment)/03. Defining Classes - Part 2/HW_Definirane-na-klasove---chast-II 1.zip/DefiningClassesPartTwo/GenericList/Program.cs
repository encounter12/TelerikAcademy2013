﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Generics;

class Program
{
    static void Main()
    {
        GenericList<int> list = new GenericList<int>(12);
        list.Add(1);
    }
}

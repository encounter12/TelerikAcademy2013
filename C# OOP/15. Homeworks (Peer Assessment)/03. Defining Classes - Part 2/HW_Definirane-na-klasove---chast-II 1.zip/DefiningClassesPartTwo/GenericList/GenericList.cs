﻿//Task 5- Write a generic class GenericList<T> that keeps a list of elements of some parametric type T. 
//Keep the elements of the list in an array with fixed capacity which is given as parameter in the class constructor. 
//Implement methods for adding element, accessing element by index, removing element by index, inserting element 
//at given position, clearing the list, finding element by its value and ToString(). 
//Check all input parameters to avoid accessing elements at invalid positions.

using System;
using System.Linq;
using System.Text;

namespace Generics
{
    public class GenericList<T>
    {
        private T[] elements;
        private int count = 0;
        const int FixedCapacity = 1987;
        //constructors
        public GenericList()
            : this(FixedCapacity)
        {
        }

        public GenericList(int capacity)
        {
            elements = new T[capacity];
        }

        public void Add(T item)
        {
            Insert(count, item);
        }

        public T this[int index]
        {
            get
            {
                if (index >= count || index < 0)
                {
                    throw new IndexOutOfRangeException(String.Format(
                        "Invalid index: {0}.", index));
                }
                T result = elements[index];
                return result;
            }
        }
        public void Remove(int index)
        {
            if (index >= count || index < 0)
            {
                throw new IndexOutOfRangeException(String.Format(
                    "Invalid index: {0}.", index));
            }
            Array.Copy(elements, index + 1, elements, index, count - index + 1);
            elements[elements.Length - 1] = default(T);
            count--;
        }

        public void Insert(int index, T element)
        {
            if (index > count || index < 0)
            {
                throw new IndexOutOfRangeException(
                                      "Invalid index: " + index);
            }
            T[] extendedArr = Grow();
            Array.Copy(elements, index, extendedArr, index + 1, count - index - 1);
            extendedArr[index] = element;
            elements = extendedArr;
        }
        public void Clear()
        {
            elements = new T[FixedCapacity];
            count = 0;
        }
        public bool Contains(T element)
        {
            int index = Array.IndexOf(elements, element);
            bool found = (index != -1);
            return found;
        }
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            foreach (var element in elements)
            {
                result.Append(element + " ");
            }
            return result.ToString();
        }
        //Task 6 -Implement auto-grow functionality: when the internal array is full, create a new array of double size and move all elements to it.

        public T[] Grow()
        {
            T[] extendedArr = new T[this.elements.Length * 2];
            Array.Copy(elements, extendedArr, 0);
            count++;
            return extendedArr;
        }
        //Task 7 - Create generic methods Min<T>() and Max<T>() for finding the minimal and maximal element in the  GenericList<T>. 
        //You may need to add a generic constraints for the type T.
        public T Min()
        {
            if (this.elements.Length == 0)
            {
                throw new InvalidOperationException("Sequence contains no elements.");
            }

            if (this.elements.Length == 1)
            {
                return this.elements[0];
            }

            if (this.elements[0] is IComparable<T>)
            {
                T min = this.elements[0];

                for (int i = 1; i < this.elements.Length; i++)
                {
                    if ((min as IComparable<T>).CompareTo(this.elements[i]) > 0)
                    {
                        min = this.elements[i];
                    }
                }

                return min;
            }
            else
            {
                throw new ArgumentException("At least one object must implement IComparable.");
            }
        }
        public T Max()
        {
            if (this.elements.Length == 0)
            {
                throw new InvalidOperationException("Sequence contains no elements.");
            }

            if (this.elements.Length == 1)
            {
                return this.elements[0];
            }

            if (this.elements[0] is IComparable<T>)
            {
                T max = this.elements[0];

                for (int i = 1; i < this.elements.Length; i++)
                {
                    if ((max as IComparable<T>).CompareTo(this.elements[i]) < 0)
                    {
                        max = this.elements[i];
                    }
                }

                return max;
            }
            else
            {
                throw new ArgumentException("At least one object must implement IComparable.");
            }
        }
    }
}


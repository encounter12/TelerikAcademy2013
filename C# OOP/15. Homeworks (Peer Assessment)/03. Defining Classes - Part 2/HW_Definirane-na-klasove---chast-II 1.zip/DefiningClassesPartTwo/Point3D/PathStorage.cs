﻿//Task 4 - Create a class Path to hold a sequence of points in the 3D space. Create a static class PathStorage with 
//static methods to save and load paths from a text file. Use a file format of your choice.
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Point;

static class PathStorage
{
    public static void Save(Path path, string fileName)
    {
        using (StreamWriter file = new StreamWriter(fileName))
        {
            List<Point3D> sequenceOfPoints = path.SequenceOfPoints;

            file.WriteLine("{0}", sequenceOfPoints.Count);
            for (int i = 0; i < sequenceOfPoints.Count; i++)
            {
                file.WriteLine("{0} {1} {2}", sequenceOfPoints[i].X, sequenceOfPoints[i].Y, sequenceOfPoints[i].Z);
            }
        }
    }
    public static Path LoadPath(string fileName)
    {
        Path result = new Path();
        using (StreamReader file = new StreamReader(fileName))
        {
            int numberOfPointsInPath = int.Parse(file.ReadLine());
            for (int i = 0; i < numberOfPointsInPath; i++)
            {
                string line = file.ReadLine();
                string[] listCoord = (line.Split(' '));
                double x = double.Parse(listCoord[0]);
                double y = double.Parse(listCoord[1]);
                double z = double.Parse(listCoord[2]);
                Point3D point = new Point3D(x, y, z);
                result.SequenceOfPoints.Add(point);
            }
        }
        return result;
    }
}


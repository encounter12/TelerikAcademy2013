﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Point;
class Program
{
    static void Main(string[] args)
    {
        Point3D pointOne = new Point3D();
        pointOne.X= 1.2;
        pointOne.Y = 2.3;
        pointOne.Z = 3.4;
        string coordOne = pointOne.ToString();
        Console.WriteLine(coordOne);
        Point3D pointTwo = new Point3D();
        pointTwo.X = 4.5;
        pointTwo.Y = 5.6;
        pointTwo.Z = 6.7;
        string coordTwo = pointTwo.ToString();
        Console.WriteLine(coordTwo);
        double distance = DistanceBetweenTwoPointsIn3D.CalculateDistanceBetweenPoints(pointOne, pointTwo);
        Console.WriteLine("Distance between points is: {0}",distance);
    }
}
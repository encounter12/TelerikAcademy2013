﻿//Task 4 - Create a class Path to hold a sequence of points in the 3D space. Create a static class PathStorage with 
//static methods to save and load paths from a text file. Use a file format of your choice.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Point;

public class Path
{
    private List<Point3D> sequenceOfPoints;
    public List<Point3D> SequenceOfPoints
    {
        get
        {
            return this.sequenceOfPoints;
        }
    }
    public Path()
    {
        this.sequenceOfPoints = new List<Point3D>();
    }

}


﻿//Task 3 - Write a static class with a static method to calculate the distance between two points in the 3D space.
//Explanation and Formula : The distance between two points is the length of the path connecting them. 
//The shortest path distance is a straight line. In a 3 dimensional plane, the distance between points 
//(X1, X1, Z2) and (X2, X1, Z2) is given by: 
//d(X, Y) = \sqrt{(X2 - X1)^2 + (Y2 - Y1)^2+(Z2 - Z1)^2}.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Point;

public static class DistanceBetweenTwoPointsIn3D
{
    public static double CalculateDistanceBetweenPoints(Point3D firstPoint, Point3D secondPoint)
    {
        double deltaX = secondPoint.X - firstPoint.X;
        double deltaY = secondPoint.Y - firstPoint.Y;
        double deltaZ = secondPoint.Z - firstPoint.Z;
        double distance = Math.Sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
        return distance;
    }
}


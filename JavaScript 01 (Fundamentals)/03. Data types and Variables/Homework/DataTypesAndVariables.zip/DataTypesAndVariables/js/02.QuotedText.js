/*global jsConsole*/

var string = "'How you doin'?', Joey said.";
jsConsole.writeLine(string);
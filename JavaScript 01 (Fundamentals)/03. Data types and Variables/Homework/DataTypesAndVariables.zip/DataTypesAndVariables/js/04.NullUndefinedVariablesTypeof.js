﻿/*global jsConsole*/

var applesQuantity = null;
var pearsQuantity;

jsConsole.writeLine("applesQuantity = null, Type: " + typeof (applesQuantity));
jsConsole.writeLine("pearsQuantity = undefined, Type: " + typeof (pearsQuantity));
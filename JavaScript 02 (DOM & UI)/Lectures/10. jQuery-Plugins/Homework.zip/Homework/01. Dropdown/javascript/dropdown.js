jQuery(document).ready(function ($) {
    $('#dropdown').dropdown();
});
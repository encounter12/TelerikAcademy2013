jQuery(document).ready(function ($) {
    $('.message-box').messageBox();

    /* You can also try with other plugin settings */
    /*
    $('.message-box').messageBox({
        fadeInDuration: 500,
        visibilityDuration: 1000,
        fadeOutDuration: 500
    });
    */
});
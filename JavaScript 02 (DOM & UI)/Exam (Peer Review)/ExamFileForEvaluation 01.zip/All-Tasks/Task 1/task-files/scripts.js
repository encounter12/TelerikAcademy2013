function createImagesPreviewer(selector, items) {

    setStyle();

    var currentItem = '';

    var container = document.getElementById('container');

    var leftContainer = document.createElement('div');
    container.appendChild(leftContainer);
    leftContainer.id = 'left-container';

    var rightContainer = document.createElement('div');
    container.appendChild(rightContainer);
    rightContainer.id = 'right-container';

    var filter = document.createElement('input'),
        filterDiv = document.createElement('div');
    rightContainer.appendChild(filterDiv);
    filterDiv.appendChild(filter);
    setAttributes(filter, {
        'type': 'text',
        'id': 'filter',
        'value': ''
    });

    //input filter
    filter.addEventListener('change', filterItems());

    var imagesContainer = document.createElement('div');
    rightContainer.appendChild(imagesContainer);
    imagesContainer.id = 'images-container';


    onMainImageLoad();
    loadImagesInRightPreview();

    function onMainImageLoad() {
        var headMainImage = document.createElement('h1'),
            headText = document.createTextNode(items[0].title);

        leftContainer.appendChild(headMainImage);
        headMainImage.appendChild(headText);
        headMainImage.setAttribute('id', 'head-main-text');

        var img = document.createElement('img');
        setAttributes(img, {
            'src': items[0].url,
            'id': 'main-image'
        });

        leftContainer.appendChild(img);
    }


    //this function sets stylesheet
    //Plese, insert selectors and values as new members of array
    function setStyle() {
        var css = [
            {
                '#container':

                {
                    'width': '560px',
                    'height': '400px',
                }
            },
            {
                '#left-container':
                {
                    'width': '390px',
                    'height': '250px',
                    'float': 'left',
                }
            },
            {
                '#right-container':
                    {
                        'width': '160px',
                        'height': '250px',
                        'float': 'right',
                    }
            },
            {
                '#main-image':
                    {
                        'width': '370px',
                        'height': '250px'
                    }
            },
            {
                '.image-preview':
                    {
                        'width': '120px',
                        'height': '70px',
                        'margin-left': '10px',
                        'margin-right': '10px',
                        'border': '1px solid #',
                        '-webkit-border-radius': '5px;',
                        '-moz-border-radius': '5px',
                        'border-radius': '5px'
                    }
            },
            {
                '#images-container':
                    {
                        'height': '300px',
                        'overflow-y': 'scroll'
                    }
            },
            {
                '#head-main-text':
                    {
                        'text-align': 'center',
                        'margin': 'auto'
                    }
            },
            {
                '.preview-text':
                    {
                        'text-align': 'center',
                        'margin': 'auto',

                    }
            },
            {
                '.img-container:hover':
                    {
                        'background-color': 'grey'
                    }
            },
            {
                'img, div':
                    {
                        'border': '1px solid #',
                        '-webkit-border-radius': '10px;',
                        '-moz-border-radius': '10px',
                        'border-radius': '10px'
                    }
            },
            {
                'input':
                    {
                        'border': '1px solid #',
                        '-webkit-border-radius': '3px;',
                        '-moz-border-radius': '3px',
                        'border-radius': '3px'
                    }
            }
        ];


        var head = document.head || document.getElementsByTagName('head')[0],
        style = document.createElement('style');
        style.type = 'text/css';
        var cssSelector = '';

        for (var i = 0, len = css.length; i < len; i++) {

            var keys = Object.keys(css[i]);
            cssSelector = cssSelector + keys.toString() + '{';

            for (var key in css[i][keys]) {
                cssSelector = cssSelector + key + ':' + css[i][keys][key].toString() + ';';
            }

            cssSelector = cssSelector + '}' + ' ';
        }

        if (style.styleSheet) {
            style.styleSheet.cssText = cssSelector;
        } else {
            style.appendChild(document.createTextNode(cssSelector));
        }

        head.appendChild(style);
    }

    function setAttributes(el, attrs) {
        for (var key in attrs) {
            el.setAttribute(key, attrs[key]);
        }
    }

    function loadImagesInRightPreview() {

        for (var i = 0; i < items.length; i++) {
            var imgContainer = document.createElement('div'),
                imgContainerHeader = document.createElement('h4'),
                imgText = document.createTextNode(items[i].title);
            imgContainer.appendChild(imgContainerHeader);
            imgContainerHeader.appendChild(imgText);
            imgContainerHeader.setAttribute('class', 'preview-text');

            var img = document.createElement('img');
            setAttributes(img, {
                'src': items[i].url,
                'class': 'image-preview',
                'title': items[i].title
            });

            imgContainer.setAttribute('class', 'img-container');
            img.addEventListener('click', onLoadMainImageClick);
            imgContainer.appendChild(img);
            imagesContainer.appendChild(imgContainer);

        }
    }

    function onLoadMainImageClick() {
        var currentText = document.getElementById('head-main-text');
        currentText.innerHTML = this.getAttribute('title')
        var currentImg = document.getElementById('main-image');
        setAttributes(currentImg, {
            'src': this.getAttribute('src')
        });
    }

    function filterItems() {
        var filterContent = document.getElementById('filter');
        var valContent = filterContent.value;
        console.log(valContent);
    }
}


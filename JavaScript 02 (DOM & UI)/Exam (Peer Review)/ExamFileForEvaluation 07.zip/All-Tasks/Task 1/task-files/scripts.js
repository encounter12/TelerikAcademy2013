function createImagesPreviewer(selector, animals) {
    var container = document.querySelector(selector);
    var imgContainer = document.createElement('div');
    var imgTitle = document.createElement('h1');
    var imgPath = document.createElement('a');

    var ANIMALS_COUNT = 12;

    //styles
    imgContainer.style.width = (animals.availWidth) + 'px';

    imgContainer.style.display = 'inline-block';
    imgContainer.style.margin = '0';
    imgContainer.style.padding = '0';
    imgContainer.style.border = '1px solid purple';

    imgTitle.style.display = 'block';
    imgTitle.style.textAlign = 'center';

    imgTitle.className = 'day-title';
    imgPath.className = 'day-content';

    img-container.appendChild(imgTitle);
    img-container.appendChild(imgPath);
}
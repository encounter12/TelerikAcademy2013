(function ($) {
    $.fn.gallery = function (size) {
        size = parseInt(size);
        var $galleryControl = this;
        $galleryControl.addClass('gallery');
        $galleryControl.css('width', (size*260) + 'px');

        var $gallery = $('.gallery');
        $gallery.addClass('blurred');

        $galleryControl.find('.selected').children().remove();

        $galleryControl.on('click', '.current-image', function () {
            var $clickedImage = $(this);
            hideEnlargedImages($clickedImage)
        });

        $galleryControl.on('click', '.image-container', function () {
            var $clickedImage = $(this);
            console.log($clickedImage);
            showEnlargedImages($clickedImage);

        });

        $galleryControl.on('click', '.previous-image', function () {
            var $clickedImage = $(this);
            changeEnlargedImageToPrev($clickedImage)
        });

        $galleryControl.on('click', '.next-image', function () {
            var $clickedImage = $(this);
            changeEnlargedImageToNext($clickedImage)
        });

        function hideEnlargedImages($clickedImage) {
            console.log('hide enlarged images');
            //$clickedImage.siblings().remove();
            //$clickedImage.remove('.current-image');

            $('.gallery-list').append($clickedImage.siblings().removeClass('next-image').removeClass('previous-image').addClass('image-container'));
            $('.gallery-list').append($clickedImage.removeClass('current-image').addClass('image-container'));
        }

        function showEnlargedImages($clickedImage){
            console.log('show enlarged images');

            $('.selected').append($clickedImage.next().removeClass('image-container').addClass('next-image'));
            $('.selected').append($clickedImage.prev().removeClass('image-container').addClass('previous-image'));
            $('.selected').append($clickedImage.removeClass('image-container').addClass('current-image'));
            //TODO: blurred
            //TODO: to append, but not to remove from gallery-list
        }

        function changeEnlargedImageToPrev($clickedImage){
            console.log('change to prev');

            $clickedImage.next().removeClass('current-image').addClass('next-image');
            $clickedImage.removeClass('previous-image').addClass('current-image');
            //TODO: prev img
        }

        function changeEnlargedImageToNext($clickedImage){
            console.log('change to next');

            //TODO: next img
            $clickedImage.next().removeClass('current-image').addClass('previous-image');
            $clickedImage.removeClass('next-image').addClass('current-image');

        }
    };
}(jQuery));

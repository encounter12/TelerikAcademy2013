function createImagesPreviewer(selector, items) {
    var previewer = document.querySelector(selector);
    var animals = items;
    var thumbnails = document.createElement('div');
    var thumb = document.createElement('img');
    var thumbTitle = document.createElement('h4');
    var window = document.createElement('div');
    var picture = document.createElement('img');
    var filterBox = document.createElement('input');
    var filterLabel = document.createElement('label');

    applyPictureStyle(picture);

    function applyPictureStyle(picture) {
        picture.src = animals[0].url;
        picture.name = animals[0].title;
        picture.style.width = '600px';
        picture.style.height = '400px';
        picture.style.border = '1px solid lightgray';
        picture.style.borderRadius = '10px';
    }

    applyThumbStyle(thumb);

    function applyThumbStyle(thumb) {
        thumb.style.display = 'block';
        thumb.style.width = '200px';
        thumb.style.height = '150px';
        thumb.style.border = '1px solid lightgray';
        thumb.style.borderRadius = '10px';
        return thumb;
    }

    applyViewWindowStyle(window);

    function applyViewWindowStyle(window) {
        window.style.display = 'inline-block';
        window.style.cssFloat = 'left';
        window.style.width = '600px';
        window.style.height = '400px';
    }

    applyTumbnailsStyle(thumbnails);

    function applyTumbnailsStyle(thumbnails) {
        thumbnails.style.display = 'inline-block';
        thumbnails.style.cssFloat = 'left';
        thumbnails.style.width = '200px';
        thumbnails.style.height = '500px';
        thumbnails.style.paddingLeft = '650px';
    }

    applyFilterBoxStyle(filterBox);

    function applyFilterBoxStyle(filterBox) {
        filterLabel.htmlFor = 'filter';
        filterLabel.innerHTML = 'Filter';
        filterLabel.style.fontSize = '16px';
        filterLabel.style.display = 'block';
        filterLabel.style.textAlign = 'center';
        filterBox.style.display = 'block';
        filterBox.name = 'filter';
        filterBox.style.width = '200px';
    }

    var fragment = document.createDocumentFragment();

    fragment.appendChild(generateViewWindow());
    fragment.appendChild(generateThumbnails());

    previewer.appendChild(fragment);

    function generateViewWindow() {
        var windowTitle = document.createElement('h1');
        windowTitle.innerText = picture.name;
        windowTitle.style.textAlign = 'center';
        var viewWindow = window.cloneNode(true);
        viewWindow.appendChild(windowTitle);
        viewWindow.appendChild(picture);
        viewWindow.style.position = 'fixed';
        return viewWindow;
    }

    function generateThumbnails() {
        thumbnails.appendChild(filterLabel);
        thumbnails.appendChild(filterBox);
        for (var i = 0; i < animals.length; i++) {
            thumbnails.appendChild(generateThumbTitle(i));
            thumbnails.appendChild(generateThumb(i));
        }
        return thumbnails;
    }

    function generateThumb(id) {
        var currentThumb = thumb.cloneNode(true);
        currentThumb.src = animals[id].url;
        currentThumb.name = animals[id].title;
        return currentThumb;
    }

    function generateThumbTitle(id) {
        var currentThumbTitle = thumbTitle.cloneNode(true);
        currentThumbTitle.innerText = animals[id].title;
        applyThumbTitleStyle(currentThumbTitle);
        return currentThumbTitle;
    }

    function applyThumbTitleStyle(thumbTitle) {
        thumbTitle.style.textAlign = 'center';
        thumbTitle.style.marginBottom = '0';
        return thumbTitle;
    }

    

    // previewer.addEventListener("click", clickPicture(), false);
    // previewer.addEventListener("mouseover", hoverPicture(), false);
    // previewer.addEventListener("mouseout", unhoverPicture(), false);

    //function clickPicture() {
    //    picture.name = this.name;
    //    picture.src = this.src;
    //    windowTitle.innerText = picture.name;
    //    return picture;
    //}

    //function hoverPicture() {
    //    this.style.background = 'gray';
    //}

    //function unhoverPicture() {
    //    this.style.background = 'white';
    //}

    // I wish I could make these work! :(((

}
﻿var svgNS = 'http://www.w3.org/2000/svg';
var svg = document.createElementNS(svgNS, 'svg');
svg.setAttribute('width', '1200');
svg.setAttribute('height', '1200');
document.body.appendChild(svg);

var rectWidth = 250;
var rectHeight = 120;
var startX = 100;
var startY = 160;
var gap = 10;
var twoRectsInOne = false;
var colors = ['#8bef1a', '#ff0048', '#0096ff', '#7200ff', 'orange', 'yellow'];
var colorsCount = colors.length;
var rows = 3;
var cols = 3;

function drawGroupOfRects(rows, cols) {

    for (var i = 0; i < cols; i++) {
        for (var j = 0; j < rows; j++) {

            if (j == 0 && i == 1) {
                twoRectsInOne = true;
            }
            else {
                twoRectsInOne = false;
            }

            if (twoRectsInOne) {
                var halfWidth = rectWidth / 2 - gap / 2;
                createRectangle(startX, startY, halfWidth, rectHeight, colors[Math.floor(Math.random() * colorsCount)]);
                createRectangle(startX + halfWidth + gap, startY, halfWidth, rectHeight, colors[Math.floor(Math.random() * colorsCount)]);
            }
            else {
                createRectangle(startX, startY, rectWidth, rectHeight, colors[Math.floor(Math.random() * colorsCount)]);
            }
            startY += rectHeight + gap;
        }
        startX += rectWidth + gap;
        startY -= rows * (rectHeight + gap);
    }
}

function createRectangle(x, y, w, h, fill) {
    var rectangle = document.createElementNS(svgNS, 'rect');
    rectangle.setAttribute('x', x);
    rectangle.setAttribute('y', y);
    rectangle.setAttribute('width', w);
    rectangle.setAttribute('height', h);
    rectangle.setAttribute('stroke', 'none');
    rectangle.setAttribute('fill', fill);

    svg.appendChild(rectangle);
}

function writeTextOnThePage(x, y, fontSize, color, innerText, fontFamily) {
    var text = document.createElementNS(svgNS, 'text');
    text.setAttribute('x', x);
    text.setAttribute('y', y);
    text.setAttribute('font-size', fontSize);
    text.setAttribute('fill', color);
    text.setAttribute('font-family', fontFamily),
    text.innerHTML = innerText;
    svg.appendChild(text);

}

function createCircle(x, y, r, fillColor, strokeColor,strokeWidth) {
    var circle = document.createElementNS(svgNS, 'circle');
    circle.setAttribute('cx', x);
    circle.setAttribute('cy', y);
    circle.setAttribute('r', r);
    circle.setAttribute('stroke', strokeColor);
    circle.setAttribute('stroke-width', strokeWidth);
    circle.setAttribute('fill', fillColor);
    svg.appendChild(circle);
}

function drawPath(fillColor, strokeColor, d, strokeWidth) {
    var leftCurve = document.createElementNS(svgNS, 'path');
    leftCurve.setAttribute('d', d);
    leftCurve.setAttribute('fill', fillColor);
    leftCurve.setAttribute('stroke', strokeColor);
    leftCurve.setAttribute('stroke-width', strokeWidth);
    leftCurve.setAttribute('stroke-linecap', 'round');
    svg.appendChild(leftCurve);
}

function attachImage(x, y, w, h, link) {
    var img = document.createElementNS(svgNS, 'image');
    img.setAttribute('x', x);
    img.setAttribute('y', y);
    img.setAttribute('width', w);
    img.setAttribute('height', h);
    img.setAttributeNS("http://www.w3.org/1999/xlink", "href", "IMG_8068.png");
    svg.appendChild(img);
}

//create the desktop 
//-background
createRectangle(0, 0, 1200, 1200, "#222");
//-all rectangle componentsof the menu
drawGroupOfRects(rows, cols);
startX += 30;
drawGroupOfRects(3, 1);

writeTextOnThePage(100, 100, "50", "white", "Start", "Arial");
writeTextOnThePage(850, 90, "40", "white", "User", "Arial");
//user picture rectangle
createRectangle(950, 50, 50, 50, "#333");

//add icons
//-shutdown icon
createCircle(1020, 75, 10, 'none', 'white')
createRectangle(1016, 64, 8, 4, '#222');
drawPath('none', 'white', "M 1020 60 L 1020 70", 2);

//-search icon
createCircle(1070, 70, 5, '#222', 'white', 2);
drawPath('none', 'white', 'M 1064 76 L 1055 85', 3);

// -mail icon
createRectangle(100, 160, 250, 120, '#8bef1a');
createRectangle(190, 200, 70, 40, 'white');
drawPath('none', '#8bef1a', 'M190 200 L 225 220 L260 200', 4);
writeTextOnThePage(110, 270, 12, 'white', 'Mail', 'Arial');

//-travel icon
createRectangle(180, 460, 20, 40, 'white');
createRectangle(205, 460, 30, 40, 'white');
createRectangle(240, 460, 20, 40, 'white');
drawPath('none', 'white', 'M207 460 C205 445 235 445 233 460', 3);
writeTextOnThePage(110, 530, 12, 'white', 'Travel', 'Arial');

//-desctop
attachImage(360, 290, 250, 120, 'IMG_8068.png');

//-weather
createCircle(780, 480, 10, 'white', 'white', 1);
createCircle(760, 470, 20, 'white', 'white', 1);
createCircle(740, 475, 15, 'white', 'white', 1);
createCircle(745, 500, 5, 'white', 'white', 1);
createRectangle(739, 465, 40, 25, 'white');
createCircle(745, 500, 5, 'white', 'white', 1);
createCircle(760, 500, 5, 'white', 'white', 1);
createCircle(775, 500, 5, 'white', 'white', 1);
writeTextOnThePage(640, 530, 12, 'white', 'Wheater', 'Arial');

//-clock
createCircle(1045, 215, 40, 'none','white', 3);
drawPath('none', 'white', 'M1045 215 L1050 235 M1045 215 L1075 215', 5);
writeTextOnThePage(920, 275, 12, 'white', 'World clock', 'Arial');


var items = [
    new Item(1, 'One'),
    new Item(2, 'Two'),
    new Item(3, 'Three'),
    new Item(4, 'Four'),
    new Item(5, 'Five'),
    new Item(6, 'Six')
];

function Item(value, text) {
    return {
        value: value,
        text: text
    }
}

window.onload = function () {
    var listTemplate = $('#list-template').html();
    var template = Handlebars.compile(listTemplate);
    var endHtml = template({items: items});

    $('#container').html(endHtml);
};

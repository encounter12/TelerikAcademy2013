﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace JsonExample
{
    class JsonTest
    {
        static void Main(string[] args)
        {
            string url = "http://forums.academy.telerik.com/feed/qa.rss";
            WebClient webClient = new WebClient();

            string result = webClient.DownloadString(url);

            XDocument document = XDocument.Parse(result);

            string json = JsonConvert.SerializeXNode(document, Newtonsoft.Json.Formatting.Indented);

            JObject jsonObj = JObject.Parse(json);

            var allItems = jsonObj["rss"]["channel"]["item"];

            foreach (var item in allItems)
            {
                Console.WriteLine(item["title"]);
            }

            /*
                var titles = jsonObj["rss"]["channel"]["item"].Select(i => i["title"]);
                Console.WriteLine(string.Join(Environment.NewLine, titles));
             */

            var itemsJson = jsonObj["rss"]["channel"]["item"].ToString();
            var items = JsonConvert.DeserializeObject<Item[]>(itemsJson);


        }
    }
}

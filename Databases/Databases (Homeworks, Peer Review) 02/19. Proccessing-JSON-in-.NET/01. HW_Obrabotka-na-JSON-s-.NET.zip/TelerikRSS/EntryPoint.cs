﻿namespace TelerikRSS
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Xml.Linq;
    using Models;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;

    public class EntryPoint
    {
        // Not really a HQC but I think it is understandable
        // Note: All generated content goes to Data folder
        public static void Main()
        {
            string rssFeedPath = @"..\..\Data\telerikRss.xml";

            // Task 2
            WebClient webClient = new WebClient();
            webClient.DownloadFile("http://forums.academy.telerik.com/feed/qa.rss", rssFeedPath);

            // Task 3
            XDocument rssFeed = XDocument.Load(rssFeedPath);
            string json = JsonConvert.SerializeXNode(rssFeed);

            // Task 4
            var jsonObj = JObject.Parse(json);
            foreach (var item in jsonObj["rss"]["channel"]["item"])
            {
                Console.WriteLine("{0}\n", item["title"]);
            }

            // Task 5
            // Note that Question class doesn't have description holder
            // Basically, I followed Doncho's instructions
            // Check latest JSON.NET lecture at 1:28:41 if you're sceptical
            var questions = JObject.Parse(json)
                .SelectToken("rss")
                .SelectToken("channel")
                .SelectToken("item")
                .ToObject<IEnumerable<Question>>();

            // Task 6
            JSONModelsToHTML(questions);
        }

        private static void JSONModelsToHTML(IEnumerable<Question> questions)
        {
            StringBuilder htmlQuestions = new StringBuilder();
            string htmlBeginning = "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"/><title>Telerik RSS Feed</title></head><body><ul>";
            string htmlEnd = "</ul></body></html>";

            htmlQuestions.Append(htmlBeginning);

            foreach (Question question in questions)
            {
                htmlQuestions
                    .Append("<li style=\"border:1px solid #777\">")
                    .Append("<a href=\"").Append(question.Link).Append("\" target=\"_blank\">").Append(question.Title).Append("</a>")
                    .Append("<p>Category: ").Append(question.Category).Append("</p>")
                    .Append("</li>");
            }

            htmlQuestions.Append(htmlEnd);

            File.WriteAllText(@"..\..\Data\feed.html", htmlQuestions.ToString());
        }
    }
}

USE NewDB2
GO

CREATE PROC usp_Person_Interest (@acc_id int, @rate real)
AS
DECLARE @temp real, @result real
SET @temp = (SELECT a.Balance 
			FROM People e
				JOIN  Accounts a
				ON e.Id = a.PersonId
			WHERE e.Id= @acc_id)
EXEC fn_SUM @temp, @rate, 1, @result OUTPUT
RETURN @result

GO

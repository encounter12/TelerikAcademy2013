USE NewDB2
CREATE TABLE [dbo].[People](
Id int NOT NULL IDENTITY,
FirstName nvarchar(20),
LastName nvarchar(20) NOT NULL,
SSN int UNIQUE,
CONSTRAINT PK_People PRIMARY KEY (Id) 
)
GO

CREATE TABLE [dbo].[Accounts](
Id int NOT NULL IDENTITY,
PersonId int,
Balance money,
CONSTRAINT PK_Accounts PRIMARY KEY(Id),
CONSTRAINT FK_Accounts_People FOREIGN KEY(PersonId) REFERENCES People(Id)
)
GO

INSERT INTO People (FirstName, LastName, SSN)
VALUES('Ivan', 'Ivanov', 583583)

INSERT INTO People (FirstName, LastName, SSN)
VALUES('Aneta', 'Ruseva', 182583)

INSERT INTO People (FirstName, LastName, SSN)
VALUES('Elena', 'Ivanova', 590511)

GO

INSERT INTO Accounts(PersonId, Balance)
VALUES (2, 300)

INSERT INTO Accounts(PersonId, Balance)
VALUES (1, 1300)

INSERT INTO Accounts(PersonId, Balance)
VALUES (3, 500)

GO

CREATE PROC usp_FullName
AS
SELECT FirstName+' '+ LastName AS FullName
FROM People
GO
USE NewDB2
GO

CREATE PROC Check_Sum (@sum real)	
AS
SELECT e.FirstName+' '+ e.LastName AS FullName, b.Balance
FROM People e
	INNER JOIN Accounts b
	ON e.Id = b.PersonId
	WHERE b.Balance > @sum
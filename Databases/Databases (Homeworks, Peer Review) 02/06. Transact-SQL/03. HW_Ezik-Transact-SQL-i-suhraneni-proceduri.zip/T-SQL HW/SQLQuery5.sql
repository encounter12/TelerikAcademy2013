USE NewDB2
GO

CREATE PROC usp_WithdrawMoney( @acc_id int,@sum money)
AS
DECLARE @new real
SET @new =(SELECT a.Balance 
			FROM People e
				INNER JOIN  Accounts a
				ON e.Id = a.PersonId
			WHERE e.Id= @acc_id)
UPDATE Accounts
SET Balance = @new -@sum
WHERE PersonId = @acc_id
GO

CREATE PROC usp_DepositMoney( @acc_id int,@sum money)
AS
DECLARE @new real
SET @new =(SELECT a.Balance 
			FROM People e
				INNER JOIN  Accounts a
				ON e.Id = a.PersonId
			WHERE e.Id= @acc_id)
UPDATE Accounts
SET Balance = @new +@sum
WHERE PersonId = @acc_id
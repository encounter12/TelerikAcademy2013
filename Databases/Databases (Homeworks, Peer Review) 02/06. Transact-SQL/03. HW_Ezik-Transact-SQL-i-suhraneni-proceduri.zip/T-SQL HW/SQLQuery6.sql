CREATE TABLE Logs(
LogID int IDENTITY NOT NULL,
AccountId int,
OldSum real,
NewSum real,
CONSTRAINT PK_Logs PRIMARY KEY(LogID),
CONSTRAINT FK_Logs_Accounts FOREIGN KEY (AccountId) REFERENCES Accounts(Id)
)
GO

CREATE TRIGGER tr_AccountsUpdate ON dbo.Accounts FOR UPDATE
AS
DECLARE @acc_id int,@sum real, @new_sum real
SET @acc_id=(SELECT Id	FROM inserted)
SET @sum=(SELECT Balance FROM deleted)
SET @new_sum=( SELECT Balance FROM inserted)
INSERT INTO Logs( AccountId, OldSum,NewSum)
VALUES(@acc_id, @sum, @new_sum)

GO
DECLARE town_COURSOR READ_ONLY FOR
SELECT e.LastName, t.Name AS Town
FROM Employees e
	INNER JOIN Addresses a
	ON e.AddressID= a.AddressID
	INNER JOIN Towns t
	ON 	a.TownID=t.TownID

OPEN town_COURSOR
DECLARE @town char(50)
FETCH NEXT FROM town_COURSOR INTO @town

WHILE @@FETCH_STATUS = 0
  BEGIN
    PRINT  @town
    FETCH NEXT FROM town_COURSOR 
    INTO  @town
  END

CLOSE town_COURSOR
DEALLOCATE town_COURSOR

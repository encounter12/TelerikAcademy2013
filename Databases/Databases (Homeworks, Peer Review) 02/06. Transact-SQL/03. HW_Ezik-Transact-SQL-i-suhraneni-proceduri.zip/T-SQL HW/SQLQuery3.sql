CREATE FUNCTION fn_SUM (@Sum real, @YearInterestRate real,@months int) 
RETURNS real
AS
BEGIN
DECLARE @new_sum real
SELECT @new_sum= (@Sum*@YearInterestRate/100)*@months/12
RETURN @new_sum
END

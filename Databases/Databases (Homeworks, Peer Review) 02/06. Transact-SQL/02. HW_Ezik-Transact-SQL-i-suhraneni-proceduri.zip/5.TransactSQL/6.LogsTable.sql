/* 6. Create another table � Logs(LogID, AccountID, OldSum, NewSum). 
Add a trigger to the Accounts table that enters a new entry into the Logs table 
every time the sum on an account changes.*/
USE TelerikAcademy
GO

CREATE TABLE Logs
(
	LogId int
	PRIMARY KEY CLUSTERED
	IDENTITY(1, 1),
	AccountId int
	FOREIGN KEY REFERENCES Accounts(AccountId),
	OldSum money,
	NewSum money
)
GO

CREATE TRIGGER LogTransaction ON Accounts AFTER UPDATE
AS
	IF EXISTS(SELECT * FROM DELETED)
	BEGIN

	DECLARE @personId int, @balanceBefore money, @balanceAfter money
	SELECT @personId = del.AccountId, @balanceBefore = del.Balance FROM deleted del
	SELECT @balanceAfter = ins.Balance FROM inserted ins

	INSERT INTO Logs
	VALUES (@personId, @balanceBefore, @balanceAfter)
END

EXEC uspWithdrawMoney 1, 100
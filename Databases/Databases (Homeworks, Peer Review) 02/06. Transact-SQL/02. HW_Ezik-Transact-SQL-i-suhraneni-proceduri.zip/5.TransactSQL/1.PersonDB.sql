USE TelerikAcademy

/* 1.Create a database with two tables: Persons(Id(PK), FirstName, LastName, SSN) and Accounts(Id(PK), PersonId(FK), Balance). 
Insert few records for testing. Write a stored procedure that selects the full names of all persons.*/
CREATE TABLE Persons (
        PersonID INT IDENTITY,
        FirstName NVARCHAR(50),
        LastName NVARCHAR(50),
        SSN NVARCHAR(50)
        CONSTRAINT PK_PersonsID PRIMARY KEY(PersonID)
)


CREATE TABLE Accounts (
        AccountID INT IDENTITY,
        PersonID INT,
        Balance money
        CONSTRAINT PK_AccountID PRIMARY KEY(AccountID)
        CONSTRAINT FK_PersonID FOREIGN KEY(PersonID)
                REFERENCES Persons(PersonID)
)


INSERT INTO Persons(FirstName, LastName, SSN) VALUES ('Pesho1', 'Ivanov1', 123546789)
INSERT INTO Persons(FirstName, LastName, SSN) VALUES ('Pesho2', 'Ivanov2', 223546789)
INSERT INTO Persons(FirstName, LastName, SSN) VALUES ('Pesho3', 'Ivanov3', 323546789)

INSERT INTO Accounts(Balance, PersonId) VALUES (1000, 2)
INSERT INTO Accounts(Balance, PersonId) VALUES (2000, 3)
INSERT INTO Accounts(Balance, PersonId) VALUES (50, 1)
GO

CREATE PROC usp_SelectFullNames
AS
	SELECT FirstName + ' ' + LastName AS FullName FROM Persons
GO

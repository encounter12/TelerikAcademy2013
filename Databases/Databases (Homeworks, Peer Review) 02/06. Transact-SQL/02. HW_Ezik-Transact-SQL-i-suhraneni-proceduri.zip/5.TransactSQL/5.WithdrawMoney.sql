/*5. Add two more stored procedures WithdrawMoney( AccountId, money) and DepositMoney (AccountId, money) that operate in transactions.
*/
USE TelerikAcademy
GO

CREATE PROCEDURE uspWithdrawMoney @accountId int, @money money
AS
BEGIN
UPDATE Accounts SET Balance -= @money WHERE AccountId = @accountId
END
GO

CREATE PROCEDURE uspDepositMoney @accountId int, @money money
AS
BEGIN
UPDATE Accounts SET Balance += @money WHERE AccountId = @accountId
END
GO


EXEC uspWithdrawMoney @accountId = 1, @money = 100
EXEC uspDepositMoney @accountId = 1, @money = 100
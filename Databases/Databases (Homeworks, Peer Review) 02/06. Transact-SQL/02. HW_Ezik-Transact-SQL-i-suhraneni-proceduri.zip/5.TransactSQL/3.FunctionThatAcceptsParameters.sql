/* 3.Create a function that accepts as parameters � sum, yearly interest rate and number of months. 
It should calculate and return the new sum. 
Write a SELECT to test whether the function works as expected.*/
USE TelerikAcademy
GO

CREATE FUNCTION ufn_CalcInterest(@sum money, @yearlyInterest NUMERIC(20, 2), @monthsCount INT)
  RETURNS NUMERIC(18, 2)
AS
BEGIN
  RETURN (@sum + (@monthsCount/12)*((@yearlyInterest*@sum)/100))
END
GO

SELECT dbo.ufn_CalcInterest(200, 0.2, 5)
GO

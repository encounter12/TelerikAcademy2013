/*10. Define a .NET aggregate function StrConcat that takes as input a sequence of strings and return a single string that consists of the input strings separated by ','. For example the following SQL statement should return a single string:
		SELECT StrConcat(FirstName + ' ' + LastName)
		FROM Employees*/

USE [TelerikAcademy]
GO

sp_configure 'clr enabled', 1
GO
RECONFIGURE
GO

-- Compile the solution in CLRFunctions
-- Go to TelerikAcademy -> Programmability -> Assemblies
-- Right click Assemblies -> New Assembly
-- Browse path to StringConcat\StringConcat\bin\Debug and choose the DLL file there
-- this path is in my homework directory, after this is done - proceed with the next batch

CREATE AGGREGATE STRCONCAT (@input nvarchar(200))
RETURNS nvarchar(max)
EXTERNAL NAME StringConcat.Concatenate;
GO

SELECT dbo.STRCONCAT(FirstName + ' ' + LastName) FROM Employees
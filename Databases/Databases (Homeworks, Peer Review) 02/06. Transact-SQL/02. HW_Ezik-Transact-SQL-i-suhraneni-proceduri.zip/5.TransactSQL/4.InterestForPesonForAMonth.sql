/* 4.Create a stored procedure that uses the function from the previous example to give an interest 
to a person's account for one month. It should take the AccountId and the interest rate as parameters.*/
USE TelerikAcademy
GO

CREATE PROC usp_UpdatePersonsBalance(@AccountID int, @interestRate int)
AS
BEGIN
DECLARE @sum money
SET @sum = (SELECT Balance 
			FROM Accounts
			WHERE AccountID = CAST(AccountID AS int))

DECLARE @updatedSum money
SET @updatedSum = dbo.ufn_CalcInterest(@sum, @interestRate, 1)

UPDATE Accounts SET Balance = CAST(@updatedSum AS money) WHERE AccountID = CAST(@AccountID AS int)

END
GO
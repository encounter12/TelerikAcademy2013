/* 8. Using database cursor write a T-SQL script that scans all employees and their 
addresses and prints all pairs of employees that live in the same town.*/
USE TelerikAcademy
GO

CREATE PROCEDURE uspEmployeesInTown @results CURSOR VARYING OUTPUT
AS
BEGIN

	SET @results = CURSOR FOR

	SELECT emp.LastName, towns.Name FROM Employees emp
	JOIN Addresses addr
	ON emp.AddressID = addr.AddressID
	JOIN Towns towns
	ON addr.TownID = towns.TownID
	GROUP BY towns.TownID, towns.Name, emp.LastName

	OPEN @results
END

GO

DECLARE @employeesInTowns CURSOR
DECLARE @LastName varchar(20), @TownName varchar(20)

EXEC uspEmployeesInTown @results = @employeesInTowns OUTPUT

WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT @LastName + ' ' + @TownName
	FETCH NEXT FROM @employeesInTowns
	INTO @LastName, @TownName
END

CLOSE @employeesInTowns
DEALLOCATE @employeesInTowns
/* 9. * Write a T-SQL script that shows for each town a list of all employees that live in it. Sample output:
		Sofia -> Svetlin Nakov, Martin Kulov, George Denchev
		Ottawa -> Jose Saraiva*/
	
USE TelerikAcademy
GO	
		
SELECT Towns.Name AS Town, dbo.STRCONCAT(emp.FirstName + ' ' + emp.LastName) AS Employees  
FROM Towns
	JOIN Addresses AS addr
	ON Towns.TownID = addr.TownID
	JOIN Employees AS emp
		ON emp.AddressID = addr.AddressID
GROUP BY Towns.Name
ORDER BY Towns.Name
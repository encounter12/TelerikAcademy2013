/* 2.Create a stored procedure that accepts a number as a parameter and returns all persons who have more money in their accounts than the supplied number.*/
USE TelerikAcademy
GO

CREATE PROC usp_SelectPersonsWithMoreMoneyThen(@personMoney int = 900)
AS
	SELECT p.FirstName + ' ' + p.LastName AS FullName, a.Balance AS [Money] 
	FROM Persons p
		JOIN Accounts a 
			ON (a.PersonID = p.PersonID AND a.Balance > @personMoney)
GO

EXEC usp_SelectPersonsWithMoreMoneyThen 500
GO
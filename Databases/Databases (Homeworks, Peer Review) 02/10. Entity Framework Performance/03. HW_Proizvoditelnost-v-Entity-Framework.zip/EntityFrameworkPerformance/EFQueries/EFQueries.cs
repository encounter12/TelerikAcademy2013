﻿namespace EFQueries
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;

    class EFQueries
    {
        //Using Entity Framework write a SQL query to select all employees from the Telerik Academy
        //database and later print their name, department and town. Try the both variants: 
        //with and without .Include(…). Compare the number of executed SQL statements and the performance.
        static void Task1()
        {
            var dbContext = new TelerikAcademyEntities();
            //Connect with db
            dbContext.Employees.Count();

            //Firts variant without include
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            foreach (var employee in dbContext.Employees)
            {
                Console.WriteLine("{0} {1} | {3}  | in {2} department", employee.FirstName, employee.LastName, employee.Department.Name, employee.Address.Town.Name);
            }
            stopWatch.Stop();
            Console.WriteLine();
            Console.WriteLine(stopWatch.Elapsed);
            //Aproximetly 300 miliseconds (Queries counts equal to number of employees)

            stopWatch.Reset();
            stopWatch.Start();
            foreach (var employee in dbContext.Employees.Include("Department").Include("Address"))
            {
                Console.WriteLine("{0} {1} | {3}  | in {2} department", employee.FirstName, employee.LastName, employee.Department.Name, employee.Address.Town.Name);
            }
            stopWatch.Stop();
            Console.WriteLine();
            Console.WriteLine(stopWatch.Elapsed);
            //Aproximetly 90 miliseconds (Just one query to database)
        }

        //Using Entity Framework write a query that selects all employees from the Telerik Academy database,
        //then invokes ToList(), then selects their addresses, then invokes ToList(), then selects their towns,
        //then invokes ToList() and finally checks whether the town is "Sofia". Rewrite the same in more
        //optimized way and compare the performance.

        static void Task2()
        {
            var dbContext = new TelerikAcademyEntities();
            //Connect with db
            dbContext.Employees.Count();

            //Firts variant with to many (ToList)
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            var allEmployees = dbContext.Employees
                .Select(employee => 
                    new 
                    { 
                        Name = employee.FirstName, 
                        @Address = employee.Address
                    }).ToList()
                .Select(employee => employee.Address).ToList()
                .Select(address => address.Town)
                .Where(town => town.Name == "Sofia");

            foreach (var employee in allEmployees)
            {
                Console.WriteLine("{0} {1}", employee.TownID, employee.Name);
            }

            stopWatch.Stop();
            Console.WriteLine();
            Console.WriteLine(stopWatch.Elapsed);
            //Aproximetly 280 miliseconds (Queries counts equal to number of employees)

            stopWatch.Reset();
            stopWatch.Start();
            var employeesCollection = dbContext.Employees
                .Select(employees =>
                    new
                    {
                        Name = employees.FirstName+ " "+employees.LastName,
                        TownName = employees.Address.Town.Name
                    });

            foreach (var employee in employeesCollection)
            {
                Console.WriteLine("{0} {1}", employee.Name, employee.TownName);
            }

            stopWatch.Stop();
            Console.WriteLine();
            Console.WriteLine(stopWatch.Elapsed);
            //Aproximetly 70 miliseconds (Just one query to database)
        }

        static void Main(string[] args)
        {
            Task1();
            Task2();
        }
    }
}
-- Exercise01. 
-- What is SQL? What is DML? What is DDL? Recite the most important SQL commands.

-- SQL is a special-purpose programming language designed for managing data held in
-- a relational database management system (RDBMS)

-- A data manipulation language (DML) is a family of syntax elements similar to a 
-- computer programming language used for inserting, deleting and updating data in a
-- database. Performing read-only queries of data is sometimes also considered a component
-- of DML.

-- A data definition language or data description language (DDL) is a syntax similar
-- to a computer programming language for defining data structures, especially database schemas.

-- Exercise02.
-- What is Transact-SQL (T-SQL)?
-- Transact-SQL (T-SQL) is Microsoft's and Sybase's proprietary extension to SQL.
-- Supports if statements, loops, exceptions
-- Constructions used in the high-level procedural programming languages
-- T-SQL is used for writing stored procedures, functions, triggers, etc.

-- Exercise03.
-- Did that.

-- Exercise04. 
-- Write a SQL query to find all information about all departments (use "TelerikAcademy" database).

SELECT * FROM Departments

-- Exercise05. 
-- Write a SQL query to find all department names.

SELECT Name FROM Departments

-- Exercise06. 
-- Write a SQL query to find the salary of each employee.

SELECT FirstName + ' ' + LastName AS [Full Name], Salary FROM Employees

-- Exercise07. 
-- Write a SQL to find the full name of each employee.

SELECT FirstName + ' ' + LastName AS [Full Name] FROM Employees

-- Exercise08. 
-- Write a SQL query to find the email addresses of each employee 
-- (by his first and last name). Consider that the mail domain is telerik.com.
-- Emails should look like �John.Doe@telerik.com". The produced column should be
-- named "Full Email Addresses".

SELECT FirstName +'.'+ LastName+'@telerik.com' AS [Full Email Addresses] FROM Employees

-- Exercise09. 
-- Write a SQL query to find all different employee salaries.

SELECT DISTINCT FirstName + ' ' + LastName AS [Full Name], Salary  FROM Employees

-- Exercise10. Write a SQL query to find all information about the employees whose 
-- job title is �Sales Representative�.

SELECT *  FROM Employees WHERE JobTitle = 'Sales Representative'

-- Exercise11. 
-- Write a SQL query to find the names of all employees whose first name starts with "SA".

SELECT *  FROM Employees WHERE FirstName Like 'SA%'

-- Exercise12.
-- Write a SQL query to find the names of all employees whose last name contains "ei".

SELECT *  FROM Employees WHERE LastName Like '%ei%'

-- Exercise13. 
-- Write a SQL query to find the salary of all employees whose salary is in the range [20000�30000].

SELECT *  FROM Employees WHERE Salary BETWEEN 20000 AND 30000

-- Exercise14. 
-- Write a SQL query to find the names of all employees whose salary is 25000, 14000, 12500 or 23600.

SELECT FirstName + ' ' + LastName AS [Full Name], Salary  FROM Employees WHERE Salary IN (25000, 14000, 12500, 23600)

-- Exercise15. 
-- Write a SQL query to find all employees that do not have manager.

SELECT * FROM Employees WHERE ManagerID IS NULL

-- Exercise16. 
-- Write a SQL query to find all employees that have salary more than 
-- 50000. Order them in decreasing order by salary.

SELECT FirstName + ' ' + LastName AS [Full Name], Salary  FROM Employees WHERE Salary > 5000 Order BY Salary DESC

-- Exercise17. 
-- Write a SQL query to find the top 5 best paid employees.

SELECT TOP(5) Salary FROM Employees 

-- Exercise18. 
-- Write a SQL query to find all employees along with their address. Use inner join with ON
-- clause.

SELECT * FROM Employees e JOIN Addresses a ON e.AddressID = a.AddressID

-- Exercise19. 
-- Write a SQL query to find all employees and their address. Use equijoins
-- (conditions in the WHERE clause).

SELECT e.EmployeeID, e.LastName, 
      d.AddressText AS Addresses
FROM Employees e, Addresses d 
WHERE e.AddressID = d.AddressID


-- Exercise20. 
-- Write a SQL query to find all employees along with their manager.

SELECT e.FirstName + ' ' + e.LastName 
AS [Employees], m.FirstName +' '+ m.LastName 
AS [Employees Manager] 
FROM Employees e 
Join Employees m 
ON e.ManagerID = m.EmployeeID

-- Exercise21. 
-- Write a SQL query to find all employees, along with their manager and their address.
-- Join the 3 tables: Employees e, Employees m and Addresses a.

SELECT e.FirstName + ' ' + e.LastName 
AS [Employees], m.FirstName +' '+ m.LastName 
AS [Employees Manager],
a.AddressText [Employee Adress]
FROM Employees e 
Join Employees m 
ON e.ManagerID = m.EmployeeID
JOIN Addresses a
ON a.AddressID = e.EmployeeID

-- Exercise22.
-- Write a SQL query to find all departments and all town names as a single list. Use UNION.

SELECT Name
FROM Departments
UNION
SELECT Name
FROM Towns

-- Exercise23. 
-- Write a SQL query to find all the employees and the manager for each of 
-- them along with the employees that do not have manager. Use right outer join.
-- Rewrite the query to use left outer join.

SELECT e.FirstName + ' ' + e.LastName 
AS [Employees], m.FirstName +' '+ m.LastName 
AS [Employees Manager] 
FROM Employees e 
LEFT OUTER Join Employees m 
ON e.ManagerID = m.EmployeeID

-- Exercise24. 
-- Write a SQL query to find the names of all employees from the departments 
-- "Sales" and "Finance" whose hire year is between 1995 and 2005.

SELECT e.FirstName + ' ' + e.LastName, e.HireDate 
FROM Employees e JOIN Departments d 
ON e.DepartmentID = d.DepartmentID AND d.Name = 'Sales' OR  d.Name = 'Finance'
WHERE   FORMAT(HireDate, 'yyyy') BETWEEN 1995 AND 2005
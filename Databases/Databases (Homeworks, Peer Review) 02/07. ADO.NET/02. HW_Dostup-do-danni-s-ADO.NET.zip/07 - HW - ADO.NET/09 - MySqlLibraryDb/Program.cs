﻿
namespace HW
{
    using System;
    using MySql.Data.MySqlClient;
    class Program
    {
        static void Main(string[] args)
        {
            // Download and install MySQL database, MySQL Connector/Net (.NET Data Provider for MySQL) + MySQL Workbench GUI administration tool . Create a MySQL database to store Books (title, author, publish date and ISBN). Write methods for listing all books, finding a book by name and adding a book.

            // IMPORT THE LIBRARY DB FROM THE SCRIPT IN THE PROJECT FOLDER
            string connectionString = "Server=localhost;Port=3306;Database=library;Uid=root;Pwd=;";

            MySqlConnection libraryDatabase = new MySqlConnection(connectionString);

            ListAllBooks(libraryDatabase);
            FindABook(libraryDatabase);
            AddNewBook(libraryDatabase, "The Silmarillion", "J.R.R. Tolkien");
            ListAllBooks(libraryDatabase);
        }

        private static void AddNewBook(MySqlConnection libraryDatabase, string bookTitle, string authorName)
        {
            libraryDatabase.Open();

            using (libraryDatabase)
            {
                MySqlCommand insertBookCommand = new MySqlCommand("INSERT INTO books(Title, Author) VALUES(@title, @author)", libraryDatabase);

                insertBookCommand.Parameters.AddWithValue("@title", bookTitle);
                insertBookCommand.Parameters.AddWithValue("@author", authorName);

                insertBookCommand.ExecuteNonQuery();

                MySqlCommand getNewBookIdCommand = new MySqlCommand("SELECT LAST_INSERT_ID();", libraryDatabase);
                int newBookId = (int)(ulong)getNewBookIdCommand.ExecuteScalar();

                Console.WriteLine("Book {0} by {1} has been added with ID {2}", bookTitle, authorName, newBookId);

                Console.WriteLine("------------------------------");
            }
        }

        private static void FindABook(MySqlConnection libraryDatabase)
        {
            Console.Write("Please type the book name keyword: ");
            string queryWord = Console.ReadLine();

            libraryDatabase.Open();

            using (libraryDatabase)
            {
                MySqlCommand selectBooksCommand = new MySqlCommand("SELECT Title, Author FROM books WHERE Title LIKE @query", libraryDatabase);

                selectBooksCommand.Parameters.AddWithValue("@query", "%" + queryWord + "%");

                MySqlDataReader booksReader = selectBooksCommand.ExecuteReader();

                string bookTitle, authorName;

                Console.WriteLine("Search results");

                while (booksReader.Read())
                {
                    bookTitle = (string)booksReader["Title"];
                    authorName = (string)booksReader["Author"];

                    Console.WriteLine("{0} by {1}", bookTitle, authorName);
                }

                Console.WriteLine("------------------------------");
            }
        }

        private static void ListAllBooks(MySqlConnection libraryDatabase)
        {
            libraryDatabase.Open();

            using (libraryDatabase)
            {
                MySqlCommand selectBooksCommand = new MySqlCommand("SELECT Title, Author FROM books", libraryDatabase);

                MySqlDataReader booksReader = selectBooksCommand.ExecuteReader();

                string bookTitle, authorName;

                Console.WriteLine("Books in library");

                while (booksReader.Read())
                {
                    bookTitle = (string)booksReader["Title"];
                    authorName = (string)booksReader["Author"];

                    Console.WriteLine("{0} by {1}", bookTitle, authorName);
                }

                Console.WriteLine("------------------------------");
            }
        }
    }
}

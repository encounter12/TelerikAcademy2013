﻿namespace HW
{
    using System;
    using System.Data.SQLite;
    class Program
    {
        static void Main(string[] args)
        {
             CreateDatabase();

             // You need to copy the SQLite.Interop.dll into the bin/debug folder if you get an exception
            
            FillDatabaseWithData();
            ListAllBooks();
            FindABook();
            AddNewBook("The Silmarillion", "J.R.R. Tolkien");
            ListAllBooks();
        }

        private static void CreateDatabase()
        {
            SQLiteConnection.CreateFile("library.sqlite");
        }

        private static void FillDatabaseWithData()
        {
            SQLiteConnection libraryDatabase = new SQLiteConnection("Data Source=library.sqlite;Version=3;");
            libraryDatabase.Open();

            using (libraryDatabase)
            {
                SQLiteCommand createTableCommand = new SQLiteCommand("CREATE TABLE `books` (`BookID` INTEGER PRIMARY KEY AUTOINCREMENT,`Title` varchar(45) NOT NULL,`Author` varchar(45) NOT NULL,`ISBN` varchar(45) DEFAULT NULL)", libraryDatabase);

                createTableCommand.ExecuteNonQuery();

                SQLiteCommand fillTableWithDataCommand = new SQLiteCommand("INSERT INTO `books` VALUES (1,'Lord of the Rings','J.R.R. Tolkien',NULL),(2,'Hobbit','J.R.R. Tolkien',NULL),(3,'Eragon','C. Paolini',NULL);", libraryDatabase);

                fillTableWithDataCommand.ExecuteNonQuery();
            }
        }

        private static void AddNewBook(string bookTitle, string authorName)
        {
            SQLiteConnection libraryDatabase = new SQLiteConnection("Data Source=library.sqlite;Version=3;");
            libraryDatabase.Open();

            using (libraryDatabase)
            {
                SQLiteCommand insertBookCommand = new SQLiteCommand("INSERT INTO books(Title, Author) VALUES(@title, @author)", libraryDatabase);

                insertBookCommand.Parameters.AddWithValue("@title", bookTitle);
                insertBookCommand.Parameters.AddWithValue("@author", authorName);

                insertBookCommand.ExecuteNonQuery();

                SQLiteCommand getNewBookIdCommand = new SQLiteCommand("SELECT last_insert_rowid();", libraryDatabase);
                int newBookId = (int)(long)getNewBookIdCommand.ExecuteScalar();

                Console.WriteLine("Book {0} by {1} has been added with ID {2}", bookTitle, authorName, newBookId);

                Console.WriteLine("------------------------------");
            }
        }

        private static void FindABook()
        {
            Console.Write("Please type the book name keyword: ");
            string queryWord = Console.ReadLine();

            SQLiteConnection libraryDatabase = new SQLiteConnection("Data Source=library.sqlite;Version=3;");
            libraryDatabase.Open();

            using (libraryDatabase)
            {
                SQLiteCommand selectBooksCommand = new SQLiteCommand("SELECT Title, Author FROM books WHERE Title LIKE @query", libraryDatabase);

                selectBooksCommand.Parameters.AddWithValue("@query", "%" + queryWord + "%");

                SQLiteDataReader booksReader = selectBooksCommand.ExecuteReader();

                string bookTitle, authorName;

                Console.WriteLine("Search results");

                while (booksReader.Read())
                {
                    bookTitle = (string)booksReader["Title"];
                    authorName = (string)booksReader["Author"];

                    Console.WriteLine("{0} by {1}", bookTitle, authorName);
                }

                Console.WriteLine("------------------------------");
            }
        }

        private static void ListAllBooks()
        {
            SQLiteConnection libraryDatabase = new SQLiteConnection("Data Source=library.sqlite;Version=3;");
            libraryDatabase.Open();

            using (libraryDatabase)
            {
                SQLiteCommand selectBooksCommand = new SQLiteCommand("SELECT title, author FROM books", libraryDatabase);

                SQLiteDataReader booksReader = selectBooksCommand.ExecuteReader();

                string bookTitle, authorName;

                Console.WriteLine("Books in library");

                while (booksReader.Read())
                {
                    bookTitle = (string)booksReader["Title"];
                    authorName = (string)booksReader["Author"];

                    Console.WriteLine("{0} by {1}", bookTitle, authorName);
                }

                Console.WriteLine("------------------------------");
            }
        }
    }
}

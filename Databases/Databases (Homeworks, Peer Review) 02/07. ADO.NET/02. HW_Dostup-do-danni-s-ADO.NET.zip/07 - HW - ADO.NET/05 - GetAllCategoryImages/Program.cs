﻿namespace HW
{
    using System;
    using System.Data.SqlClient;
using System.IO;
    class Program
    {
        static void Main(string[] args)
        {
            // Write a program that retrieves the images for all categories in the Northwind database and stores them as JPG files in the file system.

            string connectionString = "Server=LYUBENPC; Database=Northwind; Integrated Security=true";

            SqlConnection northwindDatabase = new SqlConnection(connectionString);

            northwindDatabase.Open();

            using (northwindDatabase)
            {
                SqlCommand getImagesCommand = new SqlCommand("SELECT CategoryID, Picture FROM Categories", northwindDatabase);

                SqlDataReader imagesReader = getImagesCommand.ExecuteReader();

                string imageName;
                byte[] imageData;

                while (imagesReader.Read())
                {
                    imageName = "Category" + (int)imagesReader["CategoryID"];
                    imageData = (byte[])imagesReader["Picture"];

                    SaveImageDataToJpegFile(@"..\..\Images", imageName, imageData);
                }
            }
        }

        private static void SaveImageDataToJpegFile(string folderPath,string imageName,byte[] imageData)
        {
 	        FileStream stream = File.OpenWrite(folderPath + "\\" + imageName + ".jpg");

            using (stream)
            {
                stream.Write(imageData, 0, imageData.Length);
            }

            Console.WriteLine("File {0} saved to {1}", imageName + ".jpg", folderPath);
        }
    }
}

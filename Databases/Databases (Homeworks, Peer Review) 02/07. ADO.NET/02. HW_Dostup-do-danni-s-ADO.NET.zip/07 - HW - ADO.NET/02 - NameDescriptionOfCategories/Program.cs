﻿namespace HW
{
    using System;
    using System.Data.SqlClient;

    class Program
    {
        static void Main(string[] args)
        {
            // Write a program that retrieves the name and description of all categories in the Northwind DB.
            
            string connectionString = "Server=LYUBENPC; " +
            "Database=Northwind; Integrated Security=true";

            SqlConnection northwindConnection = new SqlConnection(connectionString);

            northwindConnection.Open();

            using (northwindConnection)
            {
                SqlCommand getCategoriesCommand = new SqlCommand("SELECT CategoryName, Description FROM Categories", northwindConnection);

                string categoryName = "";
                string categoryDescription = "";

                SqlDataReader categoriesReader = getCategoriesCommand.ExecuteReader();

                while (categoriesReader.Read())
                {
                    categoryName = (string)categoriesReader["CategoryName"];
                    categoryDescription = (string)categoriesReader["Description"];

                    Console.WriteLine("{0} - {1}", categoryName, categoryDescription);
                }
            }
        }
    }
}

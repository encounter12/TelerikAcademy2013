﻿namespace _04___AddProductMethod
{
    using System;
    using System.Data.SqlClient;

    class Program
    {
        
        static void Main(string[] args)
        {
            //4.  Write a method that adds a new product in the products table in the Northwind database. Use a parameterized SQL command.
            //int newProductId = InsertProductIntoNorthwind("Coca-Cola");

            //Console.WriteLine("Row with ID {0} has been added", newProductId);

            // 7. Write a program that reads a string from the console and finds all products that contain this string. Ensure you handle correctly characters like ', %, ", \ and _.
            Console.Write("Please enter a product keyword: ");
            string productQuery = Console.ReadLine().ToLower();

            PrintProductsByKeyword(productQuery);
        }

        private static void PrintProductsByKeyword(string productQuery)
        {
            // NO NEED TO ESCAPE WHEN USING PARAMETERS
            if (string.IsNullOrEmpty(productQuery))
            {
                throw new ArgumentNullException("The name of the product can't be null or empty");
            }

            SqlConnection northwindDatabase = new SqlConnection("Server=LYUBENPC; Database=Northwind; Integrated Security=true");

            northwindDatabase.Open();

            using (northwindDatabase)
            {
                SqlCommand newProductCommand = new SqlCommand("SELECT ProductID, ProductName FROM Products WHERE ProductName LIKE '%' + @query + '%'", northwindDatabase);

                newProductCommand.Parameters.AddWithValue("@query", productQuery);
                SqlDataReader reader =  newProductCommand.ExecuteReader();

                int productId;
                string productName;

                while (reader.Read())
                {
                    productId = (int)reader["ProductID"];
                    productName = (string)reader["ProductName"];

                    Console.WriteLine("ID {0} - NAME {1}", productId, productName);
                }
            }
        }

        private static int InsertProductIntoNorthwind(string productName) {
            int productID = 0;

            if (string.IsNullOrEmpty(productName))
            {
                throw new ArgumentNullException("The name of the product can't be null or empty");
            }

            SqlConnection northwindDatabase = new SqlConnection("Server=LYUBENPC; Database=Northwind; Integrated Security=true");

            northwindDatabase.Open();

            using (northwindDatabase)
            {
                SqlCommand newProductCommand = new SqlCommand("INSERT INTO Products(ProductName) VALUES (@name);", northwindDatabase);

                newProductCommand.Parameters.AddWithValue("@name", productName);
                newProductCommand.ExecuteNonQuery();

                SqlCommand newProductIdCommand = new SqlCommand("SELECT @@identity", northwindDatabase);

                productID = (int)(decimal)newProductIdCommand.ExecuteScalar();
            }

            return productID;
        }
    }
}

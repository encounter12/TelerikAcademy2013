﻿namespace HW
{
    using System;
    using System.Data.OleDb;

    class Program
    {
        static void Main(string[] args)
        {
            // Create an Excel file with 2 columns: name and score: Write a program that reads your MS Excel file through the OLE DB data provider and displays the name and score row by row. 
            // YOU NEED TO INSTALL http://www.microsoft.com/download/en/confirmation.aspx?id=23734 IF YOU GET microsoft.ace.oledb.12.0 ERROR
            PrintDartsScores();

            Console.WriteLine("--------------------------------------");

            InsertRecordInDarts("Ivaylo Kenov", 29);

            Console.WriteLine("--------------------------------------");

            PrintDartsScores();
        }

        private static void InsertRecordInDarts(string competitorsName, int competitorsScore)
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=..\..\Files\Competition.xlsx; Extended Properties='Excel 12.0 Xml;HDR=YES'";

            OleDbConnection competitionFile = new OleDbConnection(connectionString);

            competitionFile.Open();

            using (competitionFile)
            {
                OleDbCommand insertScoreRecords = new OleDbCommand("INSERT INTO [Darts$](Name, Score) VALUES(@name, @score)", competitionFile);

                insertScoreRecords.Parameters.AddWithValue("@name", competitorsName);
                insertScoreRecords.Parameters.AddWithValue("@score", competitorsScore);

                insertScoreRecords.ExecuteScalar();
                Console.WriteLine("{0} with score {1} has been added successfully", competitorsName, competitorsScore);
            }
        }

        private static void PrintDartsScores()
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=..\..\Files\Competition.xlsx; Extended Properties='Excel 12.0 Xml;HDR=YES'";

            OleDbConnection competitionFile = new OleDbConnection(connectionString);

            competitionFile.Open();

            using (competitionFile)
            {
                OleDbCommand dartsScoresCommand = new OleDbCommand("SELECT * FROM [Darts$]", competitionFile);

                OleDbDataReader scoresReader = dartsScoresCommand.ExecuteReader();

                string name;
                double score;

                while (scoresReader.Read())
                {
                    name = (string)scoresReader["Name"];
                    score = (double)scoresReader["Score"];

                    Console.WriteLine("{0} scored {1} points", name, score);
                }
            }
        }
    }
}

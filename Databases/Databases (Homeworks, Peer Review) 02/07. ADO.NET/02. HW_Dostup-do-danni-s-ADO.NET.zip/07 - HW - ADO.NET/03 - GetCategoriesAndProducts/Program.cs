﻿namespace HW
{
    using System;
    using System.Data.SqlClient;

    class Program
    {
        static void Main(string[] args)
        {
            // Write a program that retrieves from the Northwind database all product categories and the names of the products in each category. Can you do this with a single SQL query (with table join)?

            string connectionString = "Server=LYUBENPC; " +
            "Database=Northwind; Integrated Security=true";

            SqlConnection northwindDatabase = new SqlConnection(connectionString);

            northwindDatabase.Open();

            using (northwindDatabase)
            {
                SqlCommand command = new SqlCommand("SELECT c.CategoryName, p.ProductName FROM Categories AS c JOIN Products AS p ON c.CategoryID = p.CategoryID ORDER BY c.CategoryName, p.ProductName", northwindDatabase);

                SqlDataReader reader = command.ExecuteReader();

                string categoryName = "";
                string productName = "";

                while (reader.Read())
                {
                    categoryName = (string)reader["CategoryName"];
                    productName = (string)reader["ProductName"];

                    Console.WriteLine("{0} - {1}", categoryName, productName);
                }
            }
        }
    }
}

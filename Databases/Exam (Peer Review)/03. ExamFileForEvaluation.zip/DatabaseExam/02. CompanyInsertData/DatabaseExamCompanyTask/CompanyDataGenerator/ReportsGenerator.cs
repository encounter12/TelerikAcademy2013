﻿namespace CompanyDataGenerator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CompanyData;

    public class ReportsGenerator
    {
        private CompanyEntities1 company;
        private Random random;

        public ReportsGenerator() 
        {
            this.company = new CompanyEntities1();
            this.random = new Random();
        }

        public void GenerateReports(int reportsCount) 
        {
            Generator generator = new Generator();
            var employees = this.company.Employees.ToList();
            var report = new Report();
            var index = 0;

            foreach (var employee in employees)
            {
                for (int i = 0; i < 50; i++)
                {
                    report = new Report();
                    report.ReportTime = DateTime.Now.AddMonths(5);
                    report.Employee = employee;
                    this.company.Reports.Add(report);
                    index++;
                    if (index % 100 == 10)
                    {
                        Console.Write(".");
                        this.company.SaveChanges();
                    }
                }
            }

            this.company.SaveChanges();
        }
    }
}

﻿namespace CompanyDataGenerator
{
    public interface IGenerator
    {
        string GenerateString(int minLength, int maxLength);

        decimal GenerateSalary();
    }
}

﻿namespace CompanyDataGenerator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CompanyData;

    public class EmployeesGenerator
    {
        private CompanyEntities1 company; 
        private Random random;

        public EmployeesGenerator() 
        {
            this.company = new CompanyEntities1();
            this.random = new Random();
        }

        public void GenerateEmployees(int employeesCount) 
        {
            HashSet<Employee> employees = new HashSet<Employee>();
            Generator generator = new Generator();
            var departmentIds = this.company.Departments.Select(a => a.Id).ToList();
            var employeesIds = new List<int>();
            int index = 0;
            var savedEmployees = 0;

            while (employees.Count < employeesCount)
            {
                var employee = new Employee();
                employee.FirstName = generator.GenerateString(5, 20);
                employee.LastName = generator.GenerateString(5, 20);
                employee.YearSalary = generator.GenerateSalary();
                employee.DepartmentId = departmentIds[GetRandomIndex(departmentIds)];
                
                if (index % 100 < 5)
                {
                    employee.ManagerId = null;
                    if (index % 100 == 4) 
                    {
                        savedEmployees = index;
                        company.SaveChanges();
                    }
                }

                else 
                {
                    employee.Employee1 = employees.ElementAt(savedEmployees);
                }

                employees.Add(employee);
                company.Employees.Add(employee);
                if (index % 100 == 0)
                {
                    savedEmployees = index;
                    Console.Write(".");
                    company.SaveChanges();
                }

                index++;
            }
            company.SaveChanges();
        }

        private int GetRandomIndex(List<int> list)
        {
            return this.random.Next(0, list.Count);
        }

        private int GetRandomEmployee(int savedCount)
        {
            return this.random.Next(0, savedCount - 1);
        }
    }
}

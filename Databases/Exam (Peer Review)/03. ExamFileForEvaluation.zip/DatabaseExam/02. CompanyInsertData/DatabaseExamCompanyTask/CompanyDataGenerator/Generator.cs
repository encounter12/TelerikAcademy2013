﻿namespace CompanyDataGenerator
{
    using System;
    using CompanyData;

    public class Generator : IGenerator
    {
        private readonly int minSalary = 50000;
        private readonly int maxSalary = 200000;
        private readonly string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; 
        private Random random = new Random();

        public string GenerateString(int minLength, int maxLength)
        {
            char[] result = new char[maxLength - minLength];

            for (int i = 0; i < result.Length; i++)
            {
                result[i] = letters[random.Next(0, letters.Length - 1)];
            }

            return new string(result);
        }


        public decimal GenerateSalary()
        {
            return (decimal)random.Next(this.minSalary, this.maxSalary);
        }
    }
}

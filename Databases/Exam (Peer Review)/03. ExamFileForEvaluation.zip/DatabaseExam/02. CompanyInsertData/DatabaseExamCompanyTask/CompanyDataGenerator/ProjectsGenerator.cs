﻿namespace CompanyDataGenerator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CompanyData;

    public class ProjectsGenerator
    {
        private CompanyEntities1 company;
        private Random random;
        private readonly int minParticipantsCount = 2;
        private readonly int maxParticipantsCount = 20;

        public ProjectsGenerator() 
        {
            this.company = new CompanyEntities1();
            random = new Random();
        }

        public void GenerateProjects(int projectsCount) 
        {
            HashSet<Project> projects = new HashSet<Project>();
            Generator generator = new Generator();
            int participantsCount; 

            while (projects.Count < projectsCount)
            {
                var project = new Project();
                project.Name = generator.GenerateString(5, 50);
                participantsCount = GetParticipantsCount();
                var participant = new EmployeesProject();
                participant.Project = project;
               
                for (int i = 0; i < participantsCount; i++)
                {
                    var randIndex = GetRandomIndex(int.Parse(this.company.Employees.Count().ToString()));
                    Employee emp = new Employee();
                    emp = this.company.Employees.First(a => a.FirstName == "ygNdmWtpUyEsinx");
                    participant.Employee = emp;
                    participant.StartDate = DateTime.Now.AddMonths(-5);
                    participant.EndDate = DateTime.Now.AddMonths(5);
                    this.company.EmployeesProjects.Add(participant);
                    project.EmployeesProjects.Add(participant);
                }
                
                projects.Add(project);
                this.company.Projects.Add(project);

                if (projects.Count % 100 == 10)
                {
                    Console.Write(".");
                    this.company.SaveChanges();
                }
            }
        }

        private int GetParticipantsCount() 
        {
            return this.random.Next(minParticipantsCount, maxParticipantsCount);
        }

        private int GetRandomIndex(int listCount) 
        {
            return this.random.Next(0, listCount);
        }
    }
}

﻿namespace CompanyDataGenerator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Data.SqlClient;
    using CompanyData;

    public class DepartmentsGenerator
    {
        private CompanyEntities1 company; // = new CompanyEntities();

        public DepartmentsGenerator() 
        {
            this.company = new CompanyEntities1();
        }

        public void GenerateDepartments(int departmentsCount) 
        {
            // USE HASHSET
            HashSet<Department> departments = new HashSet<Department>();
            Generator namesGenerator = new Generator();

            while (departments.Count < departmentsCount)
            {
                var department = new Department();
                department.Name = namesGenerator.GenerateString(10, 50);
                departments.Add(department);
                this.company.Departments.Add(department);

                if (departmentsCount % 100 == 0)
                {
                    this.company.SaveChanges();
                }
            }
        }
    }
}

﻿namespace CompanyClient
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Data.SqlClient;
    using CompanyData;
    using CompanyDataGenerator;

    public class Program
    {
        private static readonly int departmentsCount = 100;
        private static readonly int employeesCount = 5000;
        private static readonly int projectsCount = 1000;
        private static readonly int reportsCount = 250000;

        static void Main(string[] args)
        {
            Console.WriteLine("Adding departments");
            //DepartmentsGenerator departments = new DepartmentsGenerator();
            //departments.GenerateDepartments(departmentsCount);
            Console.WriteLine(departmentsCount + " departments added");

            Console.WriteLine("\nAdding Employees (slow operation)");
            // EmployeesGenerator employees = new EmployeesGenerator();
            // employees.GenerateEmployees(employeesCount);
            Console.WriteLine("\n" + employeesCount + " employees added");

            Console.WriteLine("\nAdding projects");
            ProjectsGenerator projects = new ProjectsGenerator();
            projects.GenerateProjects(projectsCount);
            Console.WriteLine(projectsCount + " projects added");

            Console.WriteLine("\nAdding reports");
            // ReportsGenerator reports = new ReportsGenerator();
            // reports.GenerateReports(reportsCount);
            Console.WriteLine("\n" + reportsCount + " reports added");
        }
    }
}

﻿namespace CarsSystemData
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class SearchXML
    {
        public string OrderBy { get; set; }

        public Dictionary<string, string> WhereClauses { get; set; }

        public List<string> InnerValues { get; set; }

        public SearchXML() 
        {
            this.WhereClauses = new Dictionary<string, string>();
            this.InnerValues = new List<string>();
        }
    }
}

﻿namespace CarsSystemData
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CarsSystemModel;
    using System.Runtime.Serialization;

    public class CarsSystemDBContext : DbContext
    {
        public DbSet<Car> Cars { get; set; }
        
        public DbSet<City> Cities { get; set; }

        public DbSet<Dealer> Dealers { get; set; }

        public DbSet<Manufacturer> Manufaturers { get; set; }

        public DbSet<TransmissionType> TransmissionTypes { get; set; }

        public new void SaveChanges()
        {
            base.SaveChanges();
            // Database.SetInitializer(MigrateDatabaseToLatestVersion<CarsSystemDBContext, Configuration>());
        }
    }
}

﻿namespace CarsSystemModel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Data.SqlClient;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.ComponentModel.DataAnnotations;

    public class Car
    {
        public int Id { get; set; }

        [Index(IsUnique = true)]
        [MaxLength(20)]
        public string Model { get; set; }

        [Required]
        public int TransmisionId { get; set; }

        public TransmissionType Transimission { get; set; }

        public int DealerId { get; set; }

        public Dealer CarDealer { get; set; }

        public int ManufacturerId { get; set; }

        public Manufacturer CarManufacturer { get; set; }

        public int Year { get; set; }

        public decimal Price { get; set; }
    }
}

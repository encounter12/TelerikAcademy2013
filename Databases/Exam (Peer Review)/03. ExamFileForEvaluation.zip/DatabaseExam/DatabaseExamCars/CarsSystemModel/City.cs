﻿namespace CarsSystemModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    
    public class City
    {
        public int Id { get; set; }

        [Index(IsUnique = true)]
        [Required]
        [MaxLength(10)]
        public string CityName { get; set; }

        public virtual ICollection<Dealer> Dealers { get; set; }

        public City() 
        {
            this.Dealers = new HashSet<Dealer>();
        }
    }
}

﻿namespace CarsSystemClient
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Data.SqlClient;
    using CarsSystemData;
    using CarsSystemModel;
    using System.Xml.Linq;

    public class Program
    {
        static void Main()
        {
            CarsSystemDBContext db = new CarsSystemDBContext();
            // test to find if it works correctly
            /*
            using (db) 
            {
                Dealer dealer = new Dealer();
                dealer.Name = "GoshoAuto";
                db.Dealers.Add(dealer);
                db.SaveChanges();
            }
            */

            // task7
            var xmlContent = XElement.Load(@"../../../queries.xml");
            Console.WriteLine(xmlContent.ToString());
            var elements = xmlContent.Elements("Query");

            foreach (var element in elements)
            {
                if (element.Name == "Query") 
                {
                    /*var path = (@"../../../" + element.Attribute("OutputFileName").Value)
                        .Remove((@"../../../" + element.Attribute("OutputFileName").Value).Length - 5)
                        .Replace("\"", "");
                    Console.WriteLine(path);
                    var xmlResultWritter = new XElement(path); */
                    var search = new SearchXML();
                    search.OrderBy = element.Element("OrderBy").Value;
                    var whereClauses = element.Elements("WhereClauses");

                    foreach (var clause in whereClauses.Elements("WhereClause"))
                    {
                        search.WhereClauses.Add(clause.Attribute("PropertyName").Name.ToString(),
                            clause.Attribute("Type").Name.ToString());
                        search.InnerValues.Add(clause.Value);
                    }

                    if (search.WhereClauses.ContainsKey("Id")) 
                    {
 
                    }
                    var result = db.Cars.Select();
                }
            }
        }
    }
}

-- 3.	Get each employee�s full name (first name + � � + last name), project�s name,
-- department�s name, starting and ending date for each employee in project.
-- Additionally get the number of all reports, which time of reporting is between 
-- the start and end date. Sort the results first by the employee id, then by the 
-- project id. (This query is slow, be patient!)
USE Company
GO

SELECT e.FirstName + ' ' + e.LastName AS [Employee Name],
	p.Name, d.Name, ep.StartDate, ep.EndDate,
	(SELECT COUNT(*)
	FROM Reports r
	WHERE r.ReportTime BETWEEN ep.StartDate AND ep.EndDate) AS [Reports Count]
FROM Employees e
JOIN EmployeesProjects ep
	ON e.Id = ep.EmployeeId
JOIN Projects p
	ON p.Id = ep.ProjectId
JOIN Departments d
	ON d.Id = e.DepartmentId
ORDER BY e.Id, p.Id;
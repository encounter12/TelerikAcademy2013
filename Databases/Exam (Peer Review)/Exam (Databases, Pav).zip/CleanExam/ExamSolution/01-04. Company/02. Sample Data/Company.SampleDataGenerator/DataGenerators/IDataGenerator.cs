﻿namespace Company.SampleDataGenerator.DataGenerators
{
    using Company.SampleDataGenerator.RandomDataGenerators;

    public interface IDataGenerator
    {
        RandomDataGenerator RandomDataGenerator { get; set; }

        void Generate(int numberOfRecords);
    }
}

﻿namespace Company.SampleDataGenerator.DataGenerators
{
    using Company.Data;
    using Company.SampleDataGenerator.RandomDataGenerators;

    public abstract class AbstractDataGenerator : IDataGenerator
    {
        protected CompanyEntities DbContext { get; set; }

        public RandomDataGenerator RandomDataGenerator { get; set; }

        public AbstractDataGenerator(CompanyEntities dbContext, RandomDataGenerator randomDataGenerator)
        {
            this.DbContext = dbContext;
            this.RandomDataGenerator = randomDataGenerator;            
        }

        public abstract void Generate(int numberOfRecords);
    }
}

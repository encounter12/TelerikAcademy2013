﻿namespace Company.SampleDataGenerator.DataGenerators
{
    using System;
    using System.Linq;

    using Company.Data;
    using Company.Models;
    using Company.SampleDataGenerator.RandomDataGenerators;

    internal class EmployeesDataGenerator : AbstractDataGenerator
    {
        internal EmployeesDataGenerator(CompanyEntities dbContext, RandomDataGenerator randomDataGenerator) :
            base(dbContext, randomDataGenerator)
        {

        }

        public override void Generate(int recordsNumber)
        {
            Console.WriteLine("Importing employees");

            var departmentsIds = this.DbContext.Departments.Select(d => d.Id).ToList();

            for (int i = 0; i < recordsNumber; i++)
            {
                var employee = new Employee();
                employee.FirstName = this.RandomDataGenerator.GetString(5, 15);
                employee.LastName = this.RandomDataGenerator.GetString(5, 15);

                // 95% of them have managers and their salary is between $50 000 and $200 000, inclusive.
                var chance = this.RandomDataGenerator.GetChance(95);
                if (chance)
                {
                    // Employeees
                    employee.YearSalary = this.RandomDataGenerator.GetInt(50000, 200000);
                    var manager = this.DbContext.Employees.FirstOrDefault(e => e.ManagerId == null);
                    if (manager != null)
                    {
                        employee.ManagerId = manager.Id;
                    }
                }
                else
                {
                    // Managers
                    employee.YearSalary = this.RandomDataGenerator.GetInt(210000, 300000);
                }
                
                // Add department
                var departmentIndex = this.RandomDataGenerator.GetInt(0, departmentsIds.Count - 1);
                employee.DepartmentId = departmentsIds.ElementAt(departmentIndex);
                
                // Save employee
                this.DbContext.Employees.Add(employee);

                if (i % 100 == 0)
                {
                    this.DbContext.SaveChanges();
                    Console.Write(".");
                }
            }

            this.DbContext.SaveChanges();

            Console.WriteLine("\nEmployees imported");
        }
    }
}
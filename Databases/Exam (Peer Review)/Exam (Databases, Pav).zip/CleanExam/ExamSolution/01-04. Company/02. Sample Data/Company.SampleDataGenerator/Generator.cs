﻿namespace Company.SampleDataGenerator
{
    using Company.Data;
    using DataGenerators;
    using RandomDataGenerators;    

    internal class Generator
    {
        private static void Main()
        {
            CompanyEntities dbContext = new CompanyEntities();
            RandomDataGenerator randomDataGenerator = RandomDataGenerator.Instance;

            dbContext.Configuration.AutoDetectChangesEnabled = false;

            // Generate departments
            IDataGenerator departmentsDataGenerator = new DepartmentsDataGenerator(dbContext, randomDataGenerator);
            departmentsDataGenerator.Generate(100);

            // Generate employees
            IDataGenerator employeesDataGenerator = new EmployeesDataGenerator(dbContext, randomDataGenerator);
            employeesDataGenerator.Generate(5000);

            // Generate projects
            IDataGenerator projectsDataGenerator = new ReportsDataGenerator(dbContext, randomDataGenerator);
            projectsDataGenerator.Generate(1000);
            
            // Generate reports
            IDataGenerator reportsDataGenerator = new ReportsDataGenerator(dbContext, randomDataGenerator);
            reportsDataGenerator.Generate(250000);

            dbContext.Configuration.AutoDetectChangesEnabled = true;
        }
    }
}

﻿namespace Company.SampleDataGenerator.DataGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Company.Data;
    using Company.Models;
    using Company.SampleDataGenerator.RandomDataGenerators;

    internal class ProjectsDataGenerator : AbstractDataGenerator
    {
        internal ProjectsDataGenerator(CompanyEntities dbContext, RandomDataGenerator randomDataGenerator) :
            base(dbContext, randomDataGenerator)
        {

        }

        public override void Generate(int recordsNumber)
        {
            Console.WriteLine("Importing projects");

            var employeesIds = this.DbContext.Employees.Select(e => e.Id).ToList();

            for (int i = 0; i < recordsNumber; i++)
            {
                var project = new Project();
                project.Name = this.RandomDataGenerator.GetString(5, 40);

                // Add employees
                var chance = this.RandomDataGenerator.GetChance(50);
                int numberOfEmployees;
                if (chance)
                {
                    numberOfEmployees = 5;
                }
                else
                {
                    numberOfEmployees = this.RandomDataGenerator.GetInt(2, 20);
                }
                
                var projectEmployeesIds = new HashSet<int>();

                while (projectEmployeesIds.Count != numberOfEmployees)
                {
                    var employeeIndex = this.RandomDataGenerator.GetInt(0, employeesIds.Count - 1);
                    projectEmployeesIds.Add(employeeIndex);
                }

                foreach (var projectEmployeeId in projectEmployeesIds)
                {
                    var employeeProject = new EmployeesProject();
                    employeeProject.EmployeeId = projectEmployeeId;

                    var startDate = DateTime.Now;
                    var days = this.RandomDataGenerator.GetInt(1, 200);

                    chance = this.RandomDataGenerator.GetChance(65);
                    if (chance)
                    {
                        startDate.AddDays(-days);
                    }
                    else
                    {
                        startDate.AddDays(days);
                    }
                    employeeProject.StartDate = startDate;
                    employeeProject.EndDate = startDate.AddDays(this.RandomDataGenerator.GetInt(20, 300));

                    project.EmployeesProjects.Add(employeeProject);
                }
                                
                // Save project
                this.DbContext.Projects.Add(project);

                if (i % 100 == 0)
                {
                    this.DbContext.SaveChanges();
                    Console.Write(".");
                }
            }

            this.DbContext.SaveChanges();

            Console.WriteLine("\nProjects imported");
        }
    }
}
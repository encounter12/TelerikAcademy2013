﻿namespace Company.SampleDataGenerator.DataGenerators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Company.Data;
    using Company.Models;
    using Company.SampleDataGenerator.RandomDataGenerators;

    internal class ReportsDataGenerator : AbstractDataGenerator
    {
        internal ReportsDataGenerator(CompanyEntities dbContext, RandomDataGenerator randomDataGenerator) :
            base(dbContext, randomDataGenerator)
        {

        }

        public override void Generate(int recordsNumber)
        {
            Console.WriteLine("Importing reports");

            var employeesIds = this.DbContext.Employees.Select(e => e.Id).ToList();

            for (int i = 0; i < recordsNumber; i++)
            {
                var report = new Report();

                report.Time = DateTime.Now;

                var days = this.RandomDataGenerator.GetInt(1, 200);

                var chance = this.RandomDataGenerator.GetChance(50);
                if (chance)
                {
                    report.Time.AddDays(-days);
                }
                else
                {
                    report.Time.AddDays(days);
                }

                // Add employee
                var employeeIndex = this.RandomDataGenerator.GetInt(0, employeesIds.Count - 1);
                report.EmployeeId = employeesIds.ElementAt(employeeIndex);
     
                // Save project
                this.DbContext.Reports.Add(report);

                if (i % 100 == 0)
                {
                    this.DbContext.SaveChanges();
                    Console.Write(".");
                }
            }

            this.DbContext.SaveChanges();

            Console.WriteLine("\nReports imported");
        }
    }
}
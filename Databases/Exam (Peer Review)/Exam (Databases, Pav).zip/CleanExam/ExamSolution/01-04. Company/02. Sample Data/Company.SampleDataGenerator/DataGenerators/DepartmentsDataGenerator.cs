﻿namespace Company.SampleDataGenerator.DataGenerators
{
    using System;
    using System.Text;

    using Company.Data;
    using Company.Models;
    using Company.SampleDataGenerator.RandomDataGenerators;

    internal class DepartmentsDataGenerator : AbstractDataGenerator
    {
        internal DepartmentsDataGenerator(CompanyEntities dbContext, RandomDataGenerator randomDataGenerator) :
            base(dbContext, randomDataGenerator)
        {

        }

        public override void Generate(int recordsNumber)
        {
            Console.WriteLine("Importing departments");

            var stringBuilder = new StringBuilder();

            for (int i = 0; i < recordsNumber; i++)
            {
                stringBuilder.Clear();
                stringBuilder.Append(this.RandomDataGenerator.GetString(5, 30));
                stringBuilder.Append(i);

                var department = new Department();
                department.Name = stringBuilder.ToString();

                this.DbContext.Departments.Add(department);

                if (i % 100 == 0)
                {
                    this.DbContext.SaveChanges();
                    Console.Write(".");
                }
            }

            this.DbContext.SaveChanges();

            Console.WriteLine("\nDepartments imported");
        }
    }
}
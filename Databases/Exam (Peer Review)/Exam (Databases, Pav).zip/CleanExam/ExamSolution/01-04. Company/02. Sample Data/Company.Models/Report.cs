namespace Company.Models
{
    using System;

    public partial class Report
    {
        public int Id { get; set; }

        public DateTime Time { get; set; }

        public int EmployeeId { get; set; }

        public virtual Employee Employee { get; set; }
    }
}

-- Get each employee's full name (first name + " " + last name), project's name, department's name, starting and ending date for each employee in project. 
-- Additionally get the number of all reports, which time of reporting is between the start and end date. 
-- Sort the results first by the employee id, then by the project id. 
-- (This query is slow, be patient!)

USE Company;
GO

SELECT CONCAT(e.FirstName, ' ', e.LastName) AS FullName, 
    p.Name AS ProjectName, 
    d.Name AS DepartmentName, 
    ep.StartDate AS ProjectStartDate, ep.EndDate AS ProjectEndDate, (
        SELECT COUNT(r.Id)
        FROM Reports AS r
        WHERE r.EmployeeId = e.Id AND
            r.Time >= ep.StartDate AND r.Time <= ep.EndDate
    ) AS ReportsCount     
FROM Employees AS e
INNER JOIN EmployeesProjects AS ep ON e.Id = ep.EmployeeId
INNER JOIN Projects AS p ON p.Id = ep.ProjectId
INNER JOIN Departments AS d ON e.DepartmentId = d.Id
ORDER BY e.Id, p.Id
GO
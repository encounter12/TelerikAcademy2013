-- Get all departments and how many employees there are in each one. 
-- Sort the result by the number of employees in descending order.

USE Company
GO

SELECT d.Name AS DepartmentName, COUNT(e.Id) AS EmployeesCount
FROM Departments AS d
INNER JOIN Employees AS e ON e.DepartmentId = d.Id
GROUP BY d.Id, d.Name
GO
Please change ALL connection strings in the App.config files if needed.
I am using SQL Server 2014 Developer Edition.
Thanks.
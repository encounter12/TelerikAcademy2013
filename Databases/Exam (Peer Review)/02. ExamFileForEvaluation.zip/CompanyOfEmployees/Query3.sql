USE CompanyOfEmployees

SELECT e.FirstName + ' ' + e.LastName AS [FullName]
		
FROM Employees e	
		
USE CompanyOfEmployees

SELECT d.Name AS [Department],
		COUNT(e.EmployeeID) AS [EmployeesInDepartment]
FROM Departments d, 
		Employees e
WHERE e.DepartmentID = d.DepartmentID
GROUP BY d.Name
ORDER BY [EmployeesInDepartment] DESC
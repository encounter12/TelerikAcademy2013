USE CompanyOfEmployees

SELECT e.FirstName + ' ' + e.LastName AS [FullName], e.Salary AS [Salary]
FROM Employees e
WHERE e.Salary BETWEEN 100000 AND 150000
ORDER BY e.Salary
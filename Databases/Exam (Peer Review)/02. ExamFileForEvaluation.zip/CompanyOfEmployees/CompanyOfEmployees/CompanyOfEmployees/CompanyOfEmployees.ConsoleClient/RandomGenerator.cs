﻿namespace CompanyOfEmployees.ConsoleClient
{
    using System;
    using System.Collections.Generic;

    public class RandomGenerator : IRandomGenerator
    {
        private const int DEFAULT_MINIMAL_STRING_LENGTH = 5;
        private const int DEFAULT_MAXIMAL_STRING_LENGTH = 50;
        private const string RANDOM_STRING_BASE_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

        private static readonly Random random = new Random();

        private IRandomGenerator randomGeneratorInstance;

        public RandomGenerator()
        {
        }

        /// <summary>
        /// Gets the instance of the class. Singleton Design Pattern
        /// </summary>
        public IRandomGenerator GetInstance
        {
            get
            {
                if (this.randomGeneratorInstance == null)
                {
                    this.randomGeneratorInstance = new RandomGenerator();
                }

                return this.randomGeneratorInstance;
            }
        }

        /// <summary>
        /// Generates random integer number.
        /// </summary>
        public int GetRandomInt(int minValue = 0, int maxValue = int.MaxValue)
        {
            int generatedNumber = random.Next(minValue, maxValue);

            return generatedNumber;
        }

        /// <summary>
        /// Generates random double number in given range. Default ranges are 0.00 to double.MaxValue.
        /// </summary>
        public double GetRandomDouble(double minValue = 0.00, double maxValue = double.MaxValue)
        {
            // Returns a random floating-point number between 0.0 and 1.0.
            var randomDoubleValue = random.NextDouble();
            var generatedNumber = minValue + (randomDoubleValue * (maxValue - minValue));

            return generatedNumber;
        }

        /// <summary>
        /// Generates random string with given lengh. Default length is 10.
        /// </summary>
        public string GetRandomString(int length = DEFAULT_MAXIMAL_STRING_LENGTH)
        {
            char[] charsSelected = new char[length];

            for (int i = 0; i < length; i++)
            {
                charsSelected[i] = RANDOM_STRING_BASE_CHARS[random.Next(RANDOM_STRING_BASE_CHARS.Length)];
            }

            return new string(charsSelected);
        }

        /// <summary>
        /// Generates random string with random lenght between 3 and 10 symbols.
        /// </summary>
        public string GetRandomLengthString()
        {
            int randomLength = this.GetRandomInt(DEFAULT_MINIMAL_STRING_LENGTH, DEFAULT_MAXIMAL_STRING_LENGTH);
            string generatedString = this.GetRandomString(randomLength);

            return generatedString;
        }

        /// <summary>
        /// Generates a set (with given length) of random strings (optional lenght). 
        /// Default strings length is between 3 and 10 symbols.
        /// </summary>
        public ISet<string> GetUniqueRandomStringsSet(int listLength, int stringLength = 0)
        {
            var generatedStrings = new HashSet<string>();

            while (generatedStrings.Count < listLength)
            {
                if (stringLength == 0)
                {
                    stringLength = this.GetRandomInt(DEFAULT_MINIMAL_STRING_LENGTH, DEFAULT_MAXIMAL_STRING_LENGTH);
                }

                string currentString = this.GetRandomString(stringLength);
                generatedStrings.Add(currentString);
            }

            return generatedStrings;
        }

        /// <summary>
        /// Generates a set (with given length) of random integers.
        /// </summary>
        public ISet<int> GetUniqueRandomIntegersSet(int listLength, int minValue = 0, int maxValue = int.MaxValue)
        {
            var generatedIntegers = new HashSet<int>();

            while (generatedIntegers.Count < listLength)
            {
                int currentInteger = this.GetRandomInt(minValue, maxValue);
                generatedIntegers.Add(currentInteger);
            }

            return generatedIntegers;
        }

        /// <summary>
        /// Generates random date from minimal year to today. Default minimal date is 1990.1.1
        /// </summary>
        public DateTime GetRandomStartDate(int minimalYear = 1990)
        {
            DateTime startDate = new DateTime(minimalYear, 1, 1);            
            int range = (DateTime.Today - startDate).Days;
            var generatedDate = startDate.AddDays(random.Next(range));

            return generatedDate;
        }

        public DateTime GetRandomEndDate(int maximumDate = 2050)
        {
            DateTime endDate = new DateTime(maximumDate, 1, 1);
            int range = (endDate - DateTime.Today).Days;
            var generatedDate = endDate.AddDays(random.Next(range));

            return generatedDate;
        }
    }
}

﻿namespace CompanyOfEmployees.ConsoleClient
{
    using System;
    using System.Collections.Generic;

    public interface IRandomGenerator
    {
        int GetRandomInt(int minValue, int maxValue);

        double GetRandomDouble(double minValue, double maxValue);

        string GetRandomString(int length);

        string GetRandomLengthString();

        ISet<string> GetUniqueRandomStringsSet(int listLength, int stringLength);

        ISet<int> GetUniqueRandomIntegersSet(int listLength, int minValue, int maxValue);

        DateTime GetRandomStartDate(int minimalYear);

        DateTime GetRandomEndDate(int maximumYear);
    }
}

﻿namespace CompanyOfEmployees.ConsoleClient
{
    using System;
    using System.Linq;
    using CompanyOfEmployees.Models;
    using System.Collections.Generic;

    public class EntryPoint
    {
        static void Main()
        {
            //CHECK THE CONNECTIONSTRING IN App.config IN BOTH PROJECTS!!!
            //I'M USING ONLY . AS DATA SOURCE 
            //IF YOU ARE WITH SQLEXPRESS, PLEASE CHANGE IT TO .\SQLEXPRESS IN BOTH PROJECTS!!!

            CompanyOfEmployeesEntities dbContext = new CompanyOfEmployeesEntities();
            RandomGenerator random = new RandomGenerator();

            //Add Departments
            GenerateDepartmentsData(dbContext, random);    

            //Add Projects
            GenerateProjects(dbContext, random);

            //Add Employees
            GenerateEmployees(dbContext, random);

            //Add Reports
            GenerateReports(dbContext, random);
        }

        private static void GenerateEmployees(CompanyOfEmployeesEntities dbContext, RandomGenerator random)
        {
            int counter = 0;
            var departmentsIDs = dbContext.Departments.Select(x => x.DepartmentID).ToList();
            var projectsIDs = dbContext.Projects.Select(x => x.ProjectID).ToList();

            var managersIDs = random.GetUniqueRandomIntegersSet(0, 5000);

            for (int i = 0; i < 5000; i++)
            {
                Employee currentEmployee = new Employee();
                counter++;

                currentEmployee.FirstName = random.GetRandomString(20);
                currentEmployee.LastName = random.GetRandomString(20);
                currentEmployee.Salary = (decimal)random.GetRandomDouble(50000, 200000);
                currentEmployee.DepartmentID = departmentsIDs[random.GetRandomInt(0, departmentsIDs.Count - 1)];
                currentEmployee.Projects.Add(dbContext.Projects.Find(random.GetRandomInt(0, projectsIDs.Count - 1)));

                foreach (var managerID in managersIDs)
                {
                    currentEmployee.ManagerID = managerID;
                }

                dbContext.Employees.Add(currentEmployee);

                if (counter % 1000 == 0)
                {
                    Console.WriteLine("Added: {0} employees", counter);
                    dbContext.SaveChanges();
                }
            }

            dbContext.SaveChanges();
        }

        private static void GenerateReports(CompanyOfEmployeesEntities dbContext, RandomGenerator random)
        {
            int counter = 0;
            var employeesIDs = dbContext.Employees.Select(x => x.EmployeeID).ToList();

            for (int i = 0; i < 250000; i++)
            {
                Report currentReport = new Report();
                counter++;

                currentReport.TimeOfReporting = random.GetRandomStartDate();
                currentReport.EmployeeID = employeesIDs[random.GetRandomInt(0, employeesIDs.Count - 1)];

                dbContext.Reports.Add(currentReport);

                if (counter % 1000 == 0)
                {
                    Console.WriteLine("Added: {0} reports", counter);
                    dbContext.SaveChanges();
                }
            }

            dbContext.SaveChanges();
        }

        private static void GenerateProjects(CompanyOfEmployeesEntities dbContext, RandomGenerator random)
        {
            var projectNames = random.GetUniqueRandomStringsSet(1000);

            int counter = 0;

            foreach (var name in projectNames)
            {
                Project currentProject = new Project();
                counter++;

                currentProject.Name = name;
                currentProject.StartDate = random.GetRandomStartDate();
                currentProject.EndDate = random.GetRandomEndDate();

                dbContext.Projects.Add(currentProject);

                if (counter % 100 == 0)
                {
                    Console.WriteLine("Added: {0} projects", counter);
                    dbContext.SaveChanges();
                }
            }
            dbContext.SaveChanges();
        }

        private static void GenerateDepartmentsData(CompanyOfEmployeesEntities dbContext, RandomGenerator random)
        {
            var departmentNames = random.GetUniqueRandomStringsSet(100);

            int counter = 0;

            foreach (var name in departmentNames)
            {
                Department currentDepartment = new Department();
                counter++;

                currentDepartment.Name = name;

                dbContext.Departments.Add(currentDepartment);

                if (counter % 50 == 0)
                {
                    Console.WriteLine("Added: {0} departments", counter);
                    dbContext.SaveChanges();
                }
            }
            dbContext.SaveChanges();
        }
    }
}

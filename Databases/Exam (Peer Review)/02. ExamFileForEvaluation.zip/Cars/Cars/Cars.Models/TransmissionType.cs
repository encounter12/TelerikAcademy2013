﻿namespace Cars.Models
{
    public enum TransmissionType
    {
        Manual,
        Automatic
    }
}

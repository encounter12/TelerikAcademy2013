﻿namespace Cars.Models
{
    public class JSONDealer
    {
        public string Name { get; set; }

        public string City { get; set; }
    }
}

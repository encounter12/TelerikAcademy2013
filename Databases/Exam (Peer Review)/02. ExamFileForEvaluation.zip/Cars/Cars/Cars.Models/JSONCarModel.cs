﻿namespace Cars.Models
{
    using System;
    using System.Collections.Generic;

    public class JSONCarModel
    {
        public JSONCarModel()
        {

        }

        public int Year { get; set; }

        public int TransmissionType { get; set; }

        public string ManufacturerName { get; set; }

        public string Model { get; set; }

        public decimal Price { get; set; }        

        public JSONDealer Dealers { get; set; }
    }
}

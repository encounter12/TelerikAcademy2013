﻿namespace Cars.DataContext
{    
    using System.Data.Entity;
    using Cars.Models;
    using Cars.DataContext.Migrations;

    public class CarsDBContext : DbContext
    {
        public CarsDBContext()
            :base("CarsEntities")
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<CarsDBContext, Configuration>());
        }

        public IDbSet<Car> Cars { get; set; }

        public IDbSet<Manufacturer> Manufacturers { get; set; }

        public IDbSet<City> Cities { get; set; }

        public IDbSet<Dealer> Dealers { get; set; }
    }
}

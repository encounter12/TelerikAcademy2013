﻿namespace Cars.ConsoleClient
{
    using System;
    using Cars.DataContext;
    using Cars.Models;
    using Newtonsoft.Json.Linq;
    using System.IO;
    using Newtonsoft.Json;
    using System.Collections.Generic;
    using System.Text;

    public class EntryPoint
    {
        static void Main()
        {
            //CHECK THE CONNECTIONSTRING IN App.config IN ALL PROJECTS!!!
            //I'M USING ONLY . AS DATA SOURCE 
            //IF YOU ARE WITH SQLEXPRESS, PLEASE CHANGE IT TO .\SQLEXPRESS IN ALL PROJECTS!!!

            CarsDBContext dbContext = new CarsDBContext();

            var json = new StreamReader("data.0.json", Encoding.UTF8).ReadToEnd();
            var json1 = new StreamReader("data.1.json", Encoding.UTF8).ReadToEnd();
            var json2 = new StreamReader("data.2.json", Encoding.UTF8).ReadToEnd();
            var json3 = new StreamReader("data.3.json", Encoding.UTF8).ReadToEnd();
            var json4 = new StreamReader("data.4.json", Encoding.UTF8).ReadToEnd();
            var obj = JsonConvert.DeserializeObject(json);

            //IF YOU WANT TO ADD THE DATA FROM THE OTHER JSON FILES, JUST CHANGE json -> json1 or json2 etc. 
            List<JSONCarModel> list = JsonConvert.DeserializeObject<List<JSONCarModel>>(json);

            foreach (var item in list)
            {
                var currentCar = new Car();
                var currentManufactorer = new Manufacturer();

                currentManufactorer.Name = item.ManufacturerName;
                dbContext.Manufacturers.Add(currentManufactorer);
                dbContext.SaveChanges();

                currentCar.Year = item.Year;
                currentCar.Model = item.Model;
                currentCar.Price = item.Price;
                currentCar.ManufacturerID = currentManufactorer.ManufacturerID;

                if (item.TransmissionType == 0)
                {
                    currentCar.Type = TransmissionType.Manual;
                }
                else
                {
                    currentCar.Type = TransmissionType.Automatic;
                }


                dbContext.Cars.Add(currentCar);
                dbContext.SaveChanges();
            }

            //UN-COMMEND THE NEXT LINES ONLY TO SEE THAT THE DATABASE CAN BE CREATED!!!
            //Manufacturer man = new Manufacturer();
            //man.Name = "Gosho";

            //dbContext.Manufacturers.Add(man);

            dbContext.SaveChanges();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NorthwindData;

namespace _03.CustomersWithSpecificOrders
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new NorthwindEntities())
            {
                var customers =  db.Orders.Where(o=>o.OrderDate.Value.Year == 1997 && o.ShipCountry == "Canada").Select(o=>o.Customer)
                    .Distinct().ToList();
                foreach (var customer in customers)
                {
                    Console.WriteLine(customer.CustomerID);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NorthwindData;

namespace CustomerOrdersWithSqlQuery
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new NorthwindEntities())
            {
                string nativeSqlQuery =
                "SELECT DISTINCT c.CustomerID " +
                "From Customers c " +
                "JOIN Orders o " +
                "ON c.CustomerID = o.CustomerID " +
                "WHERE o.ShipCountry = '{0}'" +
                "AND FORMAT(o.OrderDate, 'yyyy') = '{1}'";
                object[] parameters = {"Canada", "1997"};
                var customers = db.Database.SqlQuery<string>(string.Format(nativeSqlQuery, parameters));

                foreach (var customer in customers)
                {
                    Console.WriteLine(customer);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NorthwindData;

namespace _02.CustomerManipulator
{
    class Customers
    {
        static void Main(string[] args)
        {
            Customer newCustomer = new Customer()
            {
                CustomerID = "ABC12",
                CompanyName = "My Company"
                
            };

            InsertCustomer(newCustomer);
            EditCustomer("ABC12", "Ivan Petkan");
            DeleteCustomer("ABC12");
        }

        public static void InsertCustomer(Customer customer){
            using(var db = new NorthwindEntities()){
                var hasCustomer = GetCustomerById(db, customer.CustomerID);
                if (hasCustomer!=null)
                {
                    Console.WriteLine("Customer is already in the table");
                    return;
                }

                db.Customers.Add(customer);
                db.SaveChanges();
                Console.WriteLine("Custemer is saved");
            }
        }

        public static void EditCustomer(string id, string contactName)
        {
            using (var db = new NorthwindEntities())
            {
                var customer = GetCustomerById(db, id);
                if (customer == null)
                {
                    Console.WriteLine("There's no such customer");
                    return;
                }
                customer.ContactName = contactName;
                db.SaveChanges();
                Console.WriteLine("Custemer is successfully updated");
            }
        }

        private static void DeleteCustomer(string id)
        {
            using (var db = new NorthwindEntities())
            {
                var customer = GetCustomerById(db, id);
                if (customer == null)
                {
                    Console.WriteLine("There's no such customer");
                    return;
                }
                db.Customers.Remove(customer);
                db.SaveChanges();
                Console.WriteLine("Custemer is successfully deleted");
            }
        }

        private static Customer GetCustomerById(NorthwindEntities db,string id)
        {
            return db.Customers.Where(c => c.CustomerID == id).FirstOrDefault();
        }
    }
}

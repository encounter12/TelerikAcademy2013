﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NorthwindData;

namespace _05.Sales
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Insert Start Year: ");
            int parsedStart = int.Parse(Console.ReadLine());
            Console.Write("Insert End Year: ");
            int parsedEnd = int.Parse(Console.ReadLine());
            Console.Write("Insert Region: ");
            string region = Console.ReadLine();

            using (var db = new NorthwindEntities())
            {

                var sales = db.Orders.
                    Where(o => o.ShipRegion == region && o.OrderDate.HasValue && (
                        o.OrderDate.Value.Year >= parsedStart && o.OrderDate.Value.Year <= parsedEnd));
                if (sales.Count() == 0)
                {
                    Console.WriteLine("There are no sales in this period or in this region");
                }

                foreach (var sale in sales)
                {
                    Console.WriteLine(sale.Customer.CustomerID + " " + sale.Customer.CompanyName);
                }
            }
        }
    }
}

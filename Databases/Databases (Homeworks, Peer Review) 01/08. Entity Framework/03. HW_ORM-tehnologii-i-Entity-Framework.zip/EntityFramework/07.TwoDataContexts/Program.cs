﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NorthwindData;

namespace _07.TwoDataContexts
{
    class Program
    {
        static void Main(string[] args)
        {
            using (NorthwindEntities northwindEntities1 = new NorthwindEntities())
            {
                using (NorthwindEntities northwindEntities2 = new NorthwindEntities())
                {
                    var customerId = "VAFFE";
                    Customer customerFirstData = northwindEntities1.Customers.Find(customerId);
                    customerFirstData.ContactName = "Ivan Ivanov";

                    Customer customerSecondData = northwindEntities2.Customers.Find(customerId);
                    customerSecondData.ContactName = "Ivanka Ivanova";

                    northwindEntities1.SaveChanges();
                    northwindEntities2.SaveChanges();
                    Console.WriteLine(customerId + " is successfully updated");
                }
            }

            Console.WriteLine("Changes successfully made!");
        }
    }
}

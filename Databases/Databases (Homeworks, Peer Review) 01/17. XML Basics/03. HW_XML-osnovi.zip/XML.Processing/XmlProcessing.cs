﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;

namespace Xml.Processing
{
    class XmlProcessing
    {
        private const string filePath = "../../catalog.xml";

        static void Main()
        {
            // Task 02
            PrintArtistsAlbumsCountUsingDomParser();

            // Task 03
            PrintArtistsAlbumsCountUsingXPath();

            // Task 04
            DeleteAlbumsWithPriceLessThanUsingDomParser(20);            

            // Task 05
            PrintAllSongsTitlesUsingXmlReader();
           
            // Task 06
            PrintAllSongTitlesUsingXDocumentAndLinq();

            // Task 07
            CreateContactsXml();

            // Task 08
            CreateAlbumXmlUsingXmlReaderAndWriter();

            // Task 09
            WriteDirStructureToXml();

            // Task 10
            WriteDirStructureToXmlUsingLinq();

            // Task 11
            ExtractSelectionPricesFromCatalog();

            // Task 12
            ExtractSelectionPricesFromCatalogUsingLinq();
        }

        /// <summary>
        /// Task 02 - Write program that extracts all different artists which are found in the catalog.xml. 
        /// For each author you should print the number of albums in the catalogue. Use the DOM parser and a hash-table.
        /// </summary>
        private static void PrintArtistsAlbumsCountUsingDomParser()
        {
            var doc = new XmlDocument();
            doc.Load(filePath);

            var countArtistsAlbums = new Dictionary<string, int>();

            var rootNode = doc.DocumentElement;

            foreach (XmlNode node in rootNode.ChildNodes)
            {
                var artistName = node["artist"].InnerText;

                if (!countArtistsAlbums.ContainsKey(artistName))
                {
                    countArtistsAlbums.Add(artistName, 0);
                }

                countArtistsAlbums[artistName]++;
            }

            foreach (var artist in countArtistsAlbums)
            {
                Console.WriteLine("{0} [{1}]", artist.Key, artist.Value);
            }

            Console.WriteLine(new string('*', 50));
        }

        /// <summary>
        /// Task 03 - Write program that extracts all different artists which are found in the catalog.xml. 
        /// For each author you should print the number of albums in the catalogue. Use the XPath.
        /// </summary>
        private static void PrintArtistsAlbumsCountUsingXPath()
        {
            var doc = new XmlDocument();
            doc.Load(filePath);

            var countArtistsAlbums = new Dictionary<string, int>();

            var albumNodes = doc.SelectNodes("catalog/album");

            foreach (XmlNode node in albumNodes)
            {
                var artistName = node["artist"].InnerText;

                if (!countArtistsAlbums.ContainsKey(artistName))
                {
                    countArtistsAlbums.Add(artistName, 0);
                }

                countArtistsAlbums[artistName]++;
            }

            foreach (var artist in countArtistsAlbums)
            {
                Console.WriteLine("{0} [{1}]", artist.Key, artist.Value);
            }

            Console.WriteLine(new string('*', 50));

        }

        /// <summary>
        /// Task 04 - Using the DOM parser write a program to delete from catalog.xml all albums having price > 20.
        /// </summary>
        /// <param name="price">Album price</param>
        private static void DeleteAlbumsWithPriceLessThanUsingDomParser(int price)
        {
            var doc = new XmlDocument();
            doc.Load(filePath);
            //var rootNode = doc.DocumentElement;
            //var nodes = doc.SelectNodes("catalog/album");

            var albumsForDeletion =
                doc.SelectNodes("catalog/album")
                   .Cast<XmlNode>()
                   .Where(album => double.Parse(album["price"].InnerText) < price);

            foreach (var album in albumsForDeletion)
            {
                album.ParentNode.RemoveChild(album);
            }

            doc.Save("../../catalogAfterDeletionOfAlbums.xml");
        }

        /// <summary>
        /// Task 05 - Write a program, which using XmlReader extracts all song titles from catalog.xml.
        /// </summary>
        private static void PrintAllSongsTitlesUsingXmlReader()
        {
            Console.WriteLine("Print all songs titles: ");
            using (var reader = XmlReader.Create(filePath))
            {
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element && reader.Name == "title")
                    {
                        Console.WriteLine("Song title: {0}", reader.ReadElementString());
                    }
                }
            }
            Console.WriteLine(new string('*', 50));
        }

        /// <summary>
        /// Task 06 - Write a program, which using XDocument and LINQ extracts all song titles from catalog.xml.
        /// </summary>
        private static void PrintAllSongTitlesUsingXDocumentAndLinq()
        {
            var xDoc = XDocument.Load(filePath);
            var songTitles = from title in xDoc.Descendants("title")
                             select title.Value;

            Console.WriteLine("Print all song titles:");
            foreach (var song in songTitles)
            {
                Console.WriteLine(song);
            }
            Console.WriteLine(new string('*', 50));
        }

        /// <summary>
        /// Task 07 - In a text file we are given the name, address and phone number of given person (each at a single line). 
        /// Write a program, which creates new XML document, which contains these data in structured XML format.
        /// </summary>
        private static void CreateContactsXml()
        {
            var fileName = "../../contacts.xml";
            var streamReader = new StreamReader("../../Contacts.txt");
            XNamespace ns = "http://contactinfo.com/peshocontacts";
            var contactXml = new XElement(ns + "contacts");

            while (!streamReader.EndOfStream)
            {
                var name = streamReader.ReadLine();
                var address = streamReader.ReadLine();
                var phoneNumber = streamReader.ReadLine();

                contactXml.Add(
                    new XElement(
                        ns + "contact",
                        new XElement(ns + "name", name),
                        new XElement(ns + "address", address),
                        new XElement(ns + "phone", phoneNumber)));
            }

            contactXml.Save(fileName);
            Console.WriteLine("Document {0} created.", fileName);
            Console.WriteLine(new string('*', 50));
        }

        /// <summary>
        /// Task 08 - Write a program, which (using XmlReader and XmlWriter) reads the file catalog.xml 
        /// and creates the file album.xml, in which stores in appropriate way the names of all albums and their authors.
        /// </summary>
        private static void CreateAlbumXmlUsingXmlReaderAndWriter()
        {
            string fileName = "../../album.xml";
            Encoding encoding = Encoding.GetEncoding("windows-1251");
            using (XmlTextWriter writer = new XmlTextWriter(fileName, encoding))
            {
                writer.Formatting = Formatting.Indented;
                writer.IndentChar = '\t';
                writer.Indentation = 1;

                writer.WriteStartDocument();
                writer.WriteStartElement("albums");

                var name = string.Empty;

                using (var reader = XmlReader.Create(filePath))
                {
                    while (reader.Read())
                    {
                        if (reader.NodeType == XmlNodeType.Element && reader.Name == "name")
                        {
                            name = reader.ReadElementString();
                        }
                        else if (reader.NodeType == XmlNodeType.Element && reader.Name == "artist")
                        {
                            var artist = reader.ReadElementString();
                            WriteAlbum(writer, name, artist);
                        }
                    }
                }

                writer.WriteEndDocument();
            }
            Console.WriteLine("Document {0} created.", fileName);
            Console.WriteLine(new string('*', 50));
        }
        private static void WriteAlbum(XmlWriter writer, string name, string artist)
        {
            writer.WriteStartElement("album");
            writer.WriteElementString("name", name);
            writer.WriteElementString("artist", artist);
            writer.WriteEndElement();
        }

        /// <summary>
        /// Task 09 - Write a program to traverse given directory and write to a XML file its contents 
        /// together with all subdirectories and files. Use tags <file> and <dir> with appropriate attributes. 
        /// For the generation of the XML document use the class XmlWriter.
        /// </summary>
        private static void WriteDirStructureToXml()
        {
            var createdXmlFileName = "../../directory.xml";
            DirectoryInfo sourceDirectory = new DirectoryInfo("../../");

            using(XmlTextWriter writer = new XmlTextWriter(createdXmlFileName, Encoding.UTF8))
            {
                writer.Formatting = Formatting.Indented;
                writer.IndentChar = '\t';
                writer.Indentation = 1;

                writer.WriteStartDocument();
                writer.WriteStartElement("directories");

                BuildXml(writer, sourceDirectory);

                writer.WriteEndDocument();
            
            }
            Console.WriteLine("Document {0} created.", createdXmlFileName);
            Console.WriteLine(new string('*', 50));
        }
        private static void BuildXml(XmlTextWriter writer, DirectoryInfo sourceDirectory)
        {
            //if (sourceDirectory.GetFiles().Count() == 0 && sourceDirectory.GetDirectories().Count() == 0)
            //{
            //    return;
            //}

            writer.WriteStartElement("dir");
            writer.WriteAttributeString("name", sourceDirectory.Name);
            //writer.WriteElementString("name", sourceDirectory.Name);

            foreach (var childDirectory in sourceDirectory.GetDirectories())
            {
                BuildXml(writer, childDirectory);
            }
           
            foreach (var file in sourceDirectory.GetFiles())
            {                
                writer.WriteElementString("file", file.Name);
            }
            
            writer.WriteEndElement();
        }

        /// <summary>
        /// Task 10 - Write a program to traverse given directory and write to a XML file its contents 
        /// together with all subdirectories and files. Use tags <file> and <dir> with appropriate attributes.
        /// Use XDocument, XElement and XAttribute.
        /// </summary>
        private static void WriteDirStructureToXmlUsingLinq()
        {
            DirectoryInfo sourceDirectory = new DirectoryInfo("../../");
            var createdXmlFileName = "../../directoryUsingLinq.xml";

            var document = AddDirectory(sourceDirectory);

            document.Save(createdXmlFileName);

            Console.WriteLine("Document {0} created.", createdXmlFileName);
            Console.WriteLine(new string('*', 50));
        }
        private static XElement AddDirectory(DirectoryInfo directory, XElement document = null)
        {
            //var subDirectories = directory.GetDirectories();
            //var directoryName = directory.Name;

            XElement newDir = new XElement("dir", new XAttribute("name", directory.Name));

            foreach (var subDirectory in directory.GetDirectories())
            {
                newDir.Add(AddDirectory(subDirectory, newDir));
            }

            foreach (var file in directory.GetFiles())
            {
                XElement newFile = new XElement("file", new XAttribute("name",file.Name));
                newDir.Add(newFile);
            }

            return newDir;
        }

        /// <summary>
        /// Task 11 - Write a program, which extract from the file catalog.xml the prices for all albums, 
        /// published 5 years ago or earlier. Use XPath query.
        /// </summary>
        private static void ExtractSelectionPricesFromCatalog()
        {
            XPathDocument docNav = new XPathDocument(filePath);
            XPathNavigator nav = docNav.CreateNavigator();
            string strExpression = "/catalog/album[year<2010]/price";

            var prices = nav.Select(strExpression);

            Console.WriteLine("Print prices for all albums, published 5 years ago or earlier (Using XPath query): ");

            while (prices.MoveNext())
            {
                Console.WriteLine(prices.Current.Value);
            }

            Console.WriteLine(new string('*', 50));
        }

        /// <summary>
        /// Task 12 - Write a program, which extract from the file catalog.xml the prices for all albums, 
        /// published 5 years ago or earlier. Use LINQ query.
        /// </summary>
        private static void ExtractSelectionPricesFromCatalogUsingLinq()
        {
            var document = XDocument.Load(filePath);

            var prices = document.Descendants("album")
                .Where(album => int.Parse(album.Descendants("year").FirstOrDefault().Value) <= 2009)
                .Select(album => album.Descendants("price").FirstOrDefault().Value);

            Console.WriteLine("Print prices for all albums, published 5 years ago or earlier (Using LINQ): ");

            foreach (var price in prices)
            {
                Console.WriteLine(price);
            }
            Console.WriteLine(new string('*', 50));
        }
    }
}

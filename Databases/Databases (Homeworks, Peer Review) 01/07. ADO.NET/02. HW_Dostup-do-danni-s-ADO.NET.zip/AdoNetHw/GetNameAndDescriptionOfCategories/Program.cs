﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetNameAndDescriptionOfCategories
{
    // 2. Write a program that retrieves the name and 
    // description of all categories in the Northwind DB.
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection dbCon = new SqlConnection(
                "Server=LOCALHOST; " +
                "Database=Northwind; " +
                "Integrated Security=true");

            dbCon.Open();

            using (dbCon)
            {
                SqlCommand command = new SqlCommand("SELECT CategoryName, Description FROM Categories", dbCon);
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Console.WriteLine("Name and Description of all categories in Northwind:");
                    while (reader.Read())
                    {
                        string categoryName = (string)reader["CategoryName"];
                        string categoryDescription = (string)reader["Description"];

                        Console.WriteLine("Name: {0}, Description: {1}", categoryName, categoryDescription);
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadExcelFile
{
    class Program
    {
        // 6. Write a program that reads your MS Excel file through the OLE DB data 
        // provider and displays the name and score row by row.
        static void Main(string[] args)
        {
            string path = @"../../playersAndScores.xlsx";
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";

            OleDbConnection excelCon = new OleDbConnection(connectionString);
            excelCon.Open();

            using (excelCon)
            {
                OleDbCommand command = new OleDbCommand(@"SELECT * FROM [Sheet1$]", excelCon);
                OleDbDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Console.WriteLine("Players:");
                    Console.WriteLine();
                    while (reader.Read())
                    {
                        string playerName = (string)reader["Name"];
                        double playerScore = (double)reader["Score"];

                        Console.WriteLine("Player Name: {0}, Score: {1}", playerName, playerScore);
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Linq;

namespace TaskEight
{
    class Product
    {

        public Product(string name)
        {
            this.Name = name;
            
        }

        public string Name { get; set; }
    }
}

﻿namespace ProductCategoryAndName
{
    using System;
    using System.Data.SqlClient;
    public class ProductCategoryAndName
    {
        public static void Main()
        {
            var connectionString = "Server=.\\; Database=NorthWind; Integrated Security=true";
            var db = new SqlConnection(connectionString);
            db.Open();

            using (db)
            {
                var query = "SELECT c.CategoryName, p.ProductName FROM Categories AS c " +
                    "INNER JOIN products AS p ON p.CategoryID = c.CategoryID";
                
                var cmdCategoryAndName = new SqlCommand(query, db);
                var reader = cmdCategoryAndName.ExecuteReader();

                using (reader)
                {
                    var message = "{0} - {1}";

                    while (reader.Read())
                    {
                        var productName = (string)reader["ProductName"];
                        var categoryName = (string)reader["CategoryName"];

                        Console.WriteLine(message, productName, categoryName);
                    }

                }
            }

        }
    }
}

﻿namespace _06.NameAndScoreFromExcel
{
    using System;
    using System.Data;
    using System.Data.OleDb;
    using System.Linq;
    public class NameAndScore
    {
        public static void Main()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='{0}';Extended Properties='Excel 12.0 Xml;HDR=YES;'";
            var excelPath = "../../../NameAndScore.xlsx";

            var dbConn = new OleDbConnection(string.Format(connectionString, excelPath));

            string query = "SELECT * from [Лист1$]";
            var command = new OleDbDataAdapter(query, dbConn);

            var dataSet = new DataSet();

            command.Fill(dataSet);

            var message = "Name: {0} - Score : {1}";

            foreach (DataTable table in dataSet.Tables)
            {
                foreach (DataRow dr in table.Rows)
                {
                    var name = dr["Name"];
                    var score = dr["Score"];
                    Console.WriteLine(message, name, score);
                }
            }
        }
    }
}

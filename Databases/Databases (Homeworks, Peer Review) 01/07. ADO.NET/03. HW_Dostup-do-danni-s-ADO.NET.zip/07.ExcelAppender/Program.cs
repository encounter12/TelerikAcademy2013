﻿namespace _07.ExcelAppender
{
    using System;
    using System.Data.OleDb;
    using System.Linq;
    public class Program
    {
        public static void Main()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='{0}';Extended Properties='Excel 12.0 Xml;HDR=YES;'";
            string path = "../../../NameAndScore.xlsx";

            var dbConn = new OleDbConnection(string.Format(connectionString, path));

            using (dbConn)
            {
                dbConn.Open();

                var query = "INSERT INTO [Лист1$](Name, Score) VALUES('Pesho', '150')";

                var command = new OleDbCommand(query,dbConn);
                command.ExecuteNonQuery();
            }
        }
    }
}

﻿namespace _02.NameAndDescription
{
    using System;
    using System.Data.SqlClient;
    using System.Linq;
    public class NameAndDescription
    {
        public static void Main()
        {
            var connectionString = "Server=.\\; Database=NorthWind; Integrated Security=true";

            var db = new SqlConnection(connectionString);
            db.Open();

            using (db)
            {
                var query = "SELECT CategoryName, Description FROM Categories";
                var cmdNameAndDescription = new SqlCommand(query, db);
                var reader = cmdNameAndDescription.ExecuteReader();

                using (reader)
                {
                    var message = "{0} - {1}";

                    while (reader.Read())
                    {
                        string name = (string)reader["CategoryName"];
                        string description = (string)reader["Description"];

                        Console.WriteLine(message, name, description);
                    }
                }
            }

        }
    }
}

﻿namespace _01.CategoryRows
{
    using System;
    using System.Data.SqlClient;
    using System.Linq;
    public class CategoryRows
    {
        public static void Main()
        {
            var sqlConnectionsString = "Server=.\\; Database=NorthWind; Integrated Security=true";

            var db = new SqlConnection(sqlConnectionsString);
            db.Open();

            using (db)
            {
                var query = "SELECT COUNT(*) FROM Categories";

                var cmdCount = new SqlCommand(query, db);
                int categoriesCount = (int)cmdCount.ExecuteScalar();

                var message = "Categories count : {0} ";
                Console.WriteLine(message,categoriesCount);
            }
        }
    }
}

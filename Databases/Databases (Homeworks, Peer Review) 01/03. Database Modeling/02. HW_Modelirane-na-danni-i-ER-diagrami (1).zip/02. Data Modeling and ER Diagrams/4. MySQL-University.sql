-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema University
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema University
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `University` DEFAULT CHARACTER SET latin1 ;
USE `University` ;

-- -----------------------------------------------------
-- Table `University`.`Faculties`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `University`.`Faculties` (
  `idFaculties` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(45) NULL,
  PRIMARY KEY (`idFaculties`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`Departments`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `University`.`Departments` (
  `idDepartments` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(45) NOT NULL,
  `Faculties_idFaculties` INT NOT NULL,
  PRIMARY KEY (`idDepartments`),
  INDEX `fk_Departments_Faculties_idx` (`Faculties_idFaculties` ASC),
  CONSTRAINT `fk_Departments_Faculties`
    FOREIGN KEY (`Faculties_idFaculties`)
    REFERENCES `University`.`Faculties` (`idFaculties`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`Professors`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `University`.`Professors` (
  `idProfessors` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(45) NOT NULL,
  `Departments_idDepartments` INT NOT NULL,
  PRIMARY KEY (`idProfessors`),
  INDEX `fk_Professors_Departments1_idx` (`Departments_idDepartments` ASC),
  CONSTRAINT `fk_Professors_Departments1`
    FOREIGN KEY (`Departments_idDepartments`)
    REFERENCES `University`.`Departments` (`idDepartments`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`ProfessorTitles`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `University`.`ProfessorTitles` (
  `idProfessorTitles` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idProfessorTitles`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`ProfessorTitles_has_Professors`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `University`.`ProfessorTitles_has_Professors` (
  `ProfessorTitles_idProfessorTitles` INT NOT NULL,
  `Professors_idProfessors` INT NOT NULL,
  INDEX `fk_ProfessorTitles_has_Professors_Professors1_idx` (`Professors_idProfessors` ASC),
  INDEX `fk_ProfessorTitles_has_Professors_ProfessorTitles1_idx` (`ProfessorTitles_idProfessorTitles` ASC),
  PRIMARY KEY (`Professors_idProfessors`, `ProfessorTitles_idProfessorTitles`),
  CONSTRAINT `fk_ProfessorTitles_has_Professors_ProfessorTitles1`
    FOREIGN KEY (`ProfessorTitles_idProfessorTitles`)
    REFERENCES `University`.`ProfessorTitles` (`idProfessorTitles`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ProfessorTitles_has_Professors_Professors1`
    FOREIGN KEY (`Professors_idProfessors`)
    REFERENCES `University`.`Professors` (`idProfessors`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`Courses`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `University`.`Courses` (
  `idCourses` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(45) NOT NULL,
  `Departments_idDepartments` INT NOT NULL,
  `Professors_idProfessors` INT NOT NULL,
  PRIMARY KEY (`idCourses`),
  INDEX `fk_Courses_Departments1_idx` (`Departments_idDepartments` ASC),
  INDEX `fk_Courses_Professors1_idx` (`Professors_idProfessors` ASC),
  CONSTRAINT `fk_Courses_Departments1`
    FOREIGN KEY (`Departments_idDepartments`)
    REFERENCES `University`.`Departments` (`idDepartments`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Courses_Professors1`
    FOREIGN KEY (`Professors_idProfessors`)
    REFERENCES `University`.`Professors` (`idProfessors`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`Students`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `University`.`Students` (
  `idStudents` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(45) NOT NULL,
  `Faculties_idFaculties` INT NOT NULL,
  PRIMARY KEY (`idStudents`),
  INDEX `fk_Students_Faculties1_idx` (`Faculties_idFaculties` ASC),
  CONSTRAINT `fk_Students_Faculties1`
    FOREIGN KEY (`Faculties_idFaculties`)
    REFERENCES `University`.`Faculties` (`idFaculties`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`Students_has_Courses`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `University`.`Students_has_Courses` (
  `Students_idStudents` INT NOT NULL,
  `Courses_idCourses` INT NOT NULL,
  INDEX `fk_Students_has_Courses_Courses1_idx` (`Courses_idCourses` ASC),
  INDEX `fk_Students_has_Courses_Students1_idx` (`Students_idStudents` ASC),
  PRIMARY KEY (`Courses_idCourses`, `Students_idStudents`),
  CONSTRAINT `fk_Students_has_Courses_Students1`
    FOREIGN KEY (`Students_idStudents`)
    REFERENCES `University`.`Students` (`idStudents`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Students_has_Courses_Courses1`
    FOREIGN KEY (`Courses_idCourses`)
    REFERENCES `University`.`Courses` (`idCourses`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

﻿using _01.CreateDB.Models;
using System.Data.Entity;

namespace _01.CreateDB.Data
{
    public class UniversityContext : DbContext
    {
        public UniversityContext()
            : base("UniversityDb")
        {

        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Homework> Homeworks { get; set; }
    }
}

﻿namespace ChatClient
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Shapes;
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string username = this.LoginTextBox.Text;
            if (IsUsernameValid(username))
            {
                var mainWindow = new MainWindow(username);
                this.Close();
                mainWindow.Show();
            }
        }

        private bool IsUsernameValid(string username)
        {
            char[] notAllowedCharacters = new[] { ' ', '\n', '\'', '"', '-', '_', '&', '=', '.', ',', '*', '^' };
            string[] validateUsername = username.Split(notAllowedCharacters, StringSplitOptions.RemoveEmptyEntries);
            int minUsernameLength = 5;
            int maxUsernameLength = 20;

            if (string.IsNullOrWhiteSpace(username))
            {
                this.LoginTextBox.Text = "USername can't be empty!";
                return false;
            }

            if (validateUsername.Length > 1)
            {
                this.LoginTextBox.Text = "Invalid characters in the username!";
                return false;
            }

            if (username.Length < minUsernameLength || username.Length > maxUsernameLength)
            {
                this.LoginTextBox.Text = string.Format("Username must be between {0} and {1} characters!", minUsernameLength, maxUsernameLength);
                return false;
            }

            return true;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}

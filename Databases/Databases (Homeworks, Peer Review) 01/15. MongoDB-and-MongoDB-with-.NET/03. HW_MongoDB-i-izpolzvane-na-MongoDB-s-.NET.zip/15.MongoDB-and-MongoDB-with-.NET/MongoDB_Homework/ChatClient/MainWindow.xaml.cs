﻿namespace ChatClient
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using MongoDB.Driver;
    using MongoDB.Bson;
    using System.Collections.ObjectModel;
    using System.Threading;
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string username;

        private readonly MongoCollection<BsonDocument> messages;

        public MainWindow(string username)
        {
            try
            {
                InitializeComponent();
                var db = new MongoClient(Connections.Default.MongoCloud).GetServer().GetDatabase("mongochat");
                this.username = username;
                this.messages = db.GetCollection<BsonDocument>("Messages");
                UpdatePostsEachMsAsync();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string message = this.InputTextBox.Text;
            if (!string.IsNullOrWhiteSpace(message))
            {
                messages.Insert(
                    new BsonDocument { { "Author", username }, { "Text", message }, { "Time", DateTime.Now } });
            }

            this.InputTextBox.Clear();
        }

        private async void UpdatePosts()
        {
            var formattedMessages = messages
                        .FindAll()
                        .Select(m => string.Format("[{0}] {1}: {2}", m["Time"].ToLocalTime(), m["Author"], m["Text"]));

            this.ChatView.ItemsSource = formattedMessages;
        }

        private void UpdatePostsEachMsAsync(int timeout = 1000)
        {
             Thread updatePostAsync = new Thread(
                () =>
                {
                    while (true)
                    {
                        this.ChatView.Dispatcher.BeginInvoke((Action)this.UpdatePosts);
                        Thread.Sleep(timeout);
                    }
                });

            updatePostAsync.Start();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}

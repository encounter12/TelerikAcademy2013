﻿namespace EntityFrameworkPerformance
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;

    using EntityFrameworkPerformance.Data;

    internal static class Program
    {
        private static void FirstExercise(TelerikAcademyEntities entities)
        {
            // ~150 requests
            IQueryable<Employee> employees = entities.Employees;

            // 1 request
            employees = entities.Employees.Include(employee => employee.Department).Include(employee => employee.Address).Include(employee => employee.Address.Town);

            foreach (Employee employee in employees)
            {
                Console.WriteLine("Name : {0}", employee.FirstName);
                Console.WriteLine("Department : {0}", employee.Department.Name);
                Console.WriteLine("Town : {0}", employee.Address.Town.Name);
            }
        }

        private static void Main()
        {
            TelerikAcademyEntities entities = new TelerikAcademyEntities();

            // FirstExercise(entities);
            SecondExercise(entities);
        }

        private static void SecondExercise(TelerikAcademyEntities entities)
        {
            // ~ 700 requests
            IEnumerable<Town> towns =
                entities.Employees.ToList().Select(employee => employee.Address).ToList().Select(address => address.Town).ToList().Where(town => town.Name == "Sofia").ToList();

            // 1 request
            towns = entities.Employees.Select(employee => employee.Address).Select(address => address.Town).Where(town => town.Name == "Sofia").ToList();
        }
    }
}
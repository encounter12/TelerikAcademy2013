﻿namespace ExtractAlbumsLinq
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml;
    using System.Xml.Linq;

    public class ExtractWithLinq
    {
        static void Main()
        {
            XDocument xmlDoc = XDocument.Load("../../catalog.xml");

            var albums =
                from album in xmlDoc.Descendants("album")
                where int.Parse(album.Element("year").Value) < 2004
                select new
                {
                    Title = album.Element("name").Value,
                    Price = album.Element("price").Value
                };

            foreach (var album in albums)
            {
                Console.WriteLine("Price of {0} -> ${1}.00", album.Title, album.Price);
            }
        }
    }
}

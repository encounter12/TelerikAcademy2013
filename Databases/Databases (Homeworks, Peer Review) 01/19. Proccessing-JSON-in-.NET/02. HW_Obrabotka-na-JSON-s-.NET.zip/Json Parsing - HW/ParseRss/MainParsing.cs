﻿namespace ParseRss
{
    using System;
    using System.Linq;
    using System.IO;
    using System.Net;
    using System.Xml.Linq;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System.Text;

    public class MainParsing
    {
        private static StringBuilder sbHtml;
        public static void Main ()
        {
            //2
            var client = new WebClient();
            client.DownloadFile("http://forums.academy.telerik.com/feed/qa.rss ", "../../telerikRss.xml");

            //3
            var doc = XElement.Load("../../telerikRss.xml");
            Console.WriteLine("Xml downloaded.");

            var rssJson = JsonConvert.SerializeXNode(doc);
            //4
            var rssObj = JObject.Parse(rssJson);
            var questionTitles = rssObj["rss"]["channel"]["item"].Select(t => t["title"]);

            foreach (var item in questionTitles)
            {
                Console.WriteLine(item);
            }

            //5
            var questionsObj = rssObj["rss"]["channel"].ToString();
            var questions = JsonConvert.DeserializeObject<Channel>(questionsObj);

            CreateHtml(questions);
            GenerateHtml();
        }

        private static void GenerateHtml ()
        {
            var writer = new StreamWriter("../../questions.html");
            using (writer)
            {
                writer.Write(sbHtml.ToString());
            }
        }

        private static void CreateHtml (Channel questions)
        {
            sbHtml = new StringBuilder();
            sbHtml.AppendLine(@"<!DOCTYPE html>");
            sbHtml.AppendLine(@"<html lang=""en"" xmlns=""http://www.w3.org/1999/xhtml"">");
            sbHtml.AppendLine(@"<head>");
            sbHtml.AppendLine(@" <meta charset=""utf-8"" />");
            sbHtml.AppendLine(@"<title>");
            sbHtml.AppendLine("Telerik Academy RSS");
            sbHtml.AppendLine(@"</title>");
            sbHtml.AppendLine(@"</head>");

            sbHtml.AppendLine(@"<body>");
            sbHtml.AppendLine(@"<ul>");
            foreach (var item in questions.Items)
            {
                sbHtml.AppendLine(@"<li>");
                sbHtml.AppendLine(string.Format("<h4><a href = \"{1}\">{0}</a></h4>", item.Title, item.QuestionLink));
                sbHtml.AppendLine(string.Format("<p>Category: {0}</p>", item.Category));
                sbHtml.AppendLine(@"</li>");
            }


            sbHtml.AppendLine(@"<ul>");
            sbHtml.AppendLine(@"</body>");
        }
    }
}

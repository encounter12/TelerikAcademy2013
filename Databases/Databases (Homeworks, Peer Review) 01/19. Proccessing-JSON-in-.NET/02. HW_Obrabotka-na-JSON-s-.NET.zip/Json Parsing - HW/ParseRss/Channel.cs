﻿namespace ParseRss
{
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public class Channel
    {
        [JsonProperty("item")]
        public ICollection<Item> Items { get; set; }
    }
}

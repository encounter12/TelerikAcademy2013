﻿namespace ParseRss
{
    using Newtonsoft.Json;

    public class Item
    {
        [JsonProperty("title")]
        public string Title { get; set; }
        [JsonProperty("category")]
        public string Category { get; set; }
        [JsonProperty("link")]
        public string QuestionLink { get; set; }
    }
}

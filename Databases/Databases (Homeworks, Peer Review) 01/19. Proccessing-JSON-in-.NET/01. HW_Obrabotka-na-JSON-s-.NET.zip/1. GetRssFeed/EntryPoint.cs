﻿namespace _1.GetRssFeed
{
    using System;
    using System.IO;
    using System.Net;
    using System.Text;
    using System.Xml.Linq;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    
    public class EntryPoint
    {
        public static void Main()
        {
            //1. The RSS feed is at http://forums.academy.telerik.com/feed/qa.rss
            //2. Download the content of the feed programmatically
            //   You can use WebClient.DownloadFile()
            var feedpath = @"..\..\rssfeed.xml";
            var client = new WebClient();
            client.DownloadFile(@"http://forums.academy.telerik.com/feed/qa.rss", feedpath);

            //3. Parse the XML from the feed to JSON

            var doc = XDocument.Load(feedpath);

            string jsonRss = JsonConvert.SerializeXNode(doc, Newtonsoft.Json.Formatting.Indented);

            Console.OutputEncoding = Encoding.Unicode;
            //Console.WriteLine(jsonRss);

            //4. Using LINQ-to-JSON select all the question titles 
            //   and print them to the console
            var jsonObj = JObject.Parse(jsonRss);

            var itemtitles = jsonObj["rss"]["channel"]["item"];

            foreach (var item in itemtitles)
            {
                Console.WriteLine(item["title"]);
            }

            //5. Parse the JSON string to POCO

            var itemsJson = jsonObj["rss"]["channel"]["item"].ToString();
            var pocoItems = JsonConvert.DeserializeObject<RssItem[]>(itemsJson);

            //foreach (var item in pocoItems)
            //{
            //    Console.WriteLine(item.Title);
            //    Console.WriteLine("\t" + item.Title);
            //    Console.WriteLine("\t" + item.Title);
            //}

            //6. Using the parsed objects create a HTML page that
            //   lists all questions from the RSS their categories and 
            //   a link to the question's page

            ProduceHTML(pocoItems);
        }

        private static void ProduceHTML(RssItem[] pocoItems)
        {
            var path = @"..\..\htmlfeed.html";

            using(var writer = new StreamWriter(path))
            {
                writer.WriteLine("<!DOCTYPE html><html lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta charset=\"utf-8\" /><title>TA Rss Feed</title></head><body><h1>The RSS Feed</h1><table>");

                foreach (var item in pocoItems)
                {
                    writer.WriteLine("<tr>");
                    writer.WriteLine("<td>" + item.Title + "</td>");
                    writer.WriteLine("<td>" + item.Category + "</td>");
                    writer.WriteLine("<td><a href=\"" + item.Link + "\">ClickHere</a></td>");
                    writer.WriteLine("</tr>");
                }

                writer.WriteLine("</table></body></html>");
            }
        }
    }
}

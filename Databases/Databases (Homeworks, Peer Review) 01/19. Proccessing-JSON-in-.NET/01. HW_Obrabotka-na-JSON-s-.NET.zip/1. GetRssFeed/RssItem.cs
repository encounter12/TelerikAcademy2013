﻿namespace _1.GetRssFeed
{
    public class RssItem
    {
        public string Title { get; set; }
        public string Link { get; set; }
        public string Category { get; set; }
    }
}

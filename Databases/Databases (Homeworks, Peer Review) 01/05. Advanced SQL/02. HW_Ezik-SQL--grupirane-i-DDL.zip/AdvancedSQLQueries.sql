USE TelerikAcademy;
--TASK 01-------------------------------------------------------------------------------------------------------------
SELECT
 FirstName + ' ' + LastName AS [Employee Name],
 Salary
FROM
 Employees
WHERE
 Salary = (
     SELECT
         MIN (Salary)
     FROM
         Employees
 );

--TASK 02-------------------------------------------------------------------------------------------------------------
SELECT
 FirstName + ' ' + LastName AS [Employee Name],
 Salary
FROM
 Employees
WHERE
 Salary < (
     SELECT
         MIN (Salary)
     FROM
         Employees
 ) * 1.1;

--TASK 03-------------------------------------------------------------------------------------------------------------
SELECT
 e.FirstName + ' ' + e.LastName AS [Employee Name],
 e.Salary,
 d.Name AS [Department]
FROM
 Employees e,
 Departments d
WHERE
 e.DepartmentID = d.DepartmentID
AND e.Salary = (
 SELECT
     MIN (e.Salary)
 FROM
     Employees e
 WHERE
     e.DepartmentID = d.DepartmentID
);

--TASK 04-------------------------------------------------------------------------------------------------------------
SELECT
 AVG (e.Salary) AS [Average Salary],
 d.Name AS [Department]
FROM
 Employees e
JOIN Departments d ON e.DepartmentID = d.DepartmentID
WHERE
 e.DepartmentID = 1
GROUP BY
 d.Name;

--TASK 05-------------------------------------------------------------------------------------------------------------
SELECT
 AVG (e.Salary) AS [Average Salary],
 d.Name AS [Department]
FROM
 Employees e
JOIN Departments d ON e.DepartmentID = d.DepartmentID
WHERE
 d.Name = 'Sales'
GROUP BY
 d.Name;

--TASK 06-------------------------------------------------------------------------------------------------------------
SELECT
 COUNT (*) AS [Number Of Employees in Sales]
FROM
 Employees e
WHERE
 e.DepartmentID = (
     SELECT
         d.DepartmentID
     FROM
         Departments d
     WHERE
         Name = 'Sales'
 );

--TASK 07-------------------------------------------------------------------------------------------------------------
SELECT
 COUNT (*) AS [Number of Employees with manager]
FROM
 Employees
WHERE
 ManagerID IS NOT NULL;

--TASK 08-------------------------------------------------------------------------------------------------------------
SELECT
 COUNT (*) AS [Number of Employees without manager]
FROM
 Employees
WHERE
 ManagerID IS NULL;

--TASK 09-------------------------------------------------------------------------------------------------------------
SELECT
 d.Name AS [Department Name],
 AVG (e.Salary) AS [Average Salary]
FROM
 Employees e
JOIN Departments d ON e.DepartmentID = d.DepartmentID
GROUP BY
 d.Name;

--TASK 10-------------------------------------------------------------------------------------------------------------
SELECT
 COUNT (*) AS [Number Of Employees],
 d.Name AS [Department Name],
 t.Name AS [Town Name]
FROM
 Employees e
JOIN Departments d ON e.DepartmentID = d.DepartmentID
JOIN Addresses a ON e.AddressID = a.AddressID
JOIN Towns t ON a.TownID = t.TownID
GROUP BY
 d.Name,
 t.Name
ORDER BY
 t.Name;

--TASK 11-------------------------------------------------------------------------------------------------------------
SELECT
 m.FirstName + ' ' + m.LastName AS [Manager Name],
 COUNT (*) AS [Number of Employees]
FROM
 Employees m
JOIN Employees e ON e.ManagerID = m.EmployeeID
OR m.ManagerID IS NULL
GROUP BY
 m.FirstName,
 m.LastName
HAVING
 COUNT (*) = 5
ORDER BY
 1;

--TASK 12-------------------------------------------------------------------------------------------------------------
SELECT
 e.FirstName + ' ' + e.LastName AS [Employee Name],
 ISNULL(
     m.FirstName + ' ' + m.LastName,'(no manager)'
 ) AS [Manager Name]
FROM
 Employees e
LEFT JOIN Employees m ON m.EmployeeID = e.ManagerID;

--TASK 13-------------------------------------------------------------------------------------------------------------
SELECT
 FirstName + ' ' + LastName AS [Employee Name]
FROM
 Employees
WHERE
 LEN(LastName) = 5
ORDER BY
 1;

--TASK 14-------------------------------------------------------------------------------------------------------------
SELECT CONVERT (VARCHAR, GETDATE(), 104) + ' ' + CONVERT (VARCHAR, GETDATE(), 114) AS [DATE TIME];

--TASK 15-------------------------------------------------------------------------------------------------------------
CREATE TABLE Users (
    [ID] INT IDENTITY,
    [Username] nvarchar (30) NOT NULL UNIQUE,
    [Password] nvarchar (30) NULL,
    [FullName] nvarchar (100) NOT NULL,
    [LastLogin] datetime,
    CONSTRAINT PK_Users PRIMARY KEY (ID),
    CONSTRAINT [Username] CHECK (LEN(Username) >= 3),
    CONSTRAINT [Password] CHECK (LEN(Password) >= 5)
);

--TASK 16-------------------------------------------------------------------------------------------------------------
CREATE VIEW UsersLoggedToday AS 
SELECT
    *
FROM
    Users
WHERE
    CAST (LastLogin AS DATE) = CAST (GETDATE() AS DATE);

--TASK 17-------------------------------------------------------------------------------------------------------------
CREATE TABLE Groups (
    [ID] INT IDENTITY,
    [Name] nvarchar (50) NOT NULL UNIQUE,
    CONSTRAINT PK_Groups PRIMARY KEY (ID)
);

--TASK 18-------------------------------------------------------------------------------------------------------------
ALTER TABLE Users ADD GroupID INT;

ALTER TABLE Users ADD CONSTRAINT FK_Users_Groups FOREIGN KEY (GroupID) REFERENCES Groups (ID);

--TASK 19-------------------------------------------------------------------------------------------------------------
INSERT INTO Groups (Name)
VALUES
    ('One'),
    ('Two'),
    ('Three'),
    ('Four');

INSERT INTO Users (
    Username,
    Password,
    FullName,
    LastLogin,
    GroupID
)
VALUES
    (
        'gosho',
        '123456',
        'Gosho Goshev',
        GETDATE(),
        1
    ),
    (
        'pesho',
        'pesho5',
        'Pesho Peshev',
        '2014-8-23',
        2
    ),
    (
        'sasho',
        'masho',
        'Sasho Sashev',
        '2010-1-15',
        3
    ),
    (
        'kyncho',
        'pyncho',
        'Kyncho Kynchev',
        GETDATE(),
        4
    );

--TASK 20-------------------------------------------------------------------------------------------------------------
UPDATE Groups
SET Name = 'UpdatedOne'
WHERE
    Name = 'One';

UPDATE Users
SET GroupID = 1
WHERE
    GroupID = 3;

--TASK 21-------------------------------------------------------------------------------------------------------------
DELETE
FROM
    Users
WHERE
    Username = 'pesho'; 

DELETE
FROM
    Groups
WHERE
    Name = 'Two';

--TASK 22-------------------------------------------------------------------------------------------------------------
INSERT INTO Users (Username, Password, FullName) 
SELECT
    LOWER (LEFT(FirstName, 1) + LastName),  
    LOWER (LEFT(FirstName, 1) + LastName) + 'pwd',
    FirstName + ' ' + LastName
FROM
    Employees WHERE LastName NOT LIKE '%Hill%'; -- There are a duplicate values (ahill)

--TASK 23-------------------------------------------------------------------------------------------------------------
UPDATE Users
SET Password = NULL
WHERE
    LastLogin < '20100310';

--TASK 24-------------------------------------------------------------------------------------------------------------
DELETE
FROM
    Users
WHERE
    Password IS NULL;

--TASK 25-------------------------------------------------------------------------------------------------------------
SELECT
    d.Name AS [Deparment Name],
    e.JobTitle AS [Job Title],
    AVG (e.Salary) AS [Average Salary]
FROM
    Employees e
JOIN Departments d ON e.DepartmentID = d.DepartmentID
GROUP BY
    d.Name,
    e.JobTitle;

--TASK 26-------------------------------------------------------------------------------------------------------------
SELECT
    MIN (Salary) AS [Minimal Employee Salary],
    d.Name AS [Department Name],
    e.JobTitle AS [Job Title],
    MIN (e.FirstName + ' ' + e.LastName) AS [Employee Name]
FROM
    Employees e
INNER JOIN Departments d ON e.DepartmentID = d.DepartmentID
GROUP BY
    d.Name,
    e.JobTitle;

--TASK 27-------------------------------------------------------------------------------------------------------------
SELECT
    TOP 1 t.Name AS [Town],
    COUNT (*) AS [Number of Employees]
FROM
    Employees e
JOIN Addresses a ON e.AddressID = a.AddressID
JOIN Towns t ON a.TownID = t.TownID
GROUP BY
    t.Name
ORDER BY
    2 DESC;

--TASK 28-------------------------------------------------------------------------------------------------------------
SELECT
    COUNT (DISTINCT(e.ManagerID)) AS [Number of Managers],
    t.Name AS [Town]
FROM
    Employees e
JOIN Employees m ON e.ManagerID = m.EmployeeID
OR m.ManagerID IS NULL
JOIN Addresses a ON e.AddressID = a.AddressID
JOIN Towns t ON a.TownID = t.TownID
GROUP BY
    t.Name
ORDER BY
    1;

--TASK 29-------------------------------------------------------------------------------------------------------------
CREATE TABLE WorkHours (
    [TaskID] INT IDENTITY,
    [EmployeeID] INT,
    [Date] datetime NOT NULL,
    [Task] nvarchar (100) NOT NULL,
    [Hours] INT NOT NULL,
    [Comments] nvarchar (100),
    CONSTRAINT PK_WorkHours PRIMARY KEY ([TaskID]),
    CONSTRAINT [Hours] CHECK ([Hours] > 0 OR [Hours] <= 24)
);

ALTER TABLE WorkHours 
WITH CHECK ADD CONSTRAINT [FK_WorkHours_Employees] FOREIGN KEY ([EmployeeID]) REFERENCES Employees ([EmployeeID]);

INSERT INTO WorkHours (
    [EmployeeID],
    [Date],
    [Task],
    [Hours],
    [Comments]
)
VALUES
    (
        1,
        GETDATE(),
        'Design',
        8,
        'Design the product'
    ),
    (
        2,
        GETDATE(),
        'Create',
        8,
        'Create the product'
    ),
    (
        3, 
    GETDATE(), 
        'Produce',
        8,
        'Produce the product'
    ),
    (
        4,
        GETDATE(),
        'Sell', 
        8,
        'Sell the product'      
    );

CREATE TABLE WorkHoursLog (
    [LogID] INT IDENTITY,
    [OldEmployeeID] INT,
    [OldDate] datetime,
    [OldTask] nvarchar (100),
    [OldHours] INT,
    [OldComments] nvarchar (100),
    [NewEmployeeID] INT,
    [NewDate] datetime,
    [NewTask] nvarchar (100),
    [NewHours] INT,
    [NewComments] nvarchar (100),
    [Command] nvarchar (10) CONSTRAINT PK_WorkHoursLog PRIMARY KEY ([LogID])
);

CREATE TRIGGER tr_workhoursInsert ON WorkHours FOR INSERT AS INSERT INTO WorkHoursLog (
    [OldEmployeeID],
    [OldDate],
    [OldTask],
    [OldHours],
    [OldComments],
    [NewEmployeeID],
    [NewDate],
    [NewTask],
    [NewHours],
    [NewComments],
    [Command]
) SELECT
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    i.EmployeeID,
    i. DATE,
    i.Task,
    i.Hours,
    i.Comments,
    'insert'
FROM
    WorkHours w
INNER JOIN inserted i ON w.TaskID = i.TaskID;

CREATE TRIGGER tr_workhoursUpdate ON WorkHours FOR UPDATE AS INSERT INTO WorkHoursLog (
    [OldEmployeeID],
    [OldDate],
    [OldTask],
    [OldHours],
    [OldComments],
    [NewEmployeeID],
    [NewDate],
    [NewTask],
    [NewHours],
    [NewComments],
    [Command]
) SELECT
    d.EmployeeID,
    d. DATE,
    d.Task,
    d.Hours,
    d.Comments,
    i.EmployeeID,
    i. DATE,
    i.Task,
    i.Hours,
    i.Comments,
    'update'
FROM
    deleted d
INNER JOIN inserted i ON d.TaskID = i.TaskID;

--TASK 30-------------------------------------------------------------------------------------------------------------
CREATE TRIGGER tr_workhoursDelete ON WorkHours FOR DELETE AS INSERT INTO WorkHoursLog (
    [OldEmployeeID],
    [OldDate],
    [OldTask],
    [OldHours],
    [OldComments],
    [NewEmployeeID],
    [NewDate],
    [NewTask],
    [NewHours],
    [NewComments],
    [Command]
) SELECT
    d.EmployeeID,
    d. DATE,
    d.Task,
    d.Hours,
    d.Comments,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'delete'
FROM
    deleted d;

BEGIN
    TRAN DELETE
FROM
    Employees SELECT
        d.Name
    FROM
        Employees e
    INNER JOIN Departments d ON e.DepartmentID = d.DepartmentID
    WHERE
        d.Name = 'Sales'
    GROUP BY
        d.Name 
ROLLBACK TRAN

--TASK 31-------------------------------------------------------------------------------------------------------------
BEGIN TRAN
    DROP TABLE EmployeesProjects
ROLLBACK TRAN

--TASK 32-------------------------------------------------------------------------------------------------------------
CREATE TABLE #TempEmployeeProjects(
    EmployeeID int,
    ProjectID int
)
INSERT INTO #TempEmployeeProjects
    SELECT ep.EmployeeID AS [EmployeeID],
                 ep.ProjectID AS [ProjectID]
    FROM EmployeesProjects ep
    DROP TABLE EmployeesProjects
    CREATE TABLE EmployeesProjects(
                EmployeeID int,
                ProjectID int
)
INSERT INTO EmployeesProjects
    SELECT tep.EmployeeID AS [EmployeeID],
                     tep.ProjectID AS [ProjectID]
    FROM #TempEmployeeProjects tep;
USE TelerikAcademy;
SELECT TOP 1 t.Name AS [Town Name], COUNT(e.LastName) AS [Employees Count] FROM Employees e
	INNER JOIN Departments d
	ON e.DepartmentID = d.DepartmentID
		INNER JOIN Addresses a
		ON e.AddressID = a.AddressID
			INNER JOIN Towns t
			ON a.TownID = t.TownID
GROUP BY t.Name
ORDER BY [Employees Count] DESC
USE TelerikAcademy;
CREATE TABLE #TemporaryTable (
        EmployeeId INT,
        ProjectId INT
)
 
INSERT INTO #TemporaryTable
SELECT ep.EmployeeId AS EmployeeId,
        ep.ProjectId AS ProjectId
FROM EmployeesProjects ep
 
DROP TABLE EmployeesProjects
 
CREATE TABLE EmployeesProjects (
        EmployeeId INT,
        ProjectId INT
)
 
INSERT INTO EmployeesProjects
SELECT tt.EmployeeId AS EmployeeId,
        tt.ProjectId AS ProjectId
FROM #TemporaryTable tt
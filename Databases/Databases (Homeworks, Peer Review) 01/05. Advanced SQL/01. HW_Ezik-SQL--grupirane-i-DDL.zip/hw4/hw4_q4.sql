USE TelerikAcademy;
SELECT AVG(e.Salary) FROM Employees e
WHERE e.DepartmentID= 1
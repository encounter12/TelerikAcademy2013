USE TelerikAcademy;
DELETE FROM Users
WHERE UserId = 1
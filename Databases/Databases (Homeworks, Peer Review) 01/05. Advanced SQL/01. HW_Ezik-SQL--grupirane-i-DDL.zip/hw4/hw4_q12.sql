USE TelerikAcademy;
SELECT e.FirstName + ' ' + e.LastName AS [Employee Name], ISNULL(m.FirstName + ' ' + m.LastName, '(no manager)') as [Manager Name] FROM Employees e
	INNER JOIN Employees m
	ON e.ManagerID = m.EmployeeID
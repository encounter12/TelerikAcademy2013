USE TelerikAcademy;
CREATE TABLE Groups(
	GroupID int IDENTITY,
	GroupName nvarchar(50) NOT NULL,
	CONSTRAINT PK_USERS PRIMARY KEY(GroupID),
	CONSTRAINT UC_UserName UNIQUE (GroupName)
)
GO
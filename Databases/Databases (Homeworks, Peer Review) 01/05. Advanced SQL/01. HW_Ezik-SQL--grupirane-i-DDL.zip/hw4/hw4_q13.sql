USE TelerikAcademy;
SELECT e.FirstName + ' ' + e.LastName AS [Employee Name] FROM Employees e
WHERE LEN(e.LastName) = 5
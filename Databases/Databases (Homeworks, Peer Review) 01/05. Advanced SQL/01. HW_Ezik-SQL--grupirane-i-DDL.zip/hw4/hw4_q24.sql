USE TelerikAcademy;
DELETE FROM Users
WHERE UserPassWord = NULL
USE TelerikAcademy;
SELECT e.JobTitle, d.Name AS [DepartmentName], AVG(e.Salary) AS [AverageSalary] FROM Employees e
	INNER JOIN Departments d
	ON e.DepartmentID = d.DepartmentID
GROUP BY e.JobTitle, d.Name
ORDER BY d.Name, e.JobTitle
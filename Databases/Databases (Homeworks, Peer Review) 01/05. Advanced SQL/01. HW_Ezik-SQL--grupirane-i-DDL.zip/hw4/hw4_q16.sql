CREATE VIEW [Logged today]
AS
SELECT * FROM Users u
WHERE DAY(u.LastLogin) = DAY(GETDATE())
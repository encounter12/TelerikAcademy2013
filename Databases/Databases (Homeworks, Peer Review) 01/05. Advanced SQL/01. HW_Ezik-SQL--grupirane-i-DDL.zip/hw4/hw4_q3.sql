USE TelerikAcademy;
SELECT e.DepartmentID, FirstName + ' ' + e.LastName AS [Employee Name], e.Salary FROM Employees e
WHERE e.Salary =
	(SELECT MIN(Salary) FROM Employees
	WHERE e.DepartmentID = DepartmentID)
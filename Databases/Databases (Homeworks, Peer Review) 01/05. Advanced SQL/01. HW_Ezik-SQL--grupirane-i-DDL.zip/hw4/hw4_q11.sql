USE TelerikAcademy;
SELECT e.FirstName, e.LastName FROM Employees e
	INNER JOIN Employees m
	ON e.EmployeeID = m.ManagerID
GROUP BY e.FirstName, e.LastName
HAVING COUNT(m.EmployeeId) = 5
USE TelerikAcademy;
BEGIN TRAN
DROP TABLE EmployeesProjects
ROLLBACK TRAN
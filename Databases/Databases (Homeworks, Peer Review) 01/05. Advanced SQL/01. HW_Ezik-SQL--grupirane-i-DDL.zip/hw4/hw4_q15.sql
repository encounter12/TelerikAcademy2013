USE TelerikAcademy;
CREATE TABLE Users(
	UserID int IDENTITY,
	UserName nvarchar(50) NOT NULL,
	UserPassWord nvarchar(50) NOT NULL,
	FullName nvarchar(100) NOT NULL,
	LastLogin timestamp
	CONSTRAINT PK_USERS PRIMARY KEY(UserId),
	CONSTRAINT UC_UserName UNIQUE (UserName),
	CONSTRAINT PS_UserPassWord CHECK(LEN(UserPassWord)>=5)
)
GO
USE TelerikAcademy;
SELECT COUNT(*) AS [Managed Employees] FROM Employees e
WHERE e.ManagerID IS NOT NULL
AND
e.ManagerID != e.EmployeeID
USE TelerikAcademy;
SELECT COUNT(*) AS [Sales Employees] FROM Employees e
	INNER JOIN Departments d
	ON e.DepartmentID = d.DepartmentID
WHERE d.Name = 'Sales'
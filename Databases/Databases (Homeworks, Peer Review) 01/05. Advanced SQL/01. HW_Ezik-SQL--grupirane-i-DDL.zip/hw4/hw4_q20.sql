USE TelerikAcademy;
UPDATE Users
SET UserPassWord = 'changeme'
WHERE UserId = 1

UPDATE Groups
SET GroupName = 'changeme'
WHERE GroupId = 1
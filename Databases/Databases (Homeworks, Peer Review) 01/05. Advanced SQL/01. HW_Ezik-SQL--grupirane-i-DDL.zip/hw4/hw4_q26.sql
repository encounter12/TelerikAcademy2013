USE TelerikAcademy;
SELECT e.JobTitle, d.Name AS [DepartmentName], AVG(e.Salary) AS [MinimumSalary], MIN(e.FirstName + ' ' + e.LastName) as [Sample Employee] FROM Employees e
	INNER JOIN Departments d
	ON e.DepartmentID = d.DepartmentID
GROUP BY e.JobTitle, d.Name
USE TelerikAcademy;
ALTER TABLE Users
ADD GroupId int NOT NULL
 
ALTER TABLE Users
ADD CONSTRAINT FK_Users_Groups
FOREIGN KEY (GroupId)
REFERENCES Groups(Id)
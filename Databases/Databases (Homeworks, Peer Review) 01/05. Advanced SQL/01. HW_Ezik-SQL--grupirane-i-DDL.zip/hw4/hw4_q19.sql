USE TelerikAcademy;
INSERT INTO Users (UserName, UserPassWord, FullName, LastLogin, GroupId)
VALUES ('Pesho', 'TheSecret123', 'Pesho Peshev', GETDATE(), 111)

INSERT INTO Groups (GroupName)
VALUES ('.NET Ninjas')
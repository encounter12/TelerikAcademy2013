USE TelerikAcademy;
-- Will throw exceptions because some users have the same names, and other users have too short name for password to meet criteria
INSERT INTO Users
SELECT LOWER(LEFT(e.FirstName,1)) + LOWER(e.LastName) AS [UserName],
LOWER(LEFT(e.FirstName,1)) + LOWER(e.LastName) + ' ' AS [UserPassWord],
e.FirstName + ' ' + e.LastName AS [FullName],
NULL AS [LastLogin],
NULL AS GroupId
FROM Employees e
--Suppose you are creating a simple engine for an ATM machine. 
--Create a new database "ATM" in SQL Server to hold the accounts
--of the card holders and the balance (money) for each account. 
--Add a new table CardAccounts with the following fields: 
--	Id (int)
--	CardNumber (char(10))
--	CardPIN (char(4))
--	CardCash (money)
--Add a few sample records in the table.

CREATE DATABASE ATM

USE ATM

CREATE TABLE CardAccounts(
	Id int NOT NULL IDENTITY,
	CardNumber char(10) NOT NULL,
	CardPIN char(4) NOT NULL,
	CardCash money NOT NULL,
	CONSTRAINT PK_CardAccounts PRIMARY KEY(Id)
)

INSERT INTO CardAccounts(CardNumber, CardPIN, CardCash)
	VALUES('ABCD5EFGH9', '1234', 1000.89),
		('BFFD5EFGH9', '1564', 10000.89),
		('JBCD5EFGH9', '4321', 100.19),
		('PKLD5EFGH9', '2345', 10.39),
		('RBCD5EFGH9', '4567', 3450.89),
		('TBCD5EFGH9', '7890', 1234.89),
		('EBCD5EFGH9', '4545', 2000000.89),
		('3BCD5EFGH9', '1234', 45546.89),
		('2BCD5EFGH9', '1234', 100340.89),
		('LBCD5EFGH9', '1234', 12000.89)

CREATE TABLE TransactionsHistory(
	Id int NOT NULL IDENTITY,
	CardNumber char(10) NOT NULL,
	TransactionDate datetime NOT NULL,
	Amount money NOT NULL,
	CONSTRAINT PK_TransactionsHistory PRIMARY KEY(Id)
)

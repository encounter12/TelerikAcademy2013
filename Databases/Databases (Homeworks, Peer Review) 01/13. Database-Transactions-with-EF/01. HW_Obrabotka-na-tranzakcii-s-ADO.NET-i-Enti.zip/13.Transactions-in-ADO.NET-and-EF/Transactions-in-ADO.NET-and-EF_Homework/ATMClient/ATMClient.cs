﻿//Using transactions write a method which retrieves some money 
//(for example $200) from certain account. The retrieval is 
//successful when the following sequence of sub-operations 
//is completed successfully:
//A query checks if the given CardPIN and CardNumber are valid.
//The amount on the account (CardCash) is evaluated to see whether
//it is bigger than the requested sum (more than $200).
//The ATM machine pays the required sum (e.g. $200) and stores
//in the table CardAccounts the new amount (CardCash = CardCash - 200).

//Extend the project from the previous exercise and add a new table
//TransactionsHistory with fields (Id, CardNumber, TransactionDate, Ammount)
//containing information about all money retrievals on all accounts.
//Modify the program logic so that it saves historical information (logs)
//in the new table after each successful money withdrawal.
//What should the isolation level be for the transaction?

namespace ATMClient
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Transactions;

    using _00.ATMEntities;

    class ATMClient
    {
        static void Main(string[] args)
        {
            string cardNumber = "BFFD5EFGH9";
            string cardPIN = "1564";
            decimal moneyToDraw = (decimal) 200;
            bool successfulTransaction = WithDrawMoney(cardNumber, cardPIN, moneyToDraw);
            if (successfulTransaction)
            {
                Console.WriteLine("Successful Transaction! Here's your money...");
            }
            else
            {
                Console.WriteLine("Failed Transaction!");
            }
        }

        static bool WithDrawMoney(string cardNumber, string cardPIN, decimal money)
        {
            if (cardNumber == null)
            {
                Console.WriteLine("You have to insert a card!");
                return false;
            }

            if (cardPIN == null)
            {
                Console.WriteLine("You have to enter your PIN!");
                return false;
            }

            if (cardNumber.Length != 10)
            {
                Console.WriteLine("Invalid card number! Card number must consist of 10 digits!");
                return false;
            }

            if (cardPIN.Length != 4)
            {
                Console.WriteLine("Invalid card PIN! Card PIN must consist of 4 digits!");
                return false;
            }

            var options = new TransactionOptions
            {
                IsolationLevel = IsolationLevel.RepeatableRead,
                Timeout = new TimeSpan(0, 0, 0, 10)
            };
            using (var tranScope = new TransactionScope(TransactionScopeOption.Required, options))
            {
                ATMEntities atmEntities = new ATMEntities();
                var account = atmEntities.CardAccounts.FirstOrDefault(a => a.CardNumber == cardNumber && a.CardPIN == cardPIN);
                if (account == null)
                {
                    Console.WriteLine("There is no such Card Number or Card PIN!");
                    tranScope.Dispose();
                    return false;
                }

                if (money < 0)
                {
                    Console.WriteLine("You can not withdraw negative money!");
                    tranScope.Dispose();
                    return false;
                }

                if (account.CardCash < money)
                {
                    Console.WriteLine("The money you requested is more than you have in your account!");
                    tranScope.Dispose();
                    return false;
                }

                if (SaveTransactionHistory(cardNumber, money))
                {
                    account.CardCash -= money;
                    atmEntities.SaveChanges();
                    Console.WriteLine("You have {0} money left", account.CardCash);
                    tranScope.Complete();
                    return true;
                }
                else
                {
                    Console.WriteLine("Sorry, but there are problems with the system!");
                    tranScope.Dispose();
                    return false;
                }
            }
        }

        static bool SaveTransactionHistory(string cardNumber, decimal money)
        {
            ATMEntities atmEntities = new ATMEntities();
            var options = new TransactionOptions
            {
                IsolationLevel = IsolationLevel.RepeatableRead,
                Timeout = new TimeSpan(0, 0, 0, 10)
            };

            using (var tranScope = new TransactionScope(TransactionScopeOption.Required, options))
            {
                atmEntities.TransactionsHistories.Add(new TransactionsHistory
                {
                    CardNumber = cardNumber,
                    TransactionDate = DateTime.Now,
                    Amount = money
                });

                int saved = atmEntities.SaveChanges();
                if (saved == 1)
                {
                    tranScope.Complete();
                    return true;
                }
                else
                {
                    tranScope.Dispose();
                    return false;
                }
            }
        }
    }
}

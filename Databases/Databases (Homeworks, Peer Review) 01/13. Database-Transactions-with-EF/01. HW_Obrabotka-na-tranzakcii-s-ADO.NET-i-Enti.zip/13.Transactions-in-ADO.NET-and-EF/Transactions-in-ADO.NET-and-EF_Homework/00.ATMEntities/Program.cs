﻿namespace _00.ATMEntities
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
